// تخزين محلي آمن — لا يتعطل التطبيق إن كان التخزين ممتلئًا أو ممنوعًا (مثل التصفح الخاص)
export const store = {
  get(k) { try { const v = localStorage.getItem(k); return v == null ? undefined : JSON.parse(v); } catch { return undefined; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  remove(k) { try { localStorage.removeItem(k); } catch {} },
};

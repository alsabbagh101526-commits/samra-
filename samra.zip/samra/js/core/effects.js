// مؤثرات بصرية — للعرض فقط، لا تقرأ ولا تكتب حالة اللعبة
import { settings } from './settings.js';

const root = () => document.getElementById('fx-root');

export function burst(colors = ['#f2b134', '#3ba99c', '#e2574c', '#f3e7cf'], count = 60) {
  const s = settings.get();
  if (s.reduceMotion) return;
  const n = s.performance ? Math.min(14, count) : count;
  const r = root();
  for (let i = 0; i < n; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + 'vw';
    p.style.background = colors[i % colors.length];
    p.style.animationDuration = 1.6 + Math.random() * 1.6 + 's';
    p.style.animationDelay = Math.random() * .4 + 's';
    r.appendChild(p);
    setTimeout(() => p.remove(), 3800);
  }
}

export function flash(color = '#fff') {
  if (settings.get().reduceMotion) return;
  const f = document.createElement('div');
  f.className = 'flash';
  f.style.background = color;
  root().appendChild(f);
  setTimeout(() => f.remove(), 800);
}

export function shake(el) {
  if (!el || settings.get().reduceMotion) return;
  el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
}

export function vibrate(ms = 30) {
  if (settings.get().reduceMotion) return;
  try { navigator.vibrate && navigator.vibrate(ms); } catch {}
}

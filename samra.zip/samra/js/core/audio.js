// مؤثرات صوتية مولّدة برمجيًا — بدون أي موسيقى، وبدون ملفات خارجية.
// لكل لعبة "طابع" صوتي: noir (المافيا)، luxe (الجمجمة)، pop (برا السالفة)، shell (المنصة).
import { settings } from './settings.js';

let ctx = null, master = null;
const lastPlayed = new Map();

function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  ctx = new AC();
  master = ctx.createGain();
  master.connect(ctx.destination);
  return ctx;
}

// يجب فتح الصوت بعد أول لمسة (قيود المتصفحات على الجوال)
export function unlockAudio() {
  const c = ensure();
  if (c && c.state === 'suspended') c.resume();
}

function tone(freq, dur, { type = 'sine', gain = 0.3, at = 0, to = null, attack = 0.005 } = {}) {
  const t = ctx.currentTime + at;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(master);
  o.start(t); o.stop(t + dur + 0.02);
}

function noise(dur, { gain = 0.2, at = 0, freq = 1200, q = 1, type = 'bandpass' } = {}) {
  const t = ctx.currentTime + at;
  const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const s = ctx.createBufferSource(); s.buffer = buf;
  const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
  const g = ctx.createGain(); g.gain.value = gain;
  s.connect(f); f.connect(g); g.connect(master);
  s.start(t);
}

const SFX = {
  shell: {
    tap: () => tone(660, .06, { type: 'triangle', gain: .12 }),
    join: () => { tone(523, .12, { gain: .18 }); tone(784, .16, { gain: .18, at: .08 }); },
    leave: () => { tone(523, .12, { gain: .15 }); tone(392, .18, { gain: .15, at: .08 }); },
    error: () => tone(220, .22, { type: 'square', gain: .08, to: 160 }),
    flip: () => { noise(.1, { freq: 2800, gain: .2 }); tone(500, .1, { type: 'triangle', gain: .1, to: 800, at: .03 }); },
    reveal: () => { tone(440, .12, { gain: .14 }); tone(660, .2, { gain: .12, at: .1 }); },
    secret: () => { tone(660, .08, { gain: .1 }); tone(990, .12, { gain: .08, at: .07 }); },
    coin: () => { tone(1320, .08, { type: 'square', gain: .06 }); tone(1760, .14, { type: 'square', gain: .05, at: .06 }); },
    buzz: () => tone(160, .35, { type: 'square', gain: .1 }),
    correct: () => { tone(880, .12, { gain: .15 }); tone(1320, .25, { gain: .12, at: .1 }); },
    wrong: () => tone(180, .4, { type: 'sawtooth', gain: .08, to: 120 }),
    dice: () => { for (let k = 0; k < 4; k++) noise(.05, { freq: 1500 + k * 300, gain: .25, at: k * .06 }); },
    tick: () => tone(1200, .03, { type: 'square', gain: .05 }),
    timeUp: () => { tone(440, .15, { type: 'square', gain: .08 }); tone(330, .3, { type: 'square', gain: .08, at: .16 }); },
    vote: () => tone(500, .1, { type: 'square', gain: .07, to: 750 }),
    win: () => { [523, 659, 784, 1047].forEach((f, k) => tone(f, .4, { type: 'triangle', gain: .12, at: k * .1 })); },
    lose: () => { [392, 349, 330, 262].forEach((f, k) => tone(f, .4, { type: 'triangle', gain: .08, at: k * .14 })); },
    boom: () => { noise(.8, { freq: 120, gain: .6, type: 'lowpass' }); tone(60, .9, { gain: .3, to: 30 }); },
    phase: () => tone(587, .18, { type: 'triangle', gain: .1 }),
  },
  noir: {
    tap: () => tone(180, .07, { type: 'triangle', gain: .14 }),
    flip: () => { noise(.12, { freq: 2500, gain: .25 }); tone(110, .3, { gain: .14, at: .05 }); },
    reveal: () => { tone(98, .9, { type: 'sawtooth', gain: .05 }); tone(147, .9, { type: 'sawtooth', gain: .04 }); tone(155.6, .9, { type: 'sine', gain: .08, at: .1 }); },
    night: () => { tone(220, 1.2, { gain: .12, to: 110 }); noise(1.2, { freq: 400, gain: .06, type: 'lowpass' }); },
    dawnDeath: () => { tone(82, 1.2, { type: 'sawtooth', gain: .07 }); tone(87, 1.2, { type: 'sawtooth', gain: .06 }); noise(.3, { freq: 200, gain: .3, type: 'lowpass' }); },
    dawnSafe: () => { tone(392, .25, { gain: .14 }); tone(523, .4, { gain: .12, at: .15 }); },
    vote: () => { noise(.08, { freq: 900, gain: .3 }); tone(140, .12, { gain: .18 }); },
    tick: () => tone(1200, .03, { type: 'square', gain: .05 }),
    timeUp: () => { tone(440, .15, { type: 'square', gain: .08 }); tone(330, .3, { type: 'square', gain: .08, at: .16 }); },
    win: () => { [261, 329, 392, 523].forEach((f, k) => tone(f, .5, { gain: .12, at: k * .12 })); },
    lose: () => { [220, 207, 196, 174].forEach((f, k) => tone(f, .55, { type: 'sawtooth', gain: .05, at: k * .16 })); },
    eliminated: () => { noise(.5, { freq: 150, gain: .35, type: 'lowpass' }); tone(65, .8, { gain: .2 }); },
    secret: () => { tone(660, .08, { gain: .1 }); tone(990, .12, { gain: .08, at: .07 }); },
  },
  luxe: {
    tap: () => tone(880, .05, { type: 'triangle', gain: .1 }),
    place: () => { noise(.06, { freq: 600, gain: .35, type: 'lowpass' }); tone(140, .12, { gain: .2 }); },
    bid: () => { tone(988, .35, { gain: .1 }); tone(1480, .5, { gain: .05, at: .02 }); },
    pass: () => tone(330, .12, { type: 'triangle', gain: .1 }),
    flip: () => { noise(.1, { freq: 3000, gain: .2 }); },
    rose: () => { tone(784, .5, { gain: .12 }); tone(1175, .6, { gain: .07, at: .05 }); },
    skull: () => { tone(110, .9, { type: 'sawtooth', gain: .08, to: 70 }); noise(.4, { freq: 300, gain: .3, type: 'lowpass' }); },
    point: () => { [659, 784, 988, 1319].forEach((f, k) => tone(f, .6, { gain: .1, at: k * .09 })); },
    lose: () => tone(196, .6, { type: 'triangle', gain: .14, to: 130 }),
    win: () => { [523, 659, 784, 1047, 1319].forEach((f, k) => tone(f, .9, { gain: .1, at: k * .11 })); },
    round: () => tone(587, .4, { gain: .1 }),
  },
  pop: {
    tap: () => tone(900, .05, { type: 'triangle', gain: .12, to: 1200 }),
    flip: () => { noise(.08, { freq: 3500, gain: .2 }); tone(700, .12, { type: 'triangle', gain: .12, to: 1100, at: .04 }); },
    reveal: () => { tone(523, .1, { gain: .15 }); tone(659, .1, { gain: .15, at: .08 }); tone(784, .2, { gain: .15, at: .16 }); },
    next: () => tone(660, .08, { type: 'triangle', gain: .15, to: 990 }),
    vote: () => tone(500, .1, { type: 'square', gain: .07, to: 750 }),
    caught: () => { [784, 659, 523].forEach((f, k) => tone(f, .18, { type: 'square', gain: .07, at: k * .1 })); },
    escaped: () => { [392, 523, 659, 784].forEach((f, k) => tone(f, .15, { type: 'triangle', gain: .12, at: k * .07 })); },
    correct: () => { tone(880, .12, { gain: .15 }); tone(1320, .25, { gain: .12, at: .1 }); },
    wrong: () => tone(200, .3, { type: 'square', gain: .08, to: 140 }),
    score: () => { for (let k = 0; k < 5; k++) tone(900 + k * 120, .06, { type: 'triangle', gain: .08, at: k * .05 }); },
    win: () => { [523, 659, 784, 1047].forEach((f, k) => tone(f, .35, { type: 'triangle', gain: .13, at: k * .1 })); },
  },
};

export function play(kit, name) {
  const s = settings.get();
  if (!s.sound || s.volume <= 0) return;
  const c = ensure();
  if (!c) return;
  if (c.state === 'suspended') c.resume();
  // منع التكرار المزعج لنفس المؤثر خلال وقت قصير
  const key = kit + ':' + name;
  const now = performance.now();
  if (now - (lastPlayed.get(key) || 0) < 90) return;
  lastPlayed.set(key, now);
  master.gain.value = s.volume;
  const fn = SFX[kit]?.[name] || SFX.shell[name];
  try { fn && fn(); } catch {}
}

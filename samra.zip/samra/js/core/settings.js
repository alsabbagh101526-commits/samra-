// إعدادات المستخدم: الصوت والحركة والأداء — تُحفظ محليًا
import { store } from './storage.js';

const KEY = 'samra.settings';
const prefersReduced = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
const DEFAULTS = { sound: true, volume: 0.7, reduceMotion: prefersReduced, performance: false };

let current = { ...DEFAULTS, ...(store.get(KEY) || {}) };
const subs = new Set();

export const settings = {
  get: () => current,
  set(patch) {
    current = { ...current, ...patch };
    current.volume = Math.min(1, Math.max(0, Number(current.volume) || 0));
    store.set(KEY, current);
    apply();
    subs.forEach(f => f(current));
  },
  subscribe(f) { subs.add(f); return () => subs.delete(f); },
};

export function apply() {
  const h = document.documentElement;
  h.classList.toggle('reduce-motion', !!current.reduceMotion);
  h.classList.toggle('perf', !!current.performance);
}

const PKEY = 'samra.profile';
export const profile = {
  get: () => store.get(PKEY) || null,
  set: p => store.set(PKEY, p),
};

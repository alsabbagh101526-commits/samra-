// أدوات واجهة مشتركة
import { settings, profile } from '../core/settings.js';
import { play } from '../core/audio.js';
import { AVATARS, sanitizeName } from '../net/protocol.js';

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (sel, el = document) => el.querySelector(sel);

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
export const ar = n => String(n).replace(/\d/g, d => AR_DIGITS[d]);

export function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  document.getElementById('toast-root').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

let openSheetClose = null;
// النوافذ التي تفتحها اللعبة نفسها تُوسَم حتى تُغلق تلقائيًا عند تغيّر الشاشة (مرحلة/دور جديد)
let sheetScope = null, openSheetScope = null;
export function withSheetScope(scope, fn) { const prev = sheetScope; sheetScope = scope; try { return fn(); } finally { sheetScope = prev; } }
export function closeSheetOfScope(scope) { if (openSheetClose && openSheetScope === scope) openSheetClose(); }
export function openSheet(html, { onMount, label = '' } = {}) {
  closeSheet();
  openSheetScope = sheetScope;
  const root = document.getElementById('sheet-root');
  root.innerHTML = `<div class="sheet-backdrop" data-close></div>
    <div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(label)}"><div class="grab"></div>${html}</div>`;
  const sheet = root.querySelector('.sheet');
  const close = () => { root.innerHTML = ''; openSheetClose = null; openSheetScope = null; document.removeEventListener('keydown', onKey); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  root.querySelector('[data-close]').addEventListener('click', close);
  sheet.addEventListener('click', e => { if (e.target.closest('[data-sheet-close]')) close(); });
  openSheetClose = close;
  onMount?.(sheet, close);
  const f = sheet.querySelector('input, button');
  if (f && f.tagName === 'INPUT') setTimeout(() => f.focus(), 280);
  return close;
}
export function closeSheet() { if (openSheetClose) openSheetClose(); }

export function qrSvg(text) {
  const qr = window.qrcode(0, 'M');
  qr.addData(text);
  qr.make();
  return qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
}

export function avatar(p, cls = '') {
  return `<span class="avatar ${cls} ${p && p.connected === false ? 'off' : ''}" aria-hidden="true">${esc(p?.emoji || '❔')}</span>`;
}

// ورقة الملف الشخصي: الاسم والإيموجي
export function profileSheet({ title = 'من أنت؟', submit = 'حفظ' } = {}) {
  return new Promise(resolve => {
    const cur = profile.get() || { name: '', emoji: AVATARS[Math.floor(Math.random() * AVATARS.length)] };
    let chosen = cur.emoji;
    let done = false;
    openSheet(`
      <h2>${esc(title)}</h2>
      <div class="stack">
        <div class="row" style="justify-content:center"><span class="avatar lg" id="pv">${esc(chosen)}</span></div>
        <div class="field"><label for="pname">اسمك في اللعبة</label>
          <input id="pname" class="input" maxlength="18" autocomplete="nickname" enterkeyhint="done" value="${esc(cur.name)}" placeholder="مثال: أبو فهد"></div>
        <div class="field"><span class="soft" style="font-size:15px">اختر صورتك</span>
          <div class="chip-grid" role="group" aria-label="اختيار الصورة">
            ${AVATARS.map(e => `<button class="emoji-chip" data-emoji="${e}" aria-pressed="${e === chosen}" aria-label="صورة ${e}">${e}</button>`).join('')}
          </div></div>
        <button class="btn block" id="psave">${esc(submit)}</button>
      </div>`, {
      label: title,
      onMount(sheet, close) {
        sheet.addEventListener('click', e => {
          const b = e.target.closest('[data-emoji]');
          if (!b) return;
          chosen = b.dataset.emoji;
          sheet.querySelectorAll('[data-emoji]').forEach(x => x.setAttribute('aria-pressed', x === b));
          sheet.querySelector('#pv').textContent = chosen;
          play('shell', 'tap');
        });
        const save = () => {
          const name = sanitizeName(sheet.querySelector('#pname').value);
          if (!name) { toast('اكتب اسمك أولًا', 'err'); sheet.querySelector('#pname').focus(); return; }
          const p = { name, emoji: chosen };
          profile.set(p);
          done = true;
          close();
          resolve(p);
        };
        sheet.querySelector('#psave').addEventListener('click', save);
        sheet.querySelector('#pname').addEventListener('keydown', e => { if (e.key === 'Enter') save(); });
        const backdrop = document.querySelector('.sheet-backdrop');
        backdrop.addEventListener('click', () => { if (!done) resolve(null); });
      },
    });
  });
}

export function settingsSheet() {
  const s = settings.get();
  openSheet(`
    <h2>الإعدادات</h2>
    <label class="switch-row"><span class="grow">المؤثرات الصوتية</span><input type="checkbox" class="switch" id="s-sound" ${s.sound ? 'checked' : ''}></label>
    <div class="field"><label for="s-vol">مستوى الصوت</label><input type="range" id="s-vol" min="0" max="1" step="0.05" value="${s.volume}"></div>
    <label class="switch-row"><span class="grow">تقليل الحركة<br><small class="muted">يوقف الانتقالات والجزيئات</small></span><input type="checkbox" class="switch" id="s-rm" ${s.reduceMotion ? 'checked' : ''}></label>
    <label class="switch-row"><span class="grow">وضع الأداء<br><small class="muted">للأجهزة الضعيفة: يلغي الخلفيات المتحركة والظلال</small></span><input type="checkbox" class="switch" id="s-perf" ${s.performance ? 'checked' : ''}></label>
    <div class="divider"></div>
    <button class="btn soft block" id="s-prof">تعديل اسمي وصورتي</button>
    <p class="muted center" style="font-size:14px;margin-top:14px">لا توجد موسيقى في المنصة — مؤثرات صوتية فقط.</p>
  `, {
    label: 'الإعدادات',
    onMount(sheet) {
      sheet.querySelector('#s-sound').addEventListener('change', e => { settings.set({ sound: e.target.checked }); play('shell', 'tap'); });
      sheet.querySelector('#s-vol').addEventListener('input', e => settings.set({ volume: Number(e.target.value) }));
      sheet.querySelector('#s-vol').addEventListener('change', () => play('shell', 'join'));
      sheet.querySelector('#s-rm').addEventListener('change', e => settings.set({ reduceMotion: e.target.checked }));
      sheet.querySelector('#s-perf').addEventListener('change', e => settings.set({ performance: e.target.checked }));
      sheet.querySelector('#s-prof').addEventListener('click', () => { document.dispatchEvent(new CustomEvent('samra:edit-profile')); });
    },
  });
}

export function fmtTime(ms) {
  const t = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`;
}

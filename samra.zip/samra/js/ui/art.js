// رسومات أصلية بصيغة SVG — كل الشخصيات بلا ملامح وجه (ظلال فقط)
let gid = 0;
const uid = p => p + (++gid);

// ================= شخصيات المافيا (ظلال بلا وجوه) =================
function coatFigure({ coat, collar, hat, brim, shadow, rim, extra = '' , hatShape = 'fedora' }) {
  const hats = {
    fedora: `<path d="M74 66 Q76 34 100 32 Q124 34 126 66 Z" fill="${hat}"/><path d="M84 40 Q100 48 116 40" stroke="${shadow}" stroke-width="3" fill="none"/><rect x="74" y="58" width="52" height="8" fill="${shadow}"/><ellipse cx="100" cy="67" rx="44" ry="8.5" fill="${brim}"/>`,
    trilby: `<path d="M78 66 Q80 40 100 38 Q120 40 122 66 Z" fill="${hat}"/><rect x="78" y="58" width="44" height="7" fill="${rim}" opacity=".6"/><path d="M62 70 Q100 58 138 66 L136 70 Q100 64 64 74 Z" fill="${brim}"/>`,
    cap: `<path d="M78 70 Q80 50 102 48 Q124 50 124 66 Q104 62 78 70 Z" fill="${hat}"/><path d="M118 64 Q134 64 142 70 Q128 72 118 70 Z" fill="${brim}"/>`,
    none: `<path d="M80 74 Q80 52 100 50 Q120 52 120 74 Q110 62 100 64 Q90 62 80 74 Z" fill="${hat}"/>`,
  };
  return `
    <path d="M38 240 L50 152 Q56 118 80 108 L100 130 L120 108 Q144 118 150 152 L162 240 Z" fill="${coat}"/>
    <path d="M80 108 L94 146 L100 130 Z M120 108 L106 146 L100 130 Z" fill="${collar}"/>
    <path d="M100 130 L100 240" stroke="${shadow}" stroke-width="2" opacity=".6"/>
    <rect x="91" y="90" width="18" height="22" fill="${shadow}"/>
    <ellipse cx="100" cy="80" rx="20" ry="23" fill="${shadow}"/>
    ${hats[hatShape]}
    <path d="M150 152 L162 240" stroke="${rim}" stroke-width="2" opacity=".85" fill="none"/>
    <path d="M120 108 Q144 118 150 152" stroke="${rim}" stroke-width="2" opacity=".85" fill="none"/>
    ${extra}`;
}

export function mafiaRoleArt(role) {
  const g = uid('mg');
  const bg = {
    mafia: ['#3a0b0e', '#0c0d12'],
    detective: ['#3d3420', '#0c0f14'],
    doctor: ['#0f3a38', '#0b1014'],
    civilian: ['#2a2f3b', '#0c0f14'],
  }[role];
  const fig = {
    mafia: coatFigure({ coat: '#07080b', collar: '#16181f', hat: '#0b0c10', brim: '#050608', shadow: '#030304', rim: '#b3191f',
      extra: `<rect x="112" y="98" width="18" height="4" rx="1.5" fill="#d9c9a8"/><circle cx="131" cy="100" r="3.2" fill="#ff4b2b"><animate attributeName="opacity" values="1;.45;1" dur="2.4s" repeatCount="indefinite"/></circle><path d="M132 96 Q140 84 132 74 Q126 64 136 54" stroke="#9aa0ab" stroke-width="2" fill="none" opacity=".35"/>` }),
    detective: coatFigure({ coat: '#2a2a24', collar: '#3a382f', hat: '#33302a', brim: '#1e1c18', shadow: '#0b0b0a', rim: '#e8c46a', hatShape: 'trilby',
      extra: `<circle cx="146" cy="176" r="16" fill="rgba(232,196,106,.15)" stroke="#e8c46a" stroke-width="4"/><path d="M134 188 L118 206" stroke="#7a5b2e" stroke-width="7" stroke-linecap="round"/>` }),
    doctor: coatFigure({ coat: '#d9e4e3', collar: '#b9cccb', hat: '#0f1414', brim: '#0f1414', shadow: '#0e1313', rim: '#5fd3c4', hatShape: 'none',
      extra: `<rect x="122" y="182" width="40" height="28" rx="5" fill="#1d4f4b"/><path d="M136 190 h12 M142 184 v12" stroke="#e9fffb" stroke-width="4" stroke-linecap="round"/><path d="M134 182 q8 -10 16 0" stroke="#1d4f4b" stroke-width="4" fill="none"/>` }),
    civilian: coatFigure({ coat: '#3b4150', collar: '#4c5466', hat: '#262a33', brim: '#1b1e25', shadow: '#0d0f13', rim: '#c9d1e0', hatShape: 'cap',
      extra: `<path d="M84 110 Q100 124 116 110 L116 120 Q100 132 84 120 Z" fill="#7a3b3b"/>` }),
  }[role];
  return `<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">
    <defs>
      <radialGradient id="${g}" cx="50%" cy="20%" r="85%"><stop offset="0" stop-color="${bg[0]}"/><stop offset="1" stop-color="${bg[1]}"/></radialGradient>
      <linearGradient id="${g}f" x1="0" y1="0" x2="0" y2="1"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".85"/></linearGradient>
    </defs>
    <rect width="200" height="240" fill="url(#${g})"/>
    <g opacity=".22" fill="#000">
      <rect x="0" y="150" width="26" height="90"/><rect x="24" y="128" width="20" height="112"/><rect x="160" y="140" width="22" height="100"/><rect x="180" y="118" width="20" height="122"/>
    </g>
    ${fig}
    <rect width="200" height="240" fill="url(#${g}f)"/>
  </svg>`;
}

export function mafiaBackArt() {
  const g = uid('mb');
  return `<svg viewBox="0 0 200 280" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs><linearGradient id="${g}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c9ad7c"/><stop offset="1" stop-color="#9c8152"/></linearGradient>
    <pattern id="${g}p" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 8 L8 0" stroke="#000" stroke-opacity=".05"/></pattern></defs>
    <rect width="200" height="280" fill="url(#${g})"/><rect width="200" height="280" fill="url(#${g}p)"/>
    <path d="M0 26 H70 L82 10 H200 V0 H0 Z" fill="#b39765"/>
    <rect x="16" y="40" width="168" height="224" rx="6" fill="none" stroke="#5b4626" stroke-opacity=".5" stroke-dasharray="4 5"/>
    <g transform="translate(100 138) rotate(-14)">
      <rect x="-74" y="-26" width="148" height="52" rx="6" fill="none" stroke="#8e1a1a" stroke-width="5"/>
      <text x="0" y="12" text-anchor="middle" font-family="Rakkas, serif" font-size="34" fill="#8e1a1a">سري للغاية</text>
    </g>
    <g fill="#2b2113" opacity=".75"><rect x="34" y="200" width="90" height="5" rx="2"/><rect x="34" y="214" width="120" height="5" rx="2"/><rect x="34" y="228" width="70" height="5" rx="2"/></g>
    <circle cx="160" cy="214" r="18" fill="none" stroke="#2b2113" stroke-opacity=".5" stroke-width="2"/><path d="M152 214 q8 -14 16 0 q-8 14 -16 0" fill="#2b2113" opacity=".4"/>
  </svg>`;
}

// خلفية المدينة الليلية (مؤثر محيطي — يُعطّل في وضع الأداء)
export function mafiaAmbient() {
  const g = uid('ma');
  let wins = '';
  const bld = [[0, 300, 70], [60, 240, 60], [112, 330, 46], [150, 210, 70], [214, 280, 52], [260, 190, 64], [318, 300, 50], [362, 230, 68], [424, 290, 60], [478, 200, 70], [540, 260, 60]];
  let blocks = '';
  bld.forEach(([x, y, w], k) => {
    blocks += `<rect x="${x}" y="${y}" width="${w}" height="${600 - y}" fill="#06080c"/>`;
    for (let yy = y + 16; yy < 560; yy += 26) for (let xx = x + 8; xx < x + w - 10; xx += 16) {
      if (((xx * 7 + yy * 3 + k * 11) % 9) < 2) wins += `<rect x="${xx}" y="${yy}" width="6" height="9" fill="#e8b45a" opacity="${0.35 + ((xx + yy) % 5) / 10}"/>`;
    }
  });
  return `<svg class="ambient" viewBox="0 0 600 600" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <linearGradient id="${g}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d1118"/><stop offset=".7" stop-color="#2a0d10"/><stop offset="1" stop-color="#090b10"/></linearGradient>
      <radialGradient id="${g}m"><stop offset="0" stop-color="#f3e6d0"/><stop offset=".6" stop-color="#e9d2b0"/><stop offset="1" stop-color="#e9d2b0" stop-opacity="0"/></radialGradient>
      <linearGradient id="${g}f" x1="0" x2="1"><stop offset="0" stop-color="#9aa3b5" stop-opacity="0"/><stop offset=".5" stop-color="#9aa3b5" stop-opacity=".18"/><stop offset="1" stop-color="#9aa3b5" stop-opacity="0"/></linearGradient>
    </defs>
    <rect width="600" height="600" fill="url(#${g})"/>
    <circle cx="470" cy="110" r="70" fill="url(#${g}m)" opacity=".85"/>
    <circle cx="470" cy="110" r="44" fill="#f1e2c6"/>
    ${blocks}${wins}
    <g class="fog"><rect x="-300" y="430" width="1200" height="70" fill="url(#${g}f)"/><rect x="-200" y="500" width="1200" height="90" fill="url(#${g}f)"/></g>
  </svg>`;
}

// ================= الجمجمة: أقراص فاخرة =================
export function discArt(kind) {
  const g = uid('d');
  if (kind === 'back') return `<svg viewBox="0 0 100 100" aria-hidden="true">
    <defs><radialGradient id="${g}" cx="40%" cy="35%"><stop offset="0" stop-color="#4a2430"/><stop offset="1" stop-color="#1c0c12"/></radialGradient></defs>
    <circle cx="50" cy="50" r="49" fill="url(#${g})"/><circle cx="50" cy="50" r="45" fill="none" stroke="#c9a14a" stroke-width="2"/>
    <circle cx="50" cy="50" r="40" fill="none" stroke="#c9a14a" stroke-width=".8" stroke-dasharray="2 3"/>
    <g fill="none" stroke="#c9a14a" stroke-width="1.6"><rect x="34" y="34" width="32" height="32"/><rect x="34" y="34" width="32" height="32" transform="rotate(45 50 50)"/></g>
    <circle cx="50" cy="50" r="6" fill="#c9a14a"/></svg>`;
  if (kind === 'rose') return `<svg viewBox="0 0 100 100" aria-hidden="true">
    <defs><radialGradient id="${g}" cx="45%" cy="38%"><stop offset="0" stop-color="#2a2a22"/><stop offset="1" stop-color="#0e0e0b"/></radialGradient></defs>
    <circle cx="50" cy="50" r="49" fill="url(#${g})"/><circle cx="50" cy="50" r="45" fill="none" stroke="#c9a14a" stroke-width="1.5"/>
    <path d="M50 64 L50 86" stroke="#4f7a3a" stroke-width="3"/><path d="M50 76 Q38 70 34 78 Q44 82 50 78" fill="#4f7a3a"/>
    <path d="M30 46 Q30 24 50 22 Q70 24 70 46 Q70 64 50 66 Q30 64 30 46Z" fill="#a3122a"/>
    <path d="M50 30 Q62 32 60 44 Q58 54 48 52 Q40 50 42 42 Q44 36 52 38 Q56 40 54 44" fill="none" stroke="#f4b6b0" stroke-width="2.4" stroke-linecap="round"/>
    <path d="M32 44 Q40 58 50 58 Q62 58 68 44" fill="none" stroke="#6e0b1c" stroke-width="2"/></svg>`;
  return `<svg viewBox="0 0 100 100" aria-hidden="true">
    <defs><radialGradient id="${g}" cx="45%" cy="38%"><stop offset="0" stop-color="#2a2a22"/><stop offset="1" stop-color="#0e0e0b"/></radialGradient></defs>
    <circle cx="50" cy="50" r="49" fill="url(#${g})"/><circle cx="50" cy="50" r="45" fill="none" stroke="#c9a14a" stroke-width="1.5"/>
    <path d="M28 46 Q28 20 50 20 Q72 20 72 46 Q72 56 64 60 L64 70 L36 70 L36 60 Q28 56 28 46Z" fill="#eee6d3"/>
    <ellipse cx="40" cy="47" rx="7.5" ry="8.5" fill="#15130f"/><ellipse cx="60" cy="47" rx="7.5" ry="8.5" fill="#15130f"/>
    <path d="M50 54 L46 62 L54 62Z" fill="#15130f"/>
    <g stroke="#15130f" stroke-width="2"><path d="M42 64 V71 M48 64 V71 M54 64 V71 M60 64 V71"/></g>
    <path d="M36 74 L64 74" stroke="#eee6d3" stroke-width="3" stroke-linecap="round"/></svg>`;
}

// ================= برا السالفة =================
export function baraBackArt() {
  const g = uid('bb');
  let marks = '';
  const glyphs = ['؟', '!', '؟', '…'];
  for (let y = 20; y < 280; y += 44) for (let x = 14 + ((y / 44) % 2) * 22; x < 200; x += 44)
    marks += `<text x="${x}" y="${y}" font-family="Marhey" font-size="26" fill="#fff" opacity=".22" transform="rotate(${(x + y) % 30 - 15} ${x} ${y})">${glyphs[(x + y) % 4]}</text>`;
  return `<svg viewBox="0 0 200 280" aria-hidden="true">
    <defs><linearGradient id="${g}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff7a59"/><stop offset="1" stop-color="#ffb627"/></linearGradient></defs>
    <rect width="200" height="280" fill="url(#${g})"/>${marks}
    <circle cx="100" cy="140" r="52" fill="#fff"/>
    <path d="M78 176 L70 196 L92 182Z" fill="#fff"/>
    <text x="100" y="134" text-anchor="middle" font-family="Marhey" font-weight="700" font-size="25" fill="#e8513a">برا</text>
    <text x="100" y="164" text-anchor="middle" font-family="Marhey" font-weight="700" font-size="25" fill="#e8513a">السالفة</text>
  </svg>`;
}

export function baraOutsiderArt() {
  const fig = (x, y, c, s = 1) => `<g transform="translate(${x} ${y}) scale(${s})"><circle cx="0" cy="-22" r="11" fill="${c}"/><path d="M-16 12 Q-16 -8 0 -8 Q16 -8 16 12 Z" fill="${c}"/></g>`;
  let ring = '';
  const cols = ['#2ec4b6', '#3a86ff', '#8338ec', '#06d6a0', '#ef476f', '#118ab2'];
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * Math.PI * 2;
    ring += fig(78 + Math.cos(a) * 44, 120 + Math.sin(a) * 30, cols[k], .9);
  }
  return `<svg viewBox="0 0 200 200" aria-hidden="true">
    <ellipse cx="78" cy="132" rx="62" ry="40" fill="#fff" opacity=".35"/>
    ${ring}
    ${fig(162, 140, '#1d1d1d', 1.15)}
    <g transform="translate(168 72)"><path d="M-22 -18 h44 a8 8 0 0 1 8 8 v22 a8 8 0 0 1 -8 8 h-28 l-12 10 v-10 h-4 a8 8 0 0 1 -8 -8 v-22 a8 8 0 0 1 8 -8z" fill="#fff"/>
    <text x="0" y="8" text-anchor="middle" font-family="Marhey" font-weight="700" font-size="28" fill="#e8513a">؟</text></g>
  </svg>`;
}

// ================= أغلفة المكتبة (أصلية) =================
const coverBase = (bg1, bg2, body) => {
  const g = uid('c');
  return `<svg viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs><linearGradient id="${g}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${bg1}"/><stop offset="1" stop-color="${bg2}"/></linearGradient></defs>
    <rect width="300" height="400" fill="url(#${g})"/>${body}</svg>`;
};

export const COVERS = {
  mafia: () => coverBase('#121722', '#3a0c10', `
    <circle cx="220" cy="80" r="38" fill="#f1e2c6"/><circle cx="220" cy="80" r="60" fill="#f1e2c6" opacity=".12"/>
    <g fill="#05070a"><rect x="0" y="230" width="50" height="170"/><rect x="44" y="190" width="40" height="210"/><rect x="230" y="210" width="70" height="190"/><rect x="200" y="250" width="40" height="150"/></g>
    <g fill="#e8b45a" opacity=".6"><rect x="54" y="210" width="6" height="9"/><rect x="68" y="240" width="6" height="9"/><rect x="246" y="230" width="6" height="9"/><rect x="262" y="262" width="6" height="9"/><rect x="12" y="250" width="6" height="9"/></g>
    <g transform="translate(50 150) scale(1)">${coatFigure({ coat: '#020305', collar: '#101218', hat: '#06070a', brim: '#020305', shadow: '#000', rim: '#c4161d' })}</g>`),
  skull: () => coverBase('#2a0f18', '#0e0608', `
    <g transform="translate(40 110) scale(1.5)">${discArt('back')}</g>
    <g transform="translate(130 150) scale(1.3)">${discArt('skull')}</g>
    <g transform="translate(70 230) scale(1.1)">${discArt('rose')}</g>`),
  bara: () => coverBase('#ffb627', '#ff6b4a', `<g transform="translate(20 80) scale(1.35)">${baraOutsiderArt()}</g>`),
  familyfeud: () => coverBase('#0a1f6b', '#05103a', `
    <g>${[0, 1, 2, 3].map(k => `<rect x="40" y="${90 + k * 46}" width="220" height="38" rx="6" fill="#123aa8" stroke="#ffd34d" stroke-width="2"/><circle cx="66" cy="${109 + k * 46}" r="13" fill="#ffd34d"/><text x="66" y="${115 + k * 46}" text-anchor="middle" font-family="Lalezar" font-size="18" fill="#05103a">${['١', '٢', '٣', '٤'][k]}</text>`).join('')}</g>
    ${Array.from({ length: 14 }, (_, k) => `<circle cx="${20 + k * 20}" cy="40" r="5" fill="#ffd34d" opacity="${k % 2 ? .9 : .4}"/>`).join('')}
    <text x="150" y="330" text-anchor="middle" font-family="Lalezar" font-size="64" fill="#e63946">✕</text>`),
  avalon: () => coverBase('#2b1a4a', '#120a22', `
    <path d="M150 90 L220 120 Q220 230 150 280 Q80 230 80 120 Z" fill="#3c2a63" stroke="#d6b25e" stroke-width="5"/>
    <path d="M118 150 L130 128 L150 146 L170 128 L182 150 L182 170 L118 170Z" fill="#d6b25e"/>
    <path d="M150 182 L150 262" stroke="#e9e3d0" stroke-width="6"/><path d="M134 196 H166" stroke="#d6b25e" stroke-width="6"/>`),
  werewolf: () => coverBase('#0c1a2a', '#04080d', `
    <circle cx="150" cy="140" r="78" fill="#e9eef2"/><circle cx="130" cy="120" r="12" fill="#cfd8de"/><circle cx="175" cy="160" r="8" fill="#cfd8de"/>
    <path d="M118 210 L132 150 L144 176 L160 132 L170 168 L198 150 L184 214 Z" fill="#05080c"/>
    ${[0, 1, 2, 3, 4, 5].map(k => `<path d="M${k * 60 - 10} 400 L${k * 60 + 20} ${250 + (k % 3) * 20} L${k * 60 + 50} 400Z" fill="#06100a"/>`).join('')}`),
  coup: () => coverBase('#4a1020', '#1a0509', `
    <path d="M90 160 L100 110 L125 140 L150 96 L175 140 L200 110 L210 160Z" fill="#e3b24f"/>
    <rect x="90" y="160" width="120" height="16" fill="#c99a3b"/>
    ${[0, 1, 2].map(k => `<circle cx="${110 + k * 40}" cy="${280 - k * 10}" r="22" fill="#e3b24f" stroke="#8c6420" stroke-width="3"/>`).join('')}
    <g fill="#e3b24f" opacity=".25">${[0, 1, 2, 3].map(k => `<rect x="${40 + k * 62}" y="200" width="16" height="200"/>`).join('')}</g>`),
  secret: () => coverBase('#2b2d33', '#15161a', `
    <path d="M70 170 Q150 90 230 170 Z" fill="#4a4d55"/><rect x="66" y="170" width="168" height="10" fill="#5a5e68"/>
    ${[0, 1, 2, 3, 4].map(k => `<rect x="${80 + k * 32}" y="184" width="12" height="80" fill="#5a5e68"/>`).join('')}
    <rect x="60" y="264" width="180" height="12" fill="#5a5e68"/>
    <g transform="translate(110 300) rotate(-8)"><rect width="46" height="64" rx="4" fill="#3d6fa8"/></g>
    <g transform="translate(150 296) rotate(9)"><rect width="46" height="64" rx="4" fill="#b5523f"/></g>`),
  deception: () => coverBase('#1d2b2a', '#0b1110', `
    <rect x="70" y="80" width="160" height="210" rx="6" fill="#d8cba7" transform="rotate(-6 150 185)"/>
    <circle cx="140" cy="170" r="38" fill="none" stroke="#2c2c2c" stroke-width="3" opacity=".5"/>
    ${[0, 1, 2, 3, 4].map(k => `<path d="M${118 - k * 4} 170 Q140 ${140 - k * 6} ${162 + k * 4} 170" fill="none" stroke="#2c2c2c" stroke-width="2" opacity=".5"/>`).join('')}
    <circle cx="190" cy="250" r="34" fill="none" stroke="#e1b84b" stroke-width="7"/><path d="M214 274 L246 306" stroke="#7a5b2e" stroke-width="12" stroke-linecap="round"/>`),
  kittens: () => coverBase('#ffde59', '#ff8e3c', `
    <path d="M90 150 L104 104 L128 140 Q150 132 172 140 L196 104 L210 150 Q226 200 196 236 Q150 270 104 236 Q74 200 90 150Z" fill="#fff" stroke="#2b2b2b" stroke-width="5"/>
    <circle cx="128" cy="180" r="9" fill="#2b2b2b"/><circle cx="172" cy="180" r="9" fill="#2b2b2b"/><path d="M142 204 Q150 212 158 204" stroke="#2b2b2b" stroke-width="4" fill="none"/>
    <circle cx="210" cy="300" r="34" fill="#2b2b2b"/><path d="M226 268 Q236 250 250 254" stroke="#2b2b2b" stroke-width="5" fill="none"/><path d="M250 254 l8 -8 m-8 8 l10 2 m-10 -2 l2 -10" stroke="#ff3b3b" stroke-width="4"/>`),
  wavelength: () => coverBase('#1b1f3b', '#0b0d1c', `
    <path d="M40 260 A110 110 0 0 1 260 260 Z" fill="#232a55"/>
    <path d="M150 260 L96 166 A110 110 0 0 1 128 152 Z" fill="#ff5d73"/><path d="M150 260 L128 152 A110 110 0 0 1 172 152 Z" fill="#ffd166"/><path d="M150 260 L172 152 A110 110 0 0 1 204 166 Z" fill="#06d6a0"/>
    <path d="M150 260 L222 180" stroke="#fff" stroke-width="6" stroke-linecap="round"/><circle cx="150" cy="260" r="12" fill="#fff"/>`),
  herd: () => coverBase('#7bdff2', '#b2f7ef', `
    ${[[80, 170], [150, 150], [220, 175], [110, 240], [190, 240]].map(([x, y], k) => `<g transform="translate(${x} ${y})"><circle r="30" fill="${k === 4 ? '#ff70a6' : '#fff'}" stroke="#2b2d42" stroke-width="3"/><ellipse cx="0" cy="-30" rx="10" ry="6" fill="#2b2d42"/><rect x="-16" y="26" width="6" height="16" fill="#2b2d42"/><rect x="10" y="26" width="6" height="16" fill="#2b2d42"/></g>`).join('')}`),
  shareef: () => coverBase('#7a4a1e', '#3a210c', `
    <rect x="60" y="150" width="120" height="100" rx="6" fill="#b5793a" stroke="#5a3510" stroke-width="5"/><path d="M60 200 H180 M120 150 V250" stroke="#5a3510" stroke-width="4"/>
    <path d="M170 260 Q160 200 200 190 Q240 200 232 260 Z" fill="#d8b46a" stroke="#6b4a1c" stroke-width="4"/>
    <circle cx="200" cy="300" r="20" fill="#a31d1d"/><path d="M190 300 h20 M200 290 v20" stroke="#ffd" stroke-width="3"/>`),
  letters: () => {
    const L = ['ب', 'ج', 'س', 'ع', 'ق', 'م', 'ر', 'ن', 'ه'];
    const hex = (cx, cy, r, f) => `<polygon points="${[0, 1, 2, 3, 4, 5].map(k => { const a = Math.PI / 3 * k + Math.PI / 6; return (cx + r * Math.cos(a)).toFixed(1) + ',' + (cy + r * Math.sin(a)).toFixed(1); }).join(' ')}" fill="${f}" stroke="#fff" stroke-width="3"/>`;
    let s = ''; let k = 0;
    for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) {
      const cx = 80 + col * 70 + (row % 2) * 35, cy = 130 + row * 62;
      s += hex(cx, cy, 38, ['#ff8800', '#2bb673', '#ffffff'][(row + col) % 3]) + `<text x="${cx}" y="${cy + 12}" text-anchor="middle" font-family="Lalezar" font-size="34" fill="#1a1a2e">${L[k++]}</text>`;
    }
    return coverBase('#3a0ca3', '#7209b7', s);
  },
  monopoly: () => coverBase('#d9efe0', '#a8d5ba', `
    <rect x="40" y="70" width="220" height="220" fill="#f6fbf7" stroke="#1d3b2a" stroke-width="4"/>
    ${[0, 1, 2, 3, 4].map(k => `<rect x="${40 + k * 44}" y="70" width="44" height="14" fill="${['#c0392b', '#e67e22', '#f1c40f', '#27ae60', '#2980b9'][k]}"/>`).join('')}
    <rect x="80" y="110" width="140" height="140" fill="#cfe8d8"/>
    <g transform="translate(110 150) rotate(-12)"><rect width="44" height="44" rx="8" fill="#fff" stroke="#1d3b2a" stroke-width="3"/><circle cx="12" cy="12" r="4"/><circle cx="32" cy="32" r="4"/><circle cx="22" cy="22" r="4"/></g>
    <path d="M178 200 l16 -14 l16 14 v18 h-32z" fill="#2e7d32"/>`),
};

// واجهة القطط المتفجرة — ألوان مرحة، رسوم قطط أصلية، ويد بطاقات مروحية
import { ar, esc } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, timerHtml, winnerBanner, act, toggleSel } from '../kit.js';
import { burst, flash, shake, vibrate } from '../../core/effects.js';

export const theme = 'kittens';
export const kit = 'pop';
export const ambient = () => '';

export const CARDS = {
  bomb: ['القطة المتفجرة', 'انفجرت! إلا إذا عندك إبطال', '#2b2b2b'],
  defuse: ['إبطال', 'يوقف الانفجار', '#57b94a'],
  attack: ['هجوم', 'أنهِ دورك؛ التالي يلعب دورين', '#ff7043'],
  skip: ['تخطٍّ', 'أنهِ دورك بلا سحب', '#42a5f5'],
  favor: ['طلب خدمة', 'لاعب يعطيك بطاقة', '#ab47bc'],
  shuffle: ['خلط', 'اخلط الكومة', '#8d6e63'],
  future: ['استبصار', 'شاهد أعلى ٣ بطاقات', '#ec407a'],
  nope: ['لا!', 'ألغِ أي فعل', '#e53935'],
  cat1: ['قط الشماغ', 'اجمع زوجًا للسرقة', '#ffb300'], cat2: ['قط الكبسة', 'اجمع زوجًا للسرقة', '#fb8c00'],
  cat3: ['قط الدلّة', 'اجمع زوجًا للسرقة', '#26a69a'], cat4: ['قط الفلافل', 'اجمع زوجًا للسرقة', '#7cb342'], cat5: ['قط المكيّف', 'اجمع زوجًا للسرقة', '#5c6bc0'],
};
function cat(color, extra = '') {
  return `<svg viewBox="0 0 120 120"><circle cx="60" cy="62" r="40" fill="${color}"/><path d="M28 40 L34 12 L52 30 Z M92 40 L86 12 L68 30 Z" fill="${color}"/><circle cx="46" cy="58" r="6" fill="#222"/><circle cx="74" cy="58" r="6" fill="#222"/><path d="M54 74 Q60 80 66 74" stroke="#222" stroke-width="3" fill="none"/>${extra}</svg>`;
}
const ART = {
  bomb: `<svg viewBox="0 0 120 120"><circle cx="60" cy="70" r="36" fill="#222"/><path d="M60 34 Q70 16 88 18" stroke="#8d6e63" stroke-width="5" fill="none"/><circle cx="90" cy="16" r="8" fill="#ffca28"/><path d="M34 46 L40 26 L52 40Z M86 46 L80 26 L68 40Z" fill="#222"/><circle cx="48" cy="66" r="6" fill="#ff5252"/><circle cx="72" cy="66" r="6" fill="#ff5252"/></svg>`,
  defuse: cat('#57b94a', '<rect x="40" y="88" width="40" height="10" rx="4" fill="#fff"/>'),
  nope: `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="44" fill="#fff"/><circle cx="60" cy="60" r="38" fill="#e53935"/><rect x="30" y="52" width="60" height="16" rx="6" fill="#fff"/></svg>`,
};
const cardArt = c => ART[c] || cat(CARDS[c][2], c === 'attack' ? '<path d="M30 96 L90 96" stroke="#fff" stroke-width="6"/>' : c === 'future' ? '<circle cx="60" cy="100" r="8" fill="#fff"/>' : '');
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" rx="16" fill="#ff8e3c"/><rect x="14" y="14" width="172" height="252" rx="12" fill="#fff3c4"/><text x="100" y="155" text-anchor="middle" font-size="64">🐾</text></svg>`;
export function kcard(c, { attrs = '', size = 'sm', cls = '' } = {}) {
  const [n, d, col] = CARDS[c];
  return card({ cls: `k-card ${size} ${cls}`, back: back(), front: `<div class="cf" style="--kc:${col}"><div class="cf-head"><span class="cf-type">${n}</span></div><div class="cf-art">${cardArt(c)}</div><p class="cf-desc">${d}</p></div>`, flipped: true, attrs });
}

const needsTarget = sel => {
  if (sel.length === 1) return sel[0] === 'favor';
  if (sel.length === 2 || sel.length === 3) return sel.every(c => c === sel[0]);
  return false;
};
function comboLabel(sel) {
  if (sel.length === 1 && ['attack', 'skip', 'favor', 'shuffle', 'future'].includes(sel[0])) return 'العب ' + CARDS[sel[0]][0];
  if (sel.length === 2 && sel[0] === sel[1] && !['defuse', 'nope'].includes(sel[0])) return 'زوج: اسرق بطاقة عشوائية';
  if (sel.length === 3 && sel.every(c => c === sel[0]) && sel[0] !== 'defuse') return 'ثلاثية: اطلب بطاقة بالاسم';
  if (sel.length === 5 && new Set(sel).size === 5) return 'خمس مختلفة: خذ من المهملات';
  return null;
}

export const screenKey = v => [v.phase, v.turn, v.turnsLeft, v.players.filter(p => p.alive).length].join(':');

export function render(ctx) {
  const v = ctx.view, me = v.me;
  let h = `<div class="k-top"><div class="k-pile">${card({ cls: 'k-card xs', back: back(), front: '', flipped: false })}<span>${ar(v.deck)}</span></div>
    <div class="row wrap" style="gap:6px;flex:1">${v.players.map(p => chip(ctx, p.id, ` • ${ar(p.count)}${p.alive ? '' : ' 💥'}`, p.id === v.turn ? 'ok' : p.alive ? '' : 'off')).join('')}</div>
    ${v.discardTop ? `<div class="k-pile">${kcard(v.discardTop, { size: 'xs' })}</div>` : ''}</div>`;
  if (v.last) {
    const L = v.last;
    const t = L.type === 'exploded' ? `💥 ${nm(ctx, L.who)} انفجر!` : L.type === 'noped' ? 'أُلغي الفعل بـ«لا!»' : `${nm(ctx, L.who)} لعب ${L.kind === 'pair' ? 'زوجًا' : L.kind === 'triple' ? 'ثلاثية' : L.kind === 'five' ? 'خمس بطاقات' : CARDS[L.kind]?.[0] || ''}${L.target ? ' على ' + nm(ctx, L.target) : ''}${L.got === false ? ' — لم يجدها' : ''}`;
    h += `<p class="center soft" style="margin:6px 0">${t}</p>`;
  }
  if (me?.got) h += `<p class="center muted" style="font-size:14px;margin:0">آخر بطاقة وصلتك: <b>${CARDS[me.got][0]}</b></p>`;
  if (v.phase === 'over') return winnerBanner(`${esc(ctx.player(v.winner)?.name)} نجا من الانفجارات!`) + h;
  if (!me.alive) return h + panel('<p class="center" style="margin:0">💥 انفجرت — تابع البقية</p>');

  if (v.phase === 'nope') {
    const p = v.pending;
    h += panel(`<p class="center" style="margin:0">${nm(ctx, p.actor)} لعب <b>${comboLabel(p.cards) || ''}</b>${p.target ? ` على ${nm(ctx, p.target)}` : ''}${p.named ? ` (يطلب ${CARDS[p.named][0]})` : ''}<br>«لا!» حتى الآن: ${ar(p.nopes)}</p>`) + timerHtml(v.deadline);
    if (me.hand.includes('nope')) h += `<button class="btn danger block nope-btn" ${act({ type: 'nope' })}>لا! ✋</button>`;
  } else if (v.phase === 'defuse' && v.turn === ctx.me) {
    h += panel(`<p class="center h2" style="margin:0">أبطلتها! 😮‍💨</p><p class="center">ضع القطة سرًا في الكومة (٠ = الأعلى):</p>
      <input type="range" id="kpos" min="0" max="${v.deck}" value="${Math.min(v.deck, 3)}" data-fresh oninput="this.nextElementSibling.textContent=this.value"><p class="center"><b>${Math.min(v.deck, 3)}</b></p>
      <button class="btn block" data-act='{"type":"insert"}' data-input='{"position":"#kpos"}'>ضعها</button>`);
  } else if (v.phase === 'favor' && v.favorFrom === ctx.me) {
    h += `<p class="center h2">${nm(ctx, v.favorTo)} يطلب خدمة — اختر بطاقة تعطيها:</p><div class="k-hand">${me.hand.map((c, k) => `<button class="card-btn" ${act({ type: 'give', index: k })}>${kcard(c)}</button>`).join('')}</div>`;
    return h;
  } else if (v.phase === 'pickDiscard' && v.turn === ctx.me) {
    h += `<p class="center">اختر بطاقة من المهملات:</p><div class="k-hand">${v.discardSet.map(c => `<button class="card-btn" ${act({ type: 'pickDiscard', card: c })}>${kcard(c)}</button>`).join('')}</div>`;
    return h;
  } else if (v.phase !== 'play') h += wait(v.phase === 'favor' ? `${nm(ctx, v.favorFrom)} يختار بطاقة` : `دور ${nm(ctx, v.turn)}`);

  if (me.future) h += panel(`<p style="margin:0 0 6px">أعلى الكومة (الأول = التالي):</p><div class="row" style="gap:6px;justify-content:center">${me.future.map(c => kcard(c, { size: 'xs' })).join('')}</div>`, '', 'margin-top:8px');

  const myTurn = v.phase === 'play' && v.turn === ctx.me;
  const sel = (ctx.ui.sel || []).filter(k => k < me.hand.length);
  const selCards = sel.map(k => me.hand[k]);
  h += `<p class="center soft" style="margin:12px 0 4px">${myTurn ? `دورك${v.turnsLeft > 1 ? ` (متبقٍ ${ar(v.turnsLeft)} أدوار)` : ''} — اختر بطاقات للعب أو اسحب` : 'يدك'}</p>`;
  h += `<div class="k-hand">${me.hand.map((c, k) => `<button class="card-btn ${sel.includes(k) ? 'sel' : ''}" data-ui="sel" data-k="${k}" ${myTurn ? '' : 'disabled'}>${kcard(c)}</button>`).join('')}</div>`;
  if (myTurn) {
    const label = comboLabel(selCards);
    if (label) {
      const base = selCards.length === 1 ? { type: 'play', card: selCards[0] } : { type: 'play', cards: selCards };
      if (needsTarget(selCards)) {
        if (selCards.length === 3) h += `<div class="field"><label>اسم البطاقة المطلوبة</label><select id="knamed">${Object.keys(CARDS).filter(c => c !== 'bomb').map(c => `<option value="${c}">${CARDS[c][0]}</option>`).join('')}</select></div>`;
        h += `<p class="center">${label} — اختر اللاعب:</p><div class="target-list">${v.players.filter(p => p.alive && p.id !== ctx.me && p.count > 0).map(p => `<button class="target" ${act({ ...base, target: p.id })} ${selCards.length === 3 ? `data-input='{"named":"#knamed"}'` : ''}>${chip(ctx, p.id)}</button>`).join('')}</div>`;
      } else h += btn(label, base, 'block');
    } else if (sel.length) h += `<p class="center muted">هذه المجموعة لا تُلعب</p>`;
    h += `<div style="margin-top:10px">${btn('اسحب وأنهِ الدور 🃏', { type: 'draw' }, sel.length ? 'soft block' : 'block')}</div>`;
  }
  return h;
}

export function onUi(name, el, ctx, rerender) {
  if (name === 'sel') { toggleSel(ctx, 'sel', Number(el.dataset.k), 5); ctx.sfx('tap'); rerender(); }
}
export function onAct(a, ctx) { ctx.ui.sel = []; }
export function onFx(e, ctx) {
  const m = { draw: 'flip', played: 'bid', nope: 'buzz', noped: 'wrong', attack: 'boom', shuffle: 'dice', future: 'secret', steal: 'coin', miss: 'wrong', defused: 'correct' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'bomb') { ctx.sfx('tick'); vibrate([60, 40, 60]); }
  if (e.kind === 'exploded') { ctx.sfx('boom'); flash('#ff5722'); shake(); }
  if (e.kind === 'game-over') { if (e.who === ctx.me) { ctx.sfx('win'); burst(['#ff8e3c', '#ffd54f', '#57b94a']); } else ctx.sfx('lose'); }
}

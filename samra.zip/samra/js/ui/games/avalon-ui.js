// واجهة أفالون — بلاط ملكي، دروع وشعارات
import { ar, openSheet } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, roleFront, revealStep, flipReveal, toggleSel, voteRow, winnerBanner, act } from '../kit.js';
import { burst } from '../../core/effects.js';

export const theme = 'avalon';
export const kit = 'luxe';
export const ambient = () => '';

const ROLE = {
  merlin: ['ميرلين', 'أهل الخير', 'تعرف الأشرار. ساعد الخير دون أن تنكشف للقاتل.'],
  percival: ['برسيفال', 'أهل الخير', 'ترى ميرلين (ومعه مورغانا إن وُجدت). احمِه.'],
  servant: ['خادم مخلص', 'أهل الخير', 'أنجح المهمات واكشف الأشرار.'],
  assassin: ['القاتل', 'الأشرار', 'أفشل المهمات، وفي النهاية اغتل ميرلين.'],
  morgana: ['مورغانا', 'الأشرار', 'تظهرين لبرسيفال كأنك ميرلين.'],
  mordred: ['موردريد', 'الأشرار', 'ميرلين لا يعرفك.'],
  oberon: ['أوبرون', 'الأشرار', 'لا تعرف الأشرار ولا يعرفونك.'],
  minion: ['تابع الشر', 'الأشرار', 'أفشل المهمات دون أن تنكشف.'],
};
const isEvil = r => ['assassin', 'morgana', 'mordred', 'oberon', 'minion'].includes(r);

function emblem(evil) {
  return `<svg viewBox="0 0 120 140" aria-hidden="true"><path d="M60 8 L108 26 Q108 96 60 132 Q12 96 12 26 Z" fill="${evil ? '#5b1020' : '#1f3d7a'}" stroke="#d6b25e" stroke-width="5"/>
    ${evil ? '<path d="M40 50 L80 90 M80 50 L40 90" stroke="#d6b25e" stroke-width="8" stroke-linecap="round"/>' : '<path d="M44 60 L56 46 L60 58 L64 46 L76 60 L76 74 L44 74 Z" fill="#d6b25e"/><path d="M60 80 V112 M48 90 H72" stroke="#e9e3d0" stroke-width="6"/>'}</svg>`;
}
const back = () => `<svg viewBox="0 0 200 280" aria-hidden="true"><rect width="200" height="280" fill="#2b1a4a"/><rect x="12" y="12" width="176" height="256" rx="10" fill="none" stroke="#d6b25e" stroke-width="3"/><path d="M100 70 L140 88 Q140 160 100 196 Q60 160 60 88 Z" fill="#3c2a63" stroke="#d6b25e" stroke-width="4"/><circle cx="100" cy="130" r="14" fill="#d6b25e"/></svg>`;

function roleCard(role, flipped, attrs = '', size = '') {
  const [n, team, d] = ROLE[role];
  return card({ cls: `avalon-card ${size} ${isEvil(role) ? 'evil' : 'good'}`, back: back(), front: roleFront({ type: team, name: n, desc: d, art: emblem(isEvil(role)) }), flipped, attrs, hint: flipped ? '' : 'اضغط لكشف دورك' });
}

function knowsBlock(ctx, k) {
  if (!k || !k.ids.length) return '';
  return panel(`<p style="margin:0 0 6px"><b>${k.label}:</b></p><div class="row wrap" style="gap:6px">${k.ids.map(id => chip(ctx, id)).join('')}</div>`, '', 'margin-top:12px');
}

function track(v) {
  return `<div class="quest-track">${v.sizes.map((n, k) => {
    const r = v.results[k];
    return `<div class="quest ${r || ''} ${k === v.mission && !r ? 'now' : ''}"><span>${ar(n)}</span>${k === 3 && v.twoFails ? '<small>فشلان</small>' : ''}${r ? `<b>${r === 'success' ? '✓' : '✕'}</b>` : ''}</div>`;
  }).join('')}</div><p class="center muted" style="margin:4px 0 0;font-size:14px">رفض متتالي: ${ar(v.rejects)} / ٥</p>`;
}

export function headerExtra(ctx) {
  return ctx.view.me && ctx.view.phase !== 'reveal' && ctx.view.phase !== 'over' ? `<button class="icon-btn" data-ui="peek" aria-label="اعرض دوري">🛡️</button>` : '';
}
export const screenKey = v => [v.phase, v.mission, v.rejects].join(':');

export function render(ctx) {
  const v = ctx.view, me = v.me;
  if (v.phase === 'reveal') {
    return revealStep(ctx, { cardHtml: roleCard(me.role, !!ctx.ui.revealed, 'data-ui="reveal" role="button" tabindex="0"'), readyCount: v.players.filter(p => p.ready).length, total: v.players.length, ready: me.ready, after: knowsBlock(ctx, me.knows) });
  }
  let h = track(v);
  if (v.lastMission && v.phase !== 'over') {
    const m = v.lastMission;
    h += panel(`<p style="margin:0">المهمة ${ar(m.n)}: <b style="color:${m.success ? 'var(--ok)' : 'var(--danger)'}">${m.success ? 'نجحت' : 'فشلت'}</b> — بطاقات الفشل: ${ar(m.fails)}</p>`, 'center', 'margin-top:10px');
  }
  if (v.lastVote && v.phase === 'propose') {
    const lv = v.lastVote;
    h += `<details class="panel" style="margin-top:10px"><summary>آخر تصويت: <b>${lv.approved ? 'اعتُمد' : 'رُفض'}</b></summary>${lv.votes.map(x => `<div class="row spread"><span>${nm(ctx, x.id)}</span><span class="badge ${x.v === 'yes' ? 'ok' : 'off'}">${x.v === 'yes' ? 'موافق' : 'رافض'}</span></div>`).join('')}</details>`;
  }
  if (v.phase === 'propose') {
    const leader = v.leader === ctx.me;
    h += `<p class="center" style="margin:14px 0 8px">القائد: ${who(ctx, v.leader)} — يختار <b>${ar(v.size)}</b> لاعبين للمهمة ${ar(v.mission + 1)}</p>`;
    if (leader) {
      const sel = ctx.ui.team || [];
      h += targets(ctx, v.players.map(p => p.id), { ui: 'pick', selected: sel });
      h += `<div style="margin-top:12px">${btn(`أرسل الفريق (${ar(sel.length)}/${ar(v.size)})`, { type: 'propose', team: sel }, 'block', sel.length === v.size ? '' : 'disabled')}</div>`;
    } else h += wait('القائد يختار الفريق');
    return h;
  }
  if (v.phase === 'vote') {
    h += panel(`<p style="margin:0 0 6px">الفريق المقترح من ${nm(ctx, v.leader)}:</p><div class="row wrap" style="gap:6px">${v.team.map(id => chip(ctx, id)).join('')}</div>`, '', 'margin-top:12px');
    if (!me.vote) h += `<div class="row" style="margin-top:12px">${btn('موافق ✓', { type: 'vote', value: 'yes' }, 'grow-btn')}${btn('أرفض ✕', { type: 'vote', value: 'no' }, 'soft grow-btn')}</div>`;
    else h += wait(`صوّتّ: ${me.vote === 'yes' ? 'موافق' : 'رافض'} — بانتظار البقية`);
    return h + voteRow(ctx, v.players);
  }
  if (v.phase === 'mission') {
    h += panel(`<p style="margin:0 0 6px">فريق المهمة ${ar(v.mission + 1)}:</p><div class="row wrap" style="gap:6px">${v.team.map(id => chip(ctx, id, v.players.find(p => p.id === id).played ? ' ✓' : '')).join('')}</div>`, '', 'margin-top:12px');
    if (v.team.includes(ctx.me) && !me.card) {
      h += `<p class="center" style="margin:14px 0 8px">اختر بطاقتك سرًا:</p><div class="row">${btn('نجاح', { type: 'play', card: 'success' }, 'grow-btn')}${me.evil ? btn('فشل', { type: 'play', card: 'fail' }, 'danger grow-btn') : ''}</div>`;
      if (!me.evil) h += `<p class="center muted" style="font-size:14px">أهل الخير يلعبون «نجاح» دائمًا.</p>`;
    } else h += wait('المهمة جارية');
    return h;
  }
  if (v.phase === 'assassin') {
    h += `<p class="h2 center" style="margin:16px 0 6px">نجحت ثلاث مهمات!</p>`;
    const evilIds = me.evil ? (me.knows?.ids || []) : [];
    if (me.evil) h += knowsBlock(ctx, me.knows);
    if (me.role === 'assassin') h += `<p class="center">اختر من تظنه ميرلين (من أهل الخير):</p>` + targets(ctx, v.players.filter(p => p.id !== ctx.me && !evilIds.includes(p.id)).map(p => p.id), { action: 'assassinate' });
    else h += wait(me.evil ? 'تشاوروا — القاتل يختار ميرلين' : 'القاتل يبحث عن ميرلين');
    return h;
  }
  if (v.phase === 'over') {
    h = winnerBanner(v.winner === 'good' ? 'انتصر أهل الخير' : 'انتصر الأشرار', v.reason, v.winner === 'good' ? '#7fb2ff' : '#ff7a7a') + h;
    h += `<div class="reveal-grid" style="margin-top:16px">${v.players.map((p, k) => `<div>${roleCard(p.role, false, `data-stagger="${k}"`, 'sm')}<div class="who">${nm(ctx, p.id)}</div></div>`).join('')}</div>`;
  }
  return h;
}

export function after(root) {
  root.querySelectorAll('[data-stagger]').forEach(c => setTimeout(() => c.classList.add('is-flipped'), 250 + Number(c.dataset.stagger) * 150));
}

export function onUi(name, el, ctx, rerender) {
  if (flipReveal(name, el, ctx, rerender, 'reveal')) return;
  if (name === 'pick') { const ui = ctx.ui; ui.team ||= []; toggleSel(ctx, 'team', el.dataset.id, ctx.view.size); ctx.sfx('tap'); rerender(); }
  if (name === 'peek') openSheet(`<h2>دوري</h2>${roleCard(ctx.view.me.role, true)}${knowsBlock(ctx, ctx.view.me.knows)}<button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'دوري' });
}
export function onAct(a, ctx) { if (a.type === 'ready') ctx.ui.revealed = false; if (a.type === 'propose') ctx.ui.team = []; }
export function onFx(e, ctx) {
  const m = { proposed: 'bid', vote: 'tap', approved: 'rose', rejected: 'pass', 'mission-success': 'point', 'mission-fail': 'skull', phase: 'round' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'game-over') { const mine = ctx.view.me && (ctx.view.me.evil ? 'evil' : 'good'); if (mine === ctx.view.winner) { ctx.sfx('win'); burst(['#d6b25e', '#7fb2ff', '#fff']); } else ctx.sfx('lose'); }
}

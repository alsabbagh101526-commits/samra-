// واجهة شريف نوتنغهام — سوق خشبي وجلد وختم الشمع
import { ar, esc } from '../dom.js';
import { nm, who, chip, btn, wait, panel, card, toggleSel, winnerBanner, act } from '../kit.js';
import { burst, shake } from '../../core/effects.js';

export const theme = 'shareef';
export const kit = 'luxe';
export const ambient = () => '';

const G = {
  apple: ['تفاح', 2, 2, true, '#d64545', '🍎'], cheese: ['جبن', 3, 2, true, '#e8b93c', '🧀'], bread: ['خبز', 3, 2, true, '#c98b4a', '🍞'], chicken: ['دجاج', 4, 2, true, '#e7d6c1', '🍗'],
  pepper: ['فلفل', 6, 4, false, '#a8321e', '🌶️'], mead: ['شراب العسل', 7, 4, false, '#d99a2b', '🍯'], silk: ['حرير', 8, 4, false, '#7b4fa8', '🧵'], crossbow: ['قوس', 9, 4, false, '#4a4a4a', '🏹'],
};
const LEGAL = ['apple', 'cheese', 'bread', 'chicken'];
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" fill="#5a3415"/><circle cx="100" cy="140" r="40" fill="#a3231f"/><text x="100" y="152" text-anchor="middle" font-size="34" fill="#f3d9a4">ش</text></svg>`;
function good(g, { size = 'sm', attrs = '' } = {}) {
  const [n, v, p, legal, col, em] = G[g];
  return card({ cls: `sh-good ${size} ${legal ? '' : 'contra'}`, back: back(), flipped: true, attrs,
    front: `<div class="cf" style="--gc:${col}"><div class="cf-head"><span class="cf-type">${legal ? 'قانوني' : 'ممنوع'}</span></div><div class="cf-art" style="font-size:42px">${em}</div><h3 class="cf-name">${n}</h3><p class="cf-desc">قيمة ${ar(v)} • غرامة ${ar(p)}</p></div>` });
}

export const screenKey = v => [v.phase, v.turnNo, v.current || ''].join(':');

function stands(ctx, v) {
  return `<div class="sh-stands">${v.players.map(p => `<div class="sh-stand ${p.id === v.sheriff ? 'sheriff' : ''}"><div class="row spread">${chip(ctx, p.id, p.id === v.sheriff ? ' ⭐' : '')}<b>🪙 ${ar(p.gold)}</b></div>
    <div class="row wrap" style="gap:4px;margin-top:4px;font-size:14px">${Object.entries(p.stand).filter(([, c]) => c).map(([g, c]) => `<span class="badge">${G[g][5]} ${ar(c)}</span>`).join('')}${p.hidden ? `<span class="badge off">مقلوبة ${ar(p.hidden)}</span>` : ''}</div></div>`).join('')}</div>`;
}

export function render(ctx) {
  const v = ctx.view, me = v.me;
  const isSheriff = v.sheriff === ctx.me;
  let h = `<p class="center muted" style="margin:0">الدور ${ar(v.turnNo)} من ${ar(v.turnsTotal)} • الشريف: ${nm(ctx, v.sheriff)} ⭐</p>` + stands(ctx, v);
  const mine = v.players.find(p => p.id === ctx.me);
  const sel = ctx.ui.sel || [];
  const hand = (mode, max) => `<div class="k-hand">${me.hand.map((g, k) => `<button class="card-btn ${sel.includes(k) ? 'sel' : ''}" data-ui="sel" data-k="${k}" data-max="${max}" ${mode ? '' : 'disabled'}>${good(g)}</button>`).join('')}</div>`;
  if (v.phase === 'market') {
    if (isSheriff) return h + wait('التجار في السوق') + `<p class="center soft">يدك:</p>` + hand(false, 0);
    if (mine.done) return h + wait('أنهيت السوق — بانتظار البقية') + hand(false, 0);
    return h + `<p class="center">السوق: اختر حتى ٥ بطاقات تتخلص منها وتسحب بدلها (أو لا شيء)</p>` + hand(true, 5) + btn(sel.length ? `بدّل ${ar(sel.length)} بطاقات` : 'لا أبدّل شيئًا', { type: 'market', discard: sel }, 'block');
  }
  if (v.phase === 'load') {
    if (isSheriff) return h + wait('التجار يعبئون حقائبهم');
    if (mine.done) return h + wait(`حقيبتك جاهزة: أعلنت ${ar(mine.declare.count)} ${G[mine.declare.good][0]}`);
    h += `<p class="center">اختر ١–٥ بطاقات للحقيبة، ثم أعلن نوعًا قانونيًا (العدد سيُعلن صحيحًا تلقائيًا):</p>` + hand(true, 5);
    h += `<div class="field"><label>أعلن أنها كلها:</label><select id="decl">${LEGAL.map(g => `<option value="${g}">${G[g][5]} ${G[g][0]}</option>`).join('')}</select></div>`;
    h += `<button class="btn block" data-act='${JSON.stringify({ type: 'load', cards: sel })}' data-input='{"declare":"#decl"}' ${sel.length ? '' : 'disabled'}>أغلق الحقيبة (${ar(sel.length)})</button>`;
    return h;
  }
  if (v.phase === 'inspect') {
    const cur = v.players.find(p => p.id === v.current);
    h += panel(`<p class="center h2" style="margin:0">💼 ${nm(ctx, cur.id)} يعلن: ${ar(cur.declare.count)} × ${G[cur.declare.good][5]} ${G[cur.declare.good][0]}</p>${cur.offer ? `<p class="center" style="margin:6px 0 0">الرشوة المعروضة: <b>🪙 ${ar(cur.offer)}</b></p>` : ''}`, 'sh-bag');
    if (v.current === ctx.me) {
      if (me.bag) h += `<p class="center muted" style="font-size:14px">حقيبتك: ${me.bag.map(g => G[g][5]).join(' ')}</p>`;
      h += `<div class="field"><label>اعرض رشوة على الشريف (ذهب)</label><input id="bribe" type="number" min="0" max="${me.gold}" inputmode="numeric" value="${cur.offer || 0}"></div><button class="btn soft block" data-act='{"type":"offer"}' data-input='{"gold":"#bribe"}'>اعرض</button>`;
      h += wait('الشريف يقرر');
    } else if (isSheriff) h += `<div class="row">${btn(cur.offer ? `مرّرها وخذ ${ar(cur.offer)}` : 'مرّرها', { type: 'pass' }, 'soft grow-btn')}${btn('فتّش الحقيبة 🔍', { type: 'inspect' }, 'grow-btn')}</div>`;
    else h += wait('المواجهة بين التاجر والشريف');
    return h + lastInspect(ctx, v);
  }
  if (v.phase === 'turnEnd') {
    h += lastInspect(ctx, v);
    if (isSheriff || ctx.isHost) h += btn(v.turnNo >= v.turnsTotal ? 'احسب الثروات' : 'الدور التالي', { type: 'next' }, 'block');
    else h += wait('الشريف ينهي الدور');
    return h;
  }
  if (v.phase === 'over') {
    const sc = v.scores.slice().sort((a, b) => b.total - a.total);
    h = winnerBanner(`أغنى تاجر: ${v.winner.map(id => nm(ctx, id)).join(' و')}`) + `<div class="panel"><table class="score-table"><tr><th>اللاعب</th><th>ذهب</th><th>بضائع</th><th>مكافآت</th><th>المجموع</th></tr>${sc.map(r => `<tr><td>${nm(ctx, r.id)}</td><td>${ar(r.gold)}</td><td>${ar(r.goods)}</td><td>${ar(r.bonus)}</td><td><b>${ar(r.total)}</b></td></tr>`).join('')}</table></div>` + stands(ctx, v);
  }
  return h;
}
function lastInspect(ctx, v) {
  const L = v.lastInspect; if (!L) return '';
  if (!L.inspected) return panel(`<p class="center" style="margin:0">مرّت حقيبة ${nm(ctx, L.merchant)}${L.bribe ? ` مقابل 🪙 ${ar(L.bribe)}` : ''}</p>`, '', 'margin-top:8px');
  return panel(`<p class="center" style="margin:0">فُتّشت حقيبة ${nm(ctx, L.merchant)}: ${L.bag.map(g => G[g][5]).join(' ')} — ${L.honest ? `<b style="color:var(--ok)">صادق!</b> الشريف دفع ${ar(L.paid)}` : `<b style="color:var(--danger)">كاذب!</b> صودر ${L.confiscated.map(g => G[g][5]).join(' ')} ودفع ${ar(L.paid)}`}</p>`, '', 'margin-top:8px');
}
export function onUi(name, el, ctx, rerender) {
  if (name === 'sel') { toggleSel(ctx, 'sel', Number(el.dataset.k), Number(el.dataset.max) || 5); ctx.sfx('tap'); rerender(); }
}
export function onAct(a, ctx) { if (['market', 'load'].includes(a.type)) ctx.ui.sel = []; }
export function onFx(e, ctx) {
  const m = { 'round-start': 'round', phase: 'phase', bag: 'flip', offer: 'coin', pass: 'pass', honest: 'coin', caught: 'gavel' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'caught') shake();
  if (e.kind === 'game-over') { if ((ctx.view.winner || []).includes(ctx.me)) { ctx.sfx('win'); burst(['#e0b45c', '#a3231f', '#fff']); } else ctx.sfx('lose'); }
}

// واجهة "برا السالفة" — بطاقات مرحة، أسئلة بالدور، تصويت وتخمين
import { esc, ar, avatar, openSheet } from '../dom.js';
import { baraBackArt, baraOutsiderArt } from '../art.js';
import { burst, vibrate } from '../../core/effects.js';

export const theme = 'bara';
export const kit = 'pop';
export const ambient = () => '';

const nm = (ctx, id) => esc(ctx.player(id)?.name || '؟');

function front(v) {
  const me = v.me;
  if (me.role === 'outsider') {
    return `<div class="cf"><div class="cf-head"><span class="cf-type">${esc(v.category.icon)} ${esc(v.category.name)}</span></div>
      <div class="cf-art">${baraOutsiderArt()}</div>
      <div><h3 class="cf-name">أنت برا السالفة!</h3><p class="cf-desc">تعرف التصنيف فقط. جارِ الكلام ولا تنكشف، وحاول تعرف الكلمة.</p></div></div>`;
  }
  return `<div class="cf"><div class="cf-head"><span class="cf-type">${esc(v.category.name)}</span></div>
    <div class="cf-art"><span class="big-icon">${esc(v.category.icon)}</span></div>
    <div><p class="cf-desc" style="margin-bottom:2px">الكلمة السرية</p><h3 class="cf-name" style="font-size:36px">${esc(me.word)}</h3><p class="cf-desc">واحد منكم برا السالفة… لا تفضح الكلمة!</p></div></div>`;
}

function card(v, { flipped, attrs = '', hint = 'اضغط لكشف بطاقتك', size = '' }) {
  return `<div class="card bara-card ${size} ${v.me.role === 'outsider' ? 'outsider' : ''} ${flipped ? 'is-flipped' : ''}" ${attrs}>
    <div class="card-inner"><div class="card-face card-back">${baraBackArt()}${hint ? `<div class="tap-hint" style="color:#fff">${hint}</div>` : ''}</div>
    <div class="card-face card-front">${front(v)}</div></div></div>`;
}

export function headerExtra(ctx) {
  const v = ctx.view;
  if (!v.me || v.phase === 'reveal' || v.phase === 'over') return '';
  return `<button class="icon-btn" data-ui="peek" aria-label="اعرض بطاقتي">🂠</button>`;
}

export function render(ctx) {
  const v = ctx.view, me = v.me;
  let html = `<p class="center soft" style="margin:0 0 10px">الجولة ${ar(v.round)} من ${ar(v.rounds)} · التصنيف: <b>${esc(v.category.icon)} ${esc(v.category.name)}</b></p>`;

  if (v.phase === 'reveal') {
    const seenN = v.players.filter(p => p.seen).length;
    if (!me.seen) {
      html += card(v, { flipped: !!ctx.ui.revealed, attrs: 'data-ui="reveal" role="button" tabindex="0" aria-label="اكشف بطاقتك"' });
      if (ctx.ui.revealed) html += `<p class="private-note">لا تعرض بطاقتك لأحد.</p><button class="btn block" style="margin-top:14px" data-act='{"type":"seen"}'>شفت بطاقتي</button>`;
    } else {
      html += `<div class="big-status"><p class="h2">بانتظار البقية<span class="waiting-dots"></span></p><p class="soft">${ar(seenN)} من ${ar(v.players.length)} شافوا بطاقاتهم</p></div>`;
    }
    if (ctx.isHost && seenN < v.players.length) html += `<button class="btn ghost block" style="margin-top:12px" data-act='{"type":"advance"}'>ابدأ الأسئلة الآن (تجاوز المتأخرين)</button>`;
    return html;
  }

  if (v.phase === 'questions') {
    const pr = v.pair;
    const amAsker = pr.asker === ctx.me;
    html += `<p class="center muted" style="margin:0 0 8px">سؤال ${ar(pr.index + 1)} من ${ar(pr.total)}</p>
      <div class="pair-card phase-in" data-key="${pr.index}">
        <div class="side">${avatar(ctx.player(pr.asker), 'lg')}<span class="name">${nm(ctx, pr.asker)}</span><span class="badge host">يسأل</span></div>
        <span class="arrow" aria-hidden="true">←</span>
        <div class="side">${avatar(ctx.player(pr.answerer), 'lg')}<span class="name">${nm(ctx, pr.answerer)}</span><span class="badge ok">يجاوب</span></div>
      </div>
      <p class="center soft" style="margin:12px 0">${amAsker ? 'اسأل سؤالًا عن الكلمة دون أن تفضحها.' : pr.answerer === ctx.me ? 'جاوب بذكاء…' : 'ركّز في الأجوبة!'}</p>`;
    if (amAsker || ctx.isHost) html += `<button class="btn block" data-act='${JSON.stringify({ type: 'doneAsking', pairIndex: pr.index })}'>${amAsker ? 'انتهيت من سؤالي' : 'السؤال التالي'}</button>`;
    if (ctx.isHost) html += `<button class="btn ghost block" style="margin-top:10px" data-act='{"type":"advance"}'>انتقل للتصويت مباشرة</button>`;
    return html;
  }

  if (v.phase === 'vote') {
    const votedN = v.players.filter(p => p.voted).length;
    html += `<h2 class="h2 center" style="margin:6px 0">من برا السالفة؟</h2><p class="center soft">صوّت ${ar(votedN)} من ${ar(v.players.length)}</p>`;
    if (me.vote == null) {
      html += `<div class="target-list">${v.players.filter(p => p.id !== ctx.me).map(p => `<button class="target" data-act='${JSON.stringify({ type: 'vote', target: p.id })}'>${avatar(ctx.player(p.id), 'sm')}<span class="t-name">${nm(ctx, p.id)}</span></button>`).join('')}</div>`;
    } else {
      html += `<div class="panel center pop-in"><p>صوّتّ على: <b>${nm(ctx, me.vote)}</b></p><p class="soft">بانتظار البقية<span class="waiting-dots"></span></p></div>`;
    }
    html += `<div class="row wrap" style="justify-content:center;margin-top:12px">${v.players.map(p => `<span class="badge ${p.voted ? 'ok' : ''}">${esc(ctx.player(p.id)?.emoji || '')} ${nm(ctx, p.id)} ${p.voted ? '✓' : '…'}</span>`).join('')}</div>`;
    if (ctx.isHost) html += `<button class="btn ghost block" style="margin-top:14px" data-act='{"type":"advance"}'>أنهِ التصويت الآن</button>`;
    return html;
  }

  if (v.phase === 'over') {
    const top = Math.max(...v.players.map(p => p.score));
    const winners = v.players.filter(p => p.score === top);
    html = `<div class="center pop-in" style="padding:6px 0 14px"><p class="soft" style="margin:0">انتهت اللعبة</p>
      <p class="h1" style="color:var(--accent)">🏆 ${winners.map(p => nm(ctx, p.id)).join(' و ')}</p>
      <p class="soft" style="margin:0">${winners.some(p => p.id === ctx.me) ? 'مبروك! أنت الفائز' : 'الفائز بأعلى النقاط'} — ${ar(top)} نقاط</p></div>` + html;
  }
  if (v.phase === 'guess' || v.phase === 'result' || v.phase === 'over') {
    html += `<div class="panel center pop-in"><p class="soft" style="margin:0">برا السالفة كان</p>
      <div class="row" style="justify-content:center;margin:6px 0">${avatar(ctx.player(v.outsider), 'lg')}</div>
      <p class="h2" style="margin:0">${nm(ctx, v.outsider)}${v.outsider === ctx.me ? ' (أنت)' : ''}</p>
      <p class="badge ${v.caught ? 'ok' : 'off'}" style="display:inline-block;margin-top:8px">${v.caught ? 'انمسك!' : 'ما انمسك — أفلت من التصويت'}</p></div>`;
    html += votesBlock(ctx);
  }

  if (v.phase === 'guess') {
    if (v.options) {
      html += `<h2 class="h2 center" style="margin:16px 0 8px">خمّن الكلمة!</h2><div class="word-grid">${v.options.map(w => `<button class="word-option" data-act='${JSON.stringify({ type: 'guess', word: w })}'>${esc(w)}</button>`).join('')}</div>`;
    } else {
      html += `<p class="center soft" style="margin-top:16px">${nm(ctx, v.outsider)} يحاول تخمين الكلمة<span class="waiting-dots"></span></p>`;
    }
    return html;
  }

  if (v.phase === 'result' || v.phase === 'over') {
    const right = v.guess === v.word;
    html += `<div class="panel center" style="margin-top:12px"><p class="soft" style="margin:0">الكلمة كانت</p><p class="h1" style="color:var(--accent);margin:4px 0">${esc(v.word)}</p>
      <p style="margin:0">خمّن: <b>${esc(v.guess || '—')}</b> <span class="badge ${right ? 'ok' : 'off'}">${right ? 'صح' : 'خطأ'}</span></p></div>`;
    html += scoreBlock(ctx);
    if (v.phase === 'result') {
      const last = v.round >= v.rounds;
      html += ctx.isHost
        ? `<button class="btn block" style="margin-top:14px" data-act='{"type":"next"}'>${last ? 'النتيجة النهائية' : 'الجولة التالية'}</button>`
        : `<p class="center muted" style="margin-top:12px">بانتظار المضيف…</p>`;
    }
  }
  return html;
}

function votesBlock(ctx) {
  const v = ctx.view;
  if (!v.votes) return '';
  const counts = {};
  v.votes.forEach(x => { if (x.to) counts[x.to] = (counts[x.to] || 0) + 1; });
  const rows = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  return `<details class="panel" style="margin-top:10px"><summary style="cursor:pointer"><b>نتيجة التصويت</b></summary>
    ${rows.map(([id, c]) => `<div class="row spread" style="padding:4px 0"><span>${nm(ctx, id)}</span><span class="badge">${ar(c)} ${c === 1 ? 'صوت' : 'أصوات'}</span></div>`).join('')}
    <div class="divider"></div>${v.votes.filter(x => x.to).map(x => `<div class="row spread" style="font-size:14px"><span>${nm(ctx, x.from)}</span><span class="muted">← ${nm(ctx, x.to)}</span></div>`).join('')}</details>`;
}

function scoreBlock(ctx) {
  const v = ctx.view;
  const sorted = v.players.slice().sort((a, b) => b.score - a.score);
  return `<div class="panel" style="margin-top:12px"><b>النقاط</b><table class="score-table"><tbody>${sorted.map((p, k) => `<tr>
    <td style="width:40px"><span class="rank ${k === 0 ? 'first' : ''}">${ar(k + 1)}</span></td><td>${esc(ctx.player(p.id)?.emoji || '')} ${nm(ctx, p.id)}</td>
    <td class="num">${v.roundScores && v.roundScores[p.id] ? `<span class="badge ok">+${ar(v.roundScores[p.id])}</span> ` : ''}${ar(p.score)}</td></tr>`).join('')}</tbody></table></div>`;
}

export function screenKey(v) { return [v.phase, v.round, v.pair?.index].join(':'); }

export function onUi(name, el, ctx, rerender) {
  if (name === 'reveal' && !ctx.ui.revealed) {
    ctx.ui.revealed = true;
    el.classList.add('is-flipped');
    ctx.sfx('flip'); vibrate(30);
    setTimeout(rerender, 760);
  }
  if (name === 'peek') {
    openSheet(`<h2>بطاقتي</h2>${card(ctx.view, { flipped: true, hint: '' })}<button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'بطاقتي' });
  }
}

export function onAct(a, ctx) { if (a.type === 'seen') ctx.ui.revealed = false; }

export function onFx(e, ctx) {
  switch (e.kind) {
    case 'round-start': ctx.sfx('reveal'); ctx.ui.revealed = false; break;
    case 'phase': case 'tick': ctx.sfx('next'); break;
    case 'vote': ctx.sfx('vote'); break;
    case 'caught': ctx.sfx('caught'); break;
    case 'escaped': ctx.sfx('escaped'); break;
    case 'guess-right': ctx.sfx('correct'); break;
    case 'guess-wrong': ctx.sfx('wrong'); break;
    case 'score': setTimeout(() => ctx.sfx('score'), 400); break;
    case 'game-over': ctx.sfx('win'); burst(['#ff5a3c', '#ffb627', '#13a89e', '#8338ec']); break;
  }
}

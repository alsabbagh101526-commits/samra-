// واجهة الانقلاب — بلاط عنابي وذهب، بطاقات نفوذ وعملات
import { ar, esc } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, roleFront, toggleSel, winnerBanner, logBlock } from '../kit.js';
import { burst, shake } from '../../core/effects.js';

export const theme = 'coup';
export const kit = 'luxe';
export const ambient = () => '';

export const CARD = {
  duke: ['الدوق', 'ضريبة +٣ • يصد المساعدة الخارجية', '#7a3fb0'],
  assassin: ['القاتل', 'ادفع ٣ واغتل نفوذًا', '#2b2b2b'],
  captain: ['القبطان', 'اسرق عملتين • يصد السرقة', '#1f5f8b'],
  ambassador: ['السفير', 'بدّل بطاقتين • يصد السرقة', '#2f7d4a'],
  contessa: ['الكونتيسة', 'تصد الاغتيال', '#a8323e'],
};
const ACTION = { income: 'دخل +١', foreign_aid: 'مساعدة خارجية +٢', coup: 'انقلاب (٧)', tax: 'ضريبة +٣ (دوق)', assassinate: 'اغتيال (٣) (قاتل)', steal: 'سرقة (قبطان)', exchange: 'تبديل (سفير)' };
const BLOCKS = { foreign_aid: ['duke'], assassinate: ['contessa'], steal: ['captain', 'ambassador'] };

function sil(c, color) {
  return `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="54" fill="${color}"/><circle cx="60" cy="42" r="15" fill="#120608"/><path d="M28 104 Q60 52 92 104 Z" fill="#120608"/>${c === 'duke' ? '<path d="M44 26 L50 14 L60 24 L70 14 L76 26 Z" fill="#e3b24f"/>' : c === 'contessa' ? '<path d="M45 30 Q60 14 75 30" stroke="#e3b24f" stroke-width="4" fill="none"/>' : c === 'captain' ? '<path d="M40 30 H80 L72 20 H48 Z" fill="#e3b24f"/>' : c === 'assassin' ? '<path d="M38 36 Q60 10 82 36 L78 44 Q60 30 42 44 Z" fill="#120608"/>' : '<rect x="50" y="70" width="20" height="26" fill="#e3b24f"/>'}</svg>`;
}
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" fill="#3d0f1a"/><rect x="14" y="14" width="172" height="252" rx="12" fill="none" stroke="#e3b24f" stroke-width="3"/><path d="M100 90 L130 140 L100 190 L70 140 Z" fill="none" stroke="#e3b24f" stroke-width="4"/><circle cx="100" cy="140" r="12" fill="#e3b24f"/></svg>`;
export function infl(c, { dead = false, size = 'sm', attrs = '', flipped = true } = {}) {
  if (!c) return card({ cls: `coup-card ${size}`, back: back(), front: '', flipped: false, attrs });
  const [n, d, col] = CARD[c];
  return card({ cls: `coup-card ${size} ${dead ? 'dead' : ''}`, back: back(), front: roleFront({ type: dead ? 'مكشوفة' : 'نفوذ', name: n, desc: d, art: sil(c, col) }), flipped, attrs });
}

export const screenKey = v => [v.phase, v.turn, v.pend?.stage || ''].join(':');

function pendLine(ctx, p) {
  let t = `${nm(ctx, p.actor)} يعلن: <b>${ACTION[p.kind]}</b>${p.target ? ` على ${nm(ctx, p.target)}` : ''}`;
  if (p.blocker) t += `<br>${nm(ctx, p.blocker)} يصدّ مدعيًا <b>${CARD[p.blockCard][0]}</b>`;
  return t;
}

export function render(ctx) {
  const v = ctx.view, me = v.me;
  let h = `<div class="coup-table">${v.players.map(p => `<div class="coup-seat ${p.id === v.turn ? 'turn' : ''} ${p.alive ? '' : 'out'}">
    <div class="row" style="gap:6px">${chip(ctx, p.id, p.id === ctx.me ? ' (أنت)' : '')}<span class="coins">🪙 ${ar(p.coins)}</span></div>
    <div class="row" style="gap:4px;margin-top:6px">${(p.id === ctx.me ? me.cards : p.cards).map(c => infl(c.c, { dead: c.dead, size: 'xs' })).join('')}</div></div>`).join('')}</div>`;
  if (v.lastChallenge) {
    const c = v.lastChallenge;
    h += `<p class="center muted" style="font-size:14px;margin:6px 0">آخر تحدٍّ: ${nm(ctx, c.challenger)} تحدّى ${nm(ctx, c.claimant)} (${CARD[c.card][0]}) — ${c.truthful ? 'كان صادقًا' : 'كان يخادع'}</p>`;
  }
  if (v.phase === 'over') return winnerBanner(`${esc(ctx.player(v.winner)?.name)} يحكم المدينة`, 'آخر من بقي بنفوذ') + h + logBlock(v.log);
  if (v.phase === 'action') {
    if (v.turn === ctx.me) {
      const coins = me.coins;
      const others = v.players.filter(p => p.alive && p.id !== ctx.me).map(p => p.id);
      const sel = ctx.ui.action;
      h += `<p class="h2 center" style="margin:12px 0 6px">دورك</p>`;
      if (coins >= 10) h += `<p class="center" style="color:var(--danger)">معك ١٠ عملات: الانقلاب إجباري</p>`;
      h += `<div class="action-grid">${Object.entries(ACTION).map(([k, l]) => {
        const dis = (coins >= 10 && k !== 'coup') || (k === 'coup' && coins < 7) || (k === 'assassinate' && coins < 3);
        const needT = ['coup', 'assassinate', 'steal'].includes(k);
        return needT ? `<button class="btn soft ${sel === k ? 'on' : ''}" data-ui="choose" data-k="${k}" ${dis ? 'disabled' : ''}>${l}</button>` : btn(l, { type: k }, 'soft', dis ? 'disabled' : '');
      }).join('')}</div>`;
      if (sel) h += `<p class="center" style="margin:10px 0 6px">اختر الهدف لـ${ACTION[sel]}:</p>` + targets(ctx, others, { action: sel });
    } else h += wait(`دور ${nm(ctx, v.turn)}`);
    return h + logBlock(v.log);
  }
  if (v.phase === 'respond') {
    const p = v.pend;
    h += panel(`<p style="margin:0">${pendLine(ctx, p)}</p>`, 'center', 'margin-top:10px');
    if (me.canRespond) {
      const opts = [btn('أسمح', { type: 'allow' }, 'soft')];
      if (p.stage === 'chal' || p.stage === 'chalBlock') opts.push(btn('أتحدّى! ⚔️', { type: 'challenge' }, 'danger'));
      if (p.stage === 'block') (BLOCKS[p.kind] || []).forEach(c => opts.push(btn(`أصدّ بـ${CARD[c][0]}`, { type: 'block', card: c })));
      h += `<div class="action-grid" style="margin-top:10px">${opts.join('')}</div>`;
    } else h += wait('بانتظار ردود: ' + p.waiting.map(id => nm(ctx, id)).join('، '));
    return h + logBlock(v.log);
  }
  if (v.phase === 'lose') {
    if (v.loser === ctx.me) {
      h += `<p class="h2 center" style="color:var(--danger)">اختر نفوذًا تكشفه وتخسره:</p><div class="row" style="justify-content:center;gap:12px">${me.cards.map((c, k) => c.dead ? '' : `<button class="card-btn" data-act='{"type":"lose","index":${k}}'>${infl(c.c, { size: 'md' })}</button>`).join('')}</div>`;
    } else h += wait(`${nm(ctx, v.loser)} يختار نفوذًا يخسره`);
    return h;
  }
  if (v.phase === 'exchange') {
    if (me.exchange) {
      const need = me.cards.filter(c => !c.dead).length;
      const sel = ctx.ui.keep || [];
      h += `<p class="center">اختر ${ar(need)} بطاقة تحتفظ بها:</p><div class="row wrap" style="justify-content:center;gap:10px">${me.exchange.map((c, k) => `<button class="card-btn ${sel.includes(k) ? 'sel' : ''}" data-ui="keep" data-k="${k}">${infl(c, { size: 'md' })}</button>`).join('')}</div>`;
      h += `<div style="margin-top:12px">${btn(`احتفظ (${ar(sel.length)}/${ar(need)})`, { type: 'keep', indices: sel }, 'block', sel.length === need ? '' : 'disabled')}</div>`;
    } else h += wait(`${nm(ctx, v.pend.actor)} يبدّل بطاقاته`);
    return h;
  }
  return h;
}

export function onUi(name, el, ctx, rerender) {
  if (name === 'choose') { ctx.ui.action = ctx.ui.action === el.dataset.k ? null : el.dataset.k; ctx.sfx('tap'); rerender(); }
  if (name === 'keep') { toggleSel(ctx, 'keep', Number(el.dataset.k), ctx.view.me.cards.filter(c => !c.dead).length); ctx.sfx('tap'); rerender(); }
}
export function onAct(a, ctx) { ctx.ui.action = null; if (a.type === 'keep') ctx.ui.keep = []; }
export function onFx(e, ctx) {
  const m = { coin: 'coin', declare: 'bid', block: 'pass', challenge: 'buzz', 'challenge-win': 'correct', 'challenge-fail': 'wrong', lose: 'flip', out: 'skull', coup: 'boom', assassinate: 'boom', blocked: 'pass' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'coup' || e.kind === 'assassinate') shake();
  if (e.kind === 'game-over') { if (e.who === ctx.me) { ctx.sfx('win'); burst(['#e3b24f', '#fff', '#a8323e']); } else ctx.sfx('lose'); }
}

// واجهة الطول الموجي — قرص طيف بألوان النيون ومؤشر
import { ar, esc } from '../dom.js';
import { nm, who, btn, wait, panel, teamsBlock, winnerBanner, act } from '../kit.js';
import { burst } from '../../core/effects.js';

export const theme = 'wavelength';
export const kit = 'pop';
export const ambient = () => '';
const LBL = { A: 'الفريق الأزرق', B: 'الفريق الوردي' };

function pt(v, r, cx = 160, cy = 160) { const a = Math.PI * v / 100; return [cx + r * Math.cos(a), cy - r * Math.sin(a)]; }
function wedge(from, to, r, color) {
  from = Math.max(0, from); to = Math.min(100, to);
  const [x1, y1] = pt(from, r), [x2, y2] = pt(to, r);
  return `<path d="M160 160 L${x1} ${y1} A${r} ${r} 0 0 0 ${x2} ${y2} Z" fill="${color}"/>`;
}
function dial(v, showTarget) {
  const t = v.targetPos;
  let bands = '';
  if (showTarget && t != null) bands = wedge(t - 18, t + 18, 140, '#ffd166') + wedge(t - 11, t + 11, 140, '#ef8354') + wedge(t - 4, t + 4, 140, '#e63946')
    + `<text x="${pt(t, 118)[0]}" y="${pt(t, 118)[1]}" text-anchor="middle" font-size="13" fill="#fff" font-weight="700">٤</text>`;
  const [nx, ny] = pt(v.dial, 132);
  return `<svg class="wl-dial" viewBox="0 0 320 175" aria-label="القرص">
    <path d="M20 160 A140 140 0 0 1 300 160 Z" fill="#232a5c"/>${bands}
    ${showTarget ? '' : '<path d="M20 160 A140 140 0 0 1 300 160 Z" fill="url(#wlg)" opacity=".25"/>'}
    <defs><linearGradient id="wlg"><stop offset="0" stop-color="#ff70a6"/><stop offset="1" stop-color="#70d6ff"/></linearGradient></defs>
    <line x1="160" y1="160" x2="${nx}" y2="${ny}" stroke="#fff" stroke-width="6" stroke-linecap="round"/><circle cx="160" cy="160" r="14" fill="#ff70a6"/></svg>
    <div class="row spread wl-ends"><span>${esc(v.card[0])} ←</span><span>→ ${esc(v.card[1])}</span></div>`;
}

export const screenKey = v => [v.phase, v.round].join(':');

export function render(ctx) {
  const v = ctx.view;
  const isPsy = v.psychic === ctx.me;
  const myTeamActive = v.myTeam === v.active;
  let h = teamsBlock(ctx, v.teams, LBL, v.score);
  h += `<p class="center muted" style="margin:6px 0">الهدف: ${ar(v.target)} نقاط • الجولة ${ar(v.round)} • دور ${LBL[v.active]} • الوسيط: ${nm(ctx, v.psychic)}</p>`;
  const reveal = v.phase === 'reveal' || v.phase === 'over';
  h += dial(v, reveal || (isPsy && v.phase !== 'over'));
  if (v.clue) h += `<p class="h2 center wl-clue">«${esc(v.clue)}»</p>`;
  if (v.phase === 'clue') {
    if (isPsy) h += `<p class="center">أنت الوسيط: الهدف ظاهر لك فقط. أعطِ تلميحًا يضع فريقك في المكان الصحيح.</p>
      <div class="field"><input id="wclue" maxlength="40" placeholder="اكتب التلميح (أو قله بصوتك)"></div>
      <div class="row">${`<button class="btn grow-btn" data-act='{"type":"clue"}' data-input='{"text":"#wclue"}'>أرسل التلميح</button>`}${btn('قلته شفهيًا', { type: 'clue', text: '' }, 'soft grow-btn')}</div>`;
    else h += wait(`${nm(ctx, v.psychic)} يفكر بتلميح`);
  } else if (v.phase === 'dial') {
    if (myTeamActive && !isPsy) h += `<p class="center">حرّكوا المؤشر ثم ثبّتوه:</p><input type="range" id="wdial" min="0" max="100" value="${v.dial}" class="wl-range" onchange="document.getElementById('wsend').click()">
      <button id="wsend" hidden data-act='{"type":"dial"}' data-input='{"value":"#wdial"}'></button>${btn('ثبّت المؤشر 🔒', { type: 'lock' }, 'block')}`;
    else h += wait(isPsy ? 'لا تتكلم! فريقك يحرك المؤشر' : `${LBL[v.active]} يحرك المؤشر`);
  } else if (v.phase === 'side') {
    if (!myTeamActive) h += `<p class="center">هل الهدف على يمين المؤشر أم يساره؟</p><div class="row">${btn('→ يمين', { type: 'side', value: 'right' }, 'grow-btn')}${btn('يسار ←', { type: 'side', value: 'left' }, 'grow-btn')}</div>`;
    else h += wait('الفريق الآخر يخمّن الاتجاه');
  } else if (v.phase === 'reveal') {
    const r = v.result;
    h += panel(`<p class="center" style="margin:0">${LBL[v.active]}: <b>+${ar(r.pts)}</b> • ${LBL[v.active === 'A' ? 'B' : 'A']}: <b>+${ar(r.sidePt)}</b></p>`, 'center');
    if (isPsy || ctx.isHost) h += `<div style="margin-top:10px">${btn('الجولة التالية', { type: 'next' }, 'block')}</div>`;
    else h += wait('بانتظار الجولة التالية');
  } else if (v.phase === 'over') {
    h = winnerBanner(v.winner === 'tie' ? 'تعادل!' : `فاز ${LBL[v.winner]}`, `${ar(v.score.A)} — ${ar(v.score.B)}`) + h;
  }
  return h;
}
export function onFx(e, ctx) {
  const m = { 'round-start': 'round', clue: 'secret', lock: 'tap', bullseye: 'correct', score: 'point', miss: 'wrong' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'bullseye') burst(['#e63946', '#ffd166', '#70d6ff']);
  if (e.kind === 'game-over') { if (ctx.view.winner === ctx.view.myTeam) { ctx.sfx('win'); burst(['#ffd166', '#ff70a6', '#70d6ff']); } else ctx.sfx('lose'); }
}

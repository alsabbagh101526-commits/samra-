// واجهة مونوبولي — لوحة مصغرة ١١×١١، نرد، بطاقات ملكية، صفقات ومزاد
import { ar, esc, openSheet, closeSheet } from '../dom.js';
import { nm, who, chip, btn, wait, panel, winnerBanner, act, logBlock } from '../kit.js';
import { BOARD, GROUPS } from '../../engines/monopoly.js';
import { burst, shake } from '../../core/effects.js';

export const theme = 'monopoly';
export const kit = 'pop';
export const ambient = () => '';
const GC = { brown: '#8b5a2b', sky: '#7fd3f7', pink: '#e05aa0', orange: '#f39c12', red: '#e74c3c', yellow: '#f1c40f', green: '#27ae60', navy: '#2c3e9e' };
const PC = ['#e74c3c', '#2980b9', '#27ae60', '#f39c12', '#8e44ad', '#16a085', '#d35400', '#2c3e50'];
const ICON = { go: '➡️', chest: '🎁', chance: '❓', tax: '💸', rail: '🚉', util: '⚡', jail: '🚔', parking: '🅿️', gotojail: '👮' };
const DICE = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

function pos(k) {
  if (k <= 10) return [11, 11 - k];
  if (k <= 20) return [11 - (k - 10), 1];
  if (k <= 30) return [1, 1 + (k - 20)];
  return [1 + (k - 30), 11];
}
const pcolor = (v, id) => PC[v.players.findIndex(p => p.id === id) % PC.length];
const money = n => `${ar(n)}﷼`;

function boardHtml(ctx, v) {
  let h = '<div class="mono-board" dir="ltr">';
  BOARD.forEach((b, k) => {
    const [r, c] = pos(k);
    const pr = v.props[k];
    const tokens = v.players.filter(p => !p.bankrupt && p.pos === k).map(p => `<i class="tok" style="background:${pcolor(v, p.id)}">${esc(ctx.player(p.id)?.emoji || '')}</i>`).join('');
    const strip = b.type === 'street' ? `<span class="strip" style="background:${GC[b.group]}"></span>` : `<span class="ico">${ICON[b.type] || ''}</span>`;
    const own = pr && pr.owner ? `<span class="own" style="background:${pcolor(v, pr.owner)}">${pr.mortgaged ? '×' : pr.houses === 5 ? '🏨' : pr.houses ? ar(pr.houses) : ''}</span>` : '';
    h += `<button class="mcell ${[0, 10, 20, 30].includes(k) ? 'corner' : ''}" style="grid-row:${r};grid-column:${c}" data-ui="sq" data-k="${k}" aria-label="${esc(b.name)}">${strip}${own}<span class="toks">${tokens}</span></button>`;
  });
  const cur = v.turn;
  h += `<div class="mcenter" dir="rtl"><div class="mono-logo">مونوبولي</div><div class="dice">${v.dice ? DICE[v.dice[0]] + DICE[v.dice[1]] : '🎲'}</div><div>دور ${who(ctx, cur)}</div>
    ${v.lastCard ? `<div class="mcard">${v.lastCard.kind === 'chance' ? '❓ فرصة' : '🎁 صندوق المجتمع'}: ${esc(v.lastCard.text)}</div>` : ''}
    ${v.maxRounds ? `<small>الجولة ${ar(v.round)} من ${ar(v.maxRounds)}</small>` : `<small>الجولة ${ar(v.round)}</small>`}</div>`;
  return h + '</div>';
}

function propInfo(v, k) {
  const b = BOARD[k], pr = v.props[k];
  let h = `<h2>${esc(b.name)}</h2>`;
  if (b.type === 'street') h += `<div class="deed" style="--gc:${GC[b.group]}"><div class="deed-head">${esc(b.name)}</div><table class="score-table">
    <tr><td>الإيجار</td><td>${money(b.rent[0])}</td></tr>${[1, 2, 3, 4].map(n => `<tr><td>مع ${ar(n)} ${n === 1 ? 'بيت' : 'بيوت'}</td><td>${money(b.rent[n])}</td></tr>`).join('')}
    <tr><td>مع فندق</td><td>${money(b.rent[5])}</td></tr><tr><td>سعر البيت/الفندق</td><td>${money(b.house)}</td></tr><tr><td>السعر</td><td>${money(b.price)}</td></tr><tr><td>الرهن</td><td>${money(b.price / 2)}</td></tr></table></div>`;
  else if (b.type === 'rail') h += `<p>السعر ${money(200)} • الإيجار ٢٥/٥٠/١٠٠/٢٠٠ حسب عدد المحطات المملوكة</p>`;
  else if (b.type === 'util') h += `<p>السعر ${money(150)} • الإيجار ٤× النرد (أو ١٠× إن امتلك الشركتين)</p>`;
  else if (b.type === 'tax') h += `<p>ادفع ${money(b.amount)}</p>`;
  else h += `<p class="soft">${{ go: 'استلم ٢٠٠ عند المرور', jail: 'السجن أو مجرد زيارة', parking: 'استراحة', gotojail: 'اذهب إلى السجن مباشرة', chance: 'اسحب بطاقة فرصة', chest: 'اسحب بطاقة صندوق المجتمع' }[b.type] || ''}</p>`;
  if (pr) h += `<p>المالك: <b>${pr.owner ? esc(pr.ownerName) : 'البنك (للبيع)'}</b>${pr.mortgaged ? ' — مرهون' : ''}${pr.houses ? ` — ${pr.houses === 5 ? 'فندق' : ar(pr.houses) + ' بيوت'}` : ''}</p>`;
  return h + '<button class="btn soft block" data-sheet-close>إغلاق</button>';
}

function myProps(ctx, v) {
  const mine = Object.keys(v.props).map(Number).filter(k => v.props[k].owner === ctx.me);
  if (!mine.length) return '';
  const can = v.me?.can || {};
  return `<details class="panel" style="margin-top:10px" ${v.phase === 'debt' && v.debt?.from === ctx.me ? 'open' : ''}><summary><b>أملاكي (${ar(mine.length)})</b></summary>${mine.map(k => {
    const b = BOARD[k], pr = v.props[k];
    const ok = can[k] || [];
    const bs = [];
    if (ok.includes('build')) bs.push(btn(pr.houses === 4 ? 'ابنِ فندقًا' : 'ابنِ بيتًا', { type: 'build', sq: k }, 'soft sm'));
    if (ok.includes('sellHouse')) bs.push(btn('بِع مبنى', { type: 'sellHouse', sq: k }, 'soft sm'));
    if (ok.includes('mortgage')) bs.push(btn('ارهن', { type: 'mortgage', sq: k }, 'soft sm'));
    if (ok.includes('unmortgage')) bs.push(btn('فك الرهن', { type: 'unmortgage', sq: k }, 'soft sm'));
    return `<div class="mprop"><span class="strip" style="background:${b.group ? GC[b.group] : '#999'}"></span><span class="grow">${esc(b.name)}${pr.mortgaged ? ' (مرهون)' : ''}${pr.houses ? ' ' + (pr.houses === 5 ? '🏨' : '🏠'.repeat(pr.houses)) : ''}</span>${bs.join('')}</div>`;
  }).join('')}</details>`;
}

export const screenKey = v => [v.phase, v.turn, v.round].join(':');

export function render(ctx) {
  const v = ctx.view;
  const meP = v.players.find(p => p.id === ctx.me);
  let h = '';
  if (v.phase === 'over') h += winnerBanner(`فاز ${v.winner.map(id => nm(ctx, id)).join(' و')}`, 'أقوى إمبراطورية عقارية');
  h += `<div class="mono-players">${v.players.map(p => `<div class="mp ${p.id === v.turn ? 'turn' : ''} ${p.bankrupt ? 'out' : ''}"><i class="tok" style="background:${pcolor(v, p.id)}">${esc(ctx.player(p.id)?.emoji || '')}</i><span>${nm(ctx, p.id)}</span><b>${money(p.cash)}</b>${p.jail ? ' 🚔' : ''}${p.jailCards ? ' 🎫' : ''}</div>`).join('')}</div>`;
  h += boardHtml(ctx, v);
  if (v.phase === 'over') return h + logBlock(v.log);
  if (meP.bankrupt) return h + panel('<p class="center" style="margin:0">أفلست — تابع اللعب</p>') + logBlock(v.log);

  // صفقة موجهة لي
  if (v.trade) {
    const t = v.trade;
    const side = s => [s.cash ? money(s.cash) : '', ...s.props.map(k => esc(BOARD[k].name)), s.cards ? `${ar(s.cards)} بطاقة سجن` : ''].filter(Boolean).join('، ') || 'لا شيء';
    h += panel(`<p style="margin:0">صفقة من ${nm(ctx, t.from)} إلى ${nm(ctx, t.to)}:<br>يعطي: ${side(t.give)}<br>يأخذ: ${side(t.get)}</p>
      ${t.to === ctx.me ? `<div class="row" style="margin-top:8px">${btn('أقبل', { type: 'answerTrade', accept: true }, 'grow-btn')}${btn('أرفض', { type: 'answerTrade', accept: false }, 'soft grow-btn')}</div>` : t.from === ctx.me ? btn('ألغِ الصفقة', { type: 'cancelTrade' }, 'soft block') : ''}`, 'trade-box', 'margin-top:10px');
  }
  const myTurn = v.turn === ctx.me;
  if (v.phase === 'auction') {
    const a = v.auction;
    h += panel(`<p class="center h2" style="margin:0">مزاد: ${esc(BOARD[a.sq].name)}</p><p class="center" style="margin:4px 0">أعلى مزايدة: ${a.bidder ? `${money(a.high)} — ${nm(ctx, a.bidder)}` : 'لا يوجد'}</p>`);
    if (a.at === ctx.me) h += `<div class="field"><input id="mbid" type="number" inputmode="numeric" min="${a.high + 1}" max="${meP.cash}" value="${a.high + 10}"></div><div class="row"><button class="btn grow-btn" data-act='{"type":"bid"}' data-input='{"amount":"#mbid"}'>زايد</button>${btn('انسحب', { type: 'passBid' }, 'soft grow-btn')}</div>`;
    else h += wait(`دور ${nm(ctx, a.at)} في المزاد`);
  } else if (v.phase === 'debt') {
    const d = v.debt;
    if (d.from === ctx.me) h += panel(`<p class="center" style="margin:0;color:var(--danger)">عليك ${money(d.amount)} ${d.to ? 'لـ' + nm(ctx, d.to) : 'للبنك'} — رصيدك ${money(meP.cash)}</p><p class="center muted">ارهن أو بِع مبانيك ثم سدّد، أو أعلن الإفلاس.</p><div class="row">${btn('سدّد', { type: 'payDebt' }, 'grow-btn', meP.cash >= d.amount ? '' : 'disabled')}${btn('أعلن الإفلاس', { type: 'bankrupt' }, 'danger grow-btn')}</div>`);
    else h += wait(`${nm(ctx, d.from)} يحاول تسديد دين`);
  } else if (myTurn) {
    const sq = BOARD[meP.pos];
    if (v.phase === 'roll') {
      if (meP.jail) h += `<p class="center">أنت في السجن (محاولة ${ar(meP.jailTurns + 1)} من ٣)</p><div class="row wrap" style="gap:8px">${btn('ارمِ لزوج 🎲', { type: 'roll' }, 'grow-btn')}${btn('ادفع ٥٠', { type: 'payJail' }, 'soft grow-btn', meP.cash >= 50 ? '' : 'disabled')}${meP.jailCards ? btn('استخدم البطاقة 🎫', { type: 'useCard' }, 'soft grow-btn') : ''}</div>`;
      else h += btn(v.rolledDouble ? 'زوج! ارمِ مرة أخرى 🎲' : 'ارمِ النرد 🎲', { type: 'roll' }, 'block big-roll');
    } else if (v.phase === 'buy') {
      h += panel(`<p class="center h2" style="margin:0">${esc(sq.name)}</p><p class="center" style="margin:4px 0">السعر ${money(sq.price)}</p><div class="row">${btn('اشترِ', { type: 'buy' }, 'grow-btn', meP.cash >= sq.price ? '' : 'disabled')}${btn('اتركه للمزاد', { type: 'decline' }, 'soft grow-btn')}</div>`);
    } else if (v.phase === 'end') {
      h += btn(v.rolledDouble && !meP.jail ? 'زوج! ارمِ مرة أخرى 🎲' : 'أنهِ الدور ✓', { type: 'endTurn' }, 'block');
    }
  } else h += wait(`دور ${nm(ctx, v.turn)}`);
  if (!v.trade && !['auction', 'debt'].includes(v.phase)) h += `<button class="btn soft block" style="margin-top:8px" data-ui="trade">🤝 اعرض صفقة</button>`;
  return h + myProps(ctx, v) + logBlock(v.log);
}

function tradeSheet(ctx) {
  const v = ctx.view;
  const st = (ctx.ui.trade ||= { to: null, give: [], get: [] });
  const draw = () => {
    const others = v.players.filter(p => !p.bankrupt && p.id !== ctx.me);
    const tradable = id => Object.keys(v.props).map(Number).filter(k => v.props[k].owner === id && !(BOARD[k].group && GROUPS[BOARD[k].group].some(x => v.props[x].houses)));
    let h = `<h2>صفقة</h2><div class="target-list">${others.map(p => `<button class="target" aria-pressed="${st.to === p.id}" data-tv="to" data-v="${p.id}">${chip(ctx, p.id)}</button>`).join('')}</div>`;
    if (st.to) {
      const list = (id, key) => tradable(id).map(k => `<button class="chip-btn ${st[key].includes(k) ? 'on' : ''}" data-tv="${key}" data-v="${k}">${esc(BOARD[k].name)}</button>`).join('') || '<span class="muted">لا شيء قابل للتداول</span>';
      h += `<p><b>تعطي:</b></p><div class="row wrap" style="gap:6px">${list(ctx.me, 'give')}</div><div class="field"><label>نقود تعطيها</label><input id="tgc" type="number" min="0" value="0" inputmode="numeric"></div>`;
      h += `<p><b>تأخذ:</b></p><div class="row wrap" style="gap:6px">${list(st.to, 'get')}</div><div class="field"><label>نقود تأخذها</label><input id="tgt" type="number" min="0" value="0" inputmode="numeric"></div>`;
      h += `<button class="btn block" data-tv="send">أرسل العرض</button>`;
    }
    return h + '<button class="btn soft block" style="margin-top:8px" data-sheet-close>إلغاء</button>';
  };
  openSheet(`<div data-sc>${draw()}</div>`, {
    label: 'صفقة', onMount: (el, close) => el.addEventListener('click', async e => {
      const b = e.target.closest('[data-tv]'); if (!b) return;
      const k = b.dataset.tv;
      if (k === 'to') { st.to = b.dataset.v; st.give = []; st.get = []; }
      else if (k === 'give' || k === 'get') { const n = Number(b.dataset.v); const a = st[k]; const i = a.indexOf(n); i >= 0 ? a.splice(i, 1) : a.push(n); }
      else if (k === 'send') {
        const gc = Number(el.querySelector('#tgc').value) || 0, tc = Number(el.querySelector('#tgt').value) || 0;
        const r = await ctx.send({ type: 'proposeTrade', to: st.to, give: { cash: gc, props: st.give }, get: { cash: tc, props: st.get } });
        if (r && r.ok) { ctx.ui.trade = null; close(); }
        return;
      }
      el.querySelector('[data-sc]').innerHTML = draw();
    }),
  });
}

export function onUi(name, el, ctx, rerender) {
  if (name === 'sq') {
    const k = Number(el.dataset.k);
    const v = ctx.view;
    const pr = v.props[k] ? { ...v.props[k], ownerName: v.props[k].owner ? ctx.player(v.props[k].owner)?.name : '' } : null;
    openSheet(propInfo({ ...v, props: { ...v.props, [k]: pr } }, k), { label: BOARD[k].name });
  }
  if (name === 'trade') { ctx.ui.trade = null; tradeSheet(ctx); }
}
export function onFx(e, ctx) {
  const m = { dice: 'dice', buy: 'coin', rent: 'coin', go: 'point', card: 'flip', jail: 'gavel', build: 'bid', bid: 'tap', debt: 'wrong', bankrupt: 'boom', trade: 'secret', 'trade-yes': 'correct', 'trade-no': 'pass', mortgage: 'flip' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'bankrupt') shake();
  if (e.kind === 'game-over') { if ((ctx.view.winner || []).includes(ctx.me)) { ctx.sfx('win'); burst(['#c0392b', '#27ae60', '#f1c40f']); } else ctx.sfx('lose'); }
}

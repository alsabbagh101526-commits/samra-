// واجهة المافيا — تعرض ما يرسله المضيف فقط، وتطلب الإجراءات منه
import { esc, ar, avatar, openSheet } from '../dom.js';
import { mafiaRoleArt, mafiaBackArt, mafiaAmbient } from '../art.js';
import { burst, flash, vibrate } from '../../core/effects.js';

export const theme = 'mafia';
export const kit = 'noir';
export const ambient = () => mafiaAmbient() + '<div class="rain ambient"></div>';

const ROLE = {
  mafia: { name: 'المافيا', team: 'فريق المافيا', desc: 'اتفقوا كل ليلة على ضحية واحدة. وفي النهار تصرّفوا كمواطنين أبرياء.' },
  detective: { name: 'المحقق', team: 'فريق المدينة', desc: 'كل ليلة تحقّق من لاعب واحد لتعرف سرًا إن كان من المافيا.' },
  doctor: { name: 'الطبيب', team: 'فريق المدينة', desc: 'كل ليلة احمِ لاعبًا واحدًا من رصاص المافيا.' },
  civilian: { name: 'المواطن', team: 'فريق المدينة', desc: 'لا قدرة ليلية. سلاحك عقلك وصوتك في النهار.' },
};
export const roleName = r => ROLE[r]?.name || '';

function cardFront(role) {
  const r = ROLE[role];
  return `<div class="cf">
    <div class="cf-head"><span class="cf-type">${r.team}</span><span class="stamp">سري</span></div>
    <div class="cf-photo cf-art">${mafiaRoleArt(role).replace('<svg ', '<svg preserveAspectRatio="xMidYMid slice" ')}</div>
    <div><h3 class="cf-name">${r.name}</h3><p class="cf-desc">${r.desc}</p></div>
  </div>`;
}

export function roleCard(role, { flipped = false, size = '', hint = 'اضغط لكشف دورك', attrs = '' } = {}) {
  return `<div class="card mafia-card ${size} ${role === 'mafia' ? 'is-mafia' : ''} ${flipped ? 'is-flipped' : ''}" ${attrs}>
    <div class="card-inner">
      <div class="card-face card-back">${mafiaBackArt()}${hint ? `<div class="tap-hint" style="color:#2b2113">${hint}</div>` : ''}</div>
      <div class="card-face card-front">${role ? cardFront(role) : ''}</div>
    </div></div>`;
}

const nm = (ctx, id) => esc(ctx.player(id)?.name || '؟');
const who = (ctx, id) => `${avatar(ctx.player(id), 'sm')} <b>${nm(ctx, id)}</b>`;

export function headerExtra(ctx) {
  const v = ctx.view;
  if (!v.me || v.phase === 'over') return '';
  return `<button class="icon-btn" data-ui="peek" aria-label="اعرض بطاقتي">🂠</button>`;
}

export function render(ctx) {
  const v = ctx.view;
  const me = v.me;
  document.body.classList.toggle('is-night', v.phase === 'night');
  const alive = v.players.filter(p => p.alive);
  let html = '';

  if (v.phase === 'roles') {
    const readyN = v.players.filter(p => p.ready).length;
    if (!me.ready) {
      html += `<p class="center soft" style="margin:4px 0 14px">كل لاعب يكشف دوره على جواله بعيدًا عن أعين الآخرين.</p>
        ${roleCard(me.role, { flipped: !!ctx.ui.revealed, attrs: 'data-ui="reveal" role="button" tabindex="0" aria-label="اكشف دورك"' })}`;
      if (ctx.ui.revealed) {
        html += `<p class="private-note">هذه المعلومة خاصة بك — لا تعرضها للاعبين الآخرين.</p>`;
        if (me.team) html += teamBlock(ctx, me.team);
        html += `<div style="margin-top:16px"><button class="btn block" data-act='{"type":"ready"}'>حفظت دوري — جاهز</button></div>`;
      }
    } else {
      html += `<div class="big-status"><p class="h2">بانتظار البقية<span class="waiting-dots"></span></p>
        <p class="soft">${ar(readyN)} من ${ar(v.players.length)} جاهزون</p></div>
        ${roleCard(me.role, { size: 'md', hint: 'دورك مخفي' })}`;
    }
    return html;
  }

  if (v.phase === 'night') {
    html += `<h2 class="night-title phase-in">الليلة ${ar(v.night)}</h2>
      <p class="center soft" style="margin:0 0 14px">المدينة نائمة… أنهى ${ar(v.nightDone)} من ${ar(v.nightTotal)}</p>`;
    html += lastVoteBlock(ctx);
    if (!me.alive) return html + deadNote();
    if (me.done && me.role !== 'detective' && me.role !== 'mafia') {
      return html + `<div class="panel center phase-in"><p class="h2">نم بسلام</p><p class="soft">${me.role === 'doctor' && me.protected ? 'تحمي الليلة: ' + who(ctx, me.protected) : 'انتظر حتى يطلع الصبح'}</p></div>`;
    }
    if (me.role === 'mafia') {
      if (!v.options.killTonight) {
        html += teamBlock(ctx, me.team);
        html += me.done ? `<div class="panel center"><p>بانتظار الصبح…</p></div>` : `<p class="soft center">لا قتل في الليلة الأولى حسب إعدادات الغرفة.</p><button class="btn block" data-act='{"type":"sleep"}'>تم</button>`;
        return html;
      }
      if (me.locked) {
        return html + `<div class="panel center pop-in"><p class="soft">اتفقتم على الضحية</p><p class="h2">${who(ctx, me.locked)}</p></div>`;
      }
      html += `<p class="center" style="margin:0 0 10px"><b>اختر الضحية.</b> <span class="soft">يجب أن تتفق كل المافيا على نفس الشخص.</span></p>`;
      html += targets(ctx, alive.filter(p => !me.team.some(t => t.id === p.id)).map(p => p.id), {
        action: 'mafiaPick', selected: me.picks?.[ctx.me],
        mark: id => Object.entries(me.picks || {}).filter(([k, t]) => t === id && k !== ctx.me).map(([k]) => '🗡 ' + nm(ctx, k)).join('، '),
      });
      return html + teamBlock(ctx, me.team);
    }
    if (me.role === 'doctor') {
      html += `<p class="center" style="margin:0 0 10px"><b>من تحمي الليلة؟</b></p>`;
      html += targets(ctx, alive.map(p => p.id), {
        action: 'protect',
        disabled: id => (id === ctx.me && !v.options.doctorSelf) || (id === me.lastProtected && !v.options.doctorRepeat),
        mark: id => id === me.lastProtected && !v.options.doctorRepeat ? 'حميته الليلة الماضية' : '',
      });
      return html;
    }
    if (me.role === 'detective') {
      const last = me.investigations[me.investigations.length - 1];
      if (me.done && last && last.night === v.night) {
        html += `<div class="panel center pop-in"><p class="soft">نتيجة التحقيق السري</p>
          <p class="h2" style="margin:8px 0">${who(ctx, last.target)}</p>
          <p class="h2" style="color:${last.isMafia ? 'var(--accent)' : 'var(--ok)'}">${last.isMafia ? '⚠ من المافيا' : '✓ ليس من المافيا'}</p>
          <p class="private-note">هذه المعلومة خاصة بك — لا تعرضها للاعبين الآخرين.</p></div>`;
      } else {
        html += `<p class="center" style="margin:0 0 10px"><b>من تريد التحقيق معه؟</b></p>`;
        html += targets(ctx, alive.filter(p => p.id !== ctx.me).map(p => p.id), { action: 'investigate' });
      }
      return html + investigationsBlock(ctx, me.investigations.filter(x => x.night !== v.night || !me.done));
    }
    // المواطن: اختيار للتمويه فقط
    html += `<p class="center" style="margin:0 0 10px"><b>من تشك فيه؟</b> <span class="soft">(للتمويه فقط — لا يؤثر على اللعبة)</span></p>`;
    html += targets(ctx, alive.filter(p => p.id !== ctx.me).map(p => p.id), { action: 'sleep' });
    return html;
  }

  if (v.phase === 'day' || v.phase === 'vote') {
    const ln = v.lastNight;
    if (v.phase === 'day' && ln && ln.night === v.night) {
      if (ln.killed) {
        const p = v.players.find(x => x.id === ln.killed);
        html += `<div class="dawn-card death phase-in"><p class="soft">أشرقت الشمس… ووجدت المدينة</p>
          <div class="row" style="justify-content:center">${avatar(ctx.player(ln.killed), 'lg')}</div>
          <p class="who">${nm(ctx, ln.killed)}</p><p class="soft">${ln.killed === ctx.me ? 'لقد قُتلت هذه الليلة.' : 'قُتل هذه الليلة.'}${p.role ? ' كان: <b>' + roleName(p.role) + '</b>' : ''}</p></div>`;
      } else {
        html += `<div class="dawn-card phase-in"><p class="who">لم يمت أحد الليلة</p><p class="soft">نجت المدينة… هذه المرة.</p></div>`;
      }
    }
    if (v.phase === 'day') {
      html += `<div class="panel center" style="margin-top:14px"><p class="h2">النقاش — اليوم ${ar(v.day)}</p>
        ${v.deadline ? `<div class="timer" data-deadline="${v.deadline}">--:--</div>` : '<p class="soft">بدون مؤقت</p>'}
        ${ctx.isHost ? `<button class="btn block" style="margin-top:10px" data-act='{"type":"startVote"}'>ابدأ التصويت الآن</button>` : `<p class="muted">المضيف يبدأ التصويت عند انتهاء النقاش.</p>`}</div>`;
      html += aliveList(ctx);
      return html;
    }
    // التصويت
    const votedN = v.players.filter(p => p.voted).length;
    html += `<h2 class="h2 center" style="margin:10px 0">التصويت — من تُقصي المدينة؟</h2>
      <p class="center soft">صوّت ${ar(votedN)} من ${ar(alive.length)}</p>`;
    if (!me.alive) html += deadNote();
    else if (me.vote == null) {
      html += targets(ctx, alive.filter(p => p.id !== ctx.me).map(p => p.id), { action: 'vote' });
      html += `<button class="btn ghost block" style="margin-top:10px" data-act='{"type":"vote","target":"skip"}'>لا أحد (تخطٍّ)</button>`;
    } else {
      html += `<div class="panel center pop-in"><p>صوّتّ: <b>${me.vote === 'skip' ? 'لا أحد' : nm(ctx, me.vote)}</b></p><p class="soft">بانتظار البقية<span class="waiting-dots"></span></p></div>`;
    }
    html += `<div class="row wrap" style="justify-content:center;margin-top:12px">${alive.map(p => `<span class="badge ${p.voted ? 'ok' : ''}">${esc(ctx.player(p.id)?.emoji || '')} ${nm(ctx, p.id)} ${p.voted ? '✓' : '…'}</span>`).join('')}</div>`;
    if (ctx.isHost) html += `<button class="btn soft block" style="margin-top:14px" data-act='{"type":"closeVote"}'>أغلق التصويت الآن</button>`;
    return html;
  }

  if (v.phase === 'over') {
    const myTeam = me ? (me.role === 'mafia' ? 'mafia' : 'town') : null;
    html += `<div class="center pop-in" style="padding:10px 0 4px">
      <p class="h1" style="color:${v.winner === 'mafia' ? 'var(--accent)' : 'var(--accent-2)'}">${v.winner === 'mafia' ? 'انتصرت المافيا' : 'انتصرت المدينة'}</p>
      ${myTeam ? `<p class="soft">${myTeam === v.winner ? 'فريقك فاز 🎉' : 'خسر فريقك هذه المرة'}</p>` : ''}</div>`;
    html += lastVoteBlock(ctx);
    html += `<div class="reveal-grid" style="margin-top:16px">${v.players.map((p, k) => `<div>
      ${roleCard(p.role, { size: 'sm', hint: '', attrs: `data-stagger="${k}"` })}
      <div class="who">${avatar(ctx.player(p.id), 'sm')} ${nm(ctx, p.id)}${p.alive ? '' : ' <span class="muted">(خارج)</span>'}</div></div>`).join('')}</div>`;
    return html;
  }
  return html;
}

function teamBlock(ctx, team) {
  return `<div class="panel" style="margin-top:14px"><p style="margin:0 0 8px"><b>أفراد المافيا:</b></p>
    <div class="row wrap">${team.map(t => `<span class="badge ${t.alive ? '' : 'off'}">${esc(ctx.player(t.id)?.emoji || '')} ${nm(ctx, t.id)}${t.id === ctx.me ? ' (أنت)' : ''}</span>`).join('')}</div></div>`;
}

function investigationsBlock(ctx, list) {
  if (!list.length) return '';
  return `<div class="panel" style="margin-top:14px"><p style="margin:0 0 6px"><b>تحقيقاتك السابقة</b> <span class="muted">(سرية)</span></p>
    ${list.map(x => `<div class="row spread" style="padding:4px 0"><span>${nm(ctx, x.target)}</span><span class="badge ${x.isMafia ? 'off' : 'ok'}">${x.isMafia ? 'مافيا' : 'بريء'}</span></div>`).join('')}</div>`;
}

function lastVoteBlock(ctx) {
  const lv = ctx.view.lastVote;
  if (!lv || lv.day !== ctx.view.day) return '';
  const p = lv.eliminated ? ctx.view.players.find(x => x.id === lv.eliminated) : null;
  return `<div class="dawn-card ${lv.eliminated ? 'death' : ''}" style="margin-bottom:14px">
    <p class="soft" style="margin:0">نتيجة تصويت اليوم ${ar(lv.day)}</p>
    <p class="who" style="font-size:26px">${lv.eliminated ? 'أُقصي: ' + nm(ctx, lv.eliminated) : 'لم يُقصَ أحد'}</p>
    ${p && p.role ? `<p class="soft" style="margin:0">كان: <b>${roleName(p.role)}</b></p>` : ''}
    <details style="margin-top:8px"><summary class="soft" style="cursor:pointer">تفاصيل الأصوات</summary>
      ${lv.votes.filter(x => x.to).map(x => `<div class="row spread" style="padding:3px 0;font-size:15px"><span>${nm(ctx, x.from)}</span><span class="muted">← ${x.to === 'skip' ? 'لا أحد' : nm(ctx, x.to)}</span></div>`).join('')}
    </details></div>`;
}

function aliveList(ctx) {
  return `<div style="margin-top:14px">${ctx.view.players.map(p => `<div class="player-row">${avatar(ctx.player(p.id))}<span class="name">${nm(ctx, p.id)}${p.id === ctx.me ? ' (أنت)' : ''}</span>
    ${p.alive ? '<span class="badge ok">حي</span>' : `<span class="badge off">خارج${p.role ? ' — ' + roleName(p.role) : ''}</span>`}</div>`).join('')}</div>`;
}

function deadNote() {
  return `<div class="panel center"><p class="h2">أنت خارج اللعبة</p><p class="soft">راقب بصمت، ولا تكشف أي معلومة حتى نهاية اللعبة.</p></div>`;
}

function targets(ctx, ids, { action, selected = null, disabled = () => false, mark = () => '' }) {
  return `<div class="target-list">${ids.map(id => {
    const d = disabled(id);
    const m = mark(id);
    return `<button class="target" ${d ? 'disabled' : ''} aria-pressed="${selected === id}" data-act='${JSON.stringify({ type: action, target: id })}'>
      ${avatar(ctx.player(id), 'sm')}<span class="t-name">${nm(ctx, id)}${id === ctx.me ? ' (أنت)' : ''}${m ? `<br><span class="t-mark">${esc(m)}</span>` : ''}</span></button>`;
  }).join('')}</div>`;
}

export function screenKey(v) { return [v.phase, v.day, v.night, v.me?.done, v.me?.locked].join(':'); }

// بعد الرسم: تحريك الكشف التدريجي في النهاية
export function after(root, ctx) {
  const cards = root.querySelectorAll('[data-stagger]');
  cards.forEach(c => setTimeout(() => c.classList.add('is-flipped'), 250 + Number(c.dataset.stagger) * 160));
}

export function onUi(name, el, ctx, rerender) {
  if (name === 'reveal' && !ctx.ui.revealed) {
    ctx.ui.revealed = true;
    el.classList.add('is-flipped');
    ctx.sfx('reveal'); vibrate(40);
    setTimeout(rerender, 760);
  }
  if (name === 'peek') {
    openSheet(`<h2>بطاقتي</h2>${roleCard(ctx.view.me.role, { flipped: true })}
      <p class="private-note">هذه المعلومة خاصة بك — لا تعرضها للاعبين الآخرين.</p>
      ${ctx.view.me.team ? teamBlock(ctx, ctx.view.me.team) : ''}
      <button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'بطاقتي' });
    ctx.sfx('secret');
  }
}

export function onAct(a, ctx) {
  if (a.type === 'ready') ctx.ui.revealed = false;
}

export function onFx(e, ctx) {
  const v = ctx.view;
  switch (e.kind) {
    case 'night': ctx.sfx('night'); break;
    case 'dawn-death': ctx.sfx('dawnDeath'); flash('#5a0b0f'); vibrate(80); break;
    case 'dawn-safe': ctx.sfx('dawnSafe'); break;
    case 'vote': ctx.sfx('vote'); break;
    case 'eliminated': ctx.sfx('eliminated'); flash('#3a0a0c'); break;
    case 'no-elim': ctx.sfx('dawnSafe'); break;
    case 'locked': case 'investigated': ctx.sfx('secret'); vibrate(30); break;
    case 'phase': ctx.sfx('tick'); break;
    case 'game-over': {
      const mine = v.me ? (v.me.role === 'mafia' ? 'mafia' : 'town') : null;
      if (mine === v.winner) { ctx.sfx('win'); burst(['#c42127', '#d8b46a', '#ece3d2']); } else ctx.sfx('lose');
      break;
    }
  }
}

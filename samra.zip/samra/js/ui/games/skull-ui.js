// واجهة الجمجمة — أقراص فاخرة تُقلب، وطاولة بسجادات اللاعبين
import { esc, ar, avatar } from '../dom.js';
import { discArt } from '../art.js';
import { burst, shake, vibrate } from '../../core/effects.js';

export const theme = 'skull';
export const kit = 'luxe';
export const ambient = () => '';

const DISC_NAME = { rose: 'وردة', skull: 'جمجمة' };

function disc(kind, { flipped = true, size = '', attrs = '', label = '' } = {}) {
  return `<button class="disc ${size} ${flipped ? 'is-flipped' : ''}" ${attrs} aria-label="${esc(label || DISC_NAME[kind] || 'قرص مقلوب')}">
    <span class="disc-inner"><span class="disc-face disc-back">${discArt('back')}</span><span class="disc-face disc-front">${kind ? discArt(kind) : ''}</span></span></button>`;
}

const nm = (ctx, id) => esc(ctx.player(id)?.name || '؟');

export function headerExtra() { return ''; }

export function render(ctx) {
  const v = ctx.view;
  const me = v.me;
  const myP = v.players.find(p => p.id === ctx.me);
  const myTurn = v.turn === ctx.me;
  ctx.ui.revealSeen ||= {};
  let html = `<p class="center soft" style="margin:0 0 8px">الجولة ${ar(v.round)} · على الطاولة ${ar(v.onTable)} ${v.onTable === 1 ? 'قرص' : 'أقراص'}</p>`;

  // سطر الحالة
  html += `<div class="panel center" style="margin-bottom:12px">${statusLine(ctx)}</div>`;

  // السجادات
  const canFlip = v.phase === 'reveal' && v.challenger === ctx.me && v.ownDone;
  html += `<div class="mats">${v.players.map(p => {
    const isMe = p.id === ctx.me;
    const hidden = p.stackCount - p.revealed.length;
    const flippable = canFlip && !isMe && hidden > 0;
    const seenKey = p.id;
    const seen = ctx.ui.revealSeen[seenKey] || 0;
    const revealed = p.revealed.map((k, j) => disc(k, { size: 'sm', flipped: j < seen, attrs: j >= seen ? 'data-newflip tabindex="-1"' : 'tabindex="-1"' })).join('');
    ctx.ui.revealSeen[seenKey] = p.revealed.length;
    return `<div class="mat ${v.turn === p.id && v.phase !== 'roundEnd' ? 'is-turn' : ''} ${p.wins > 0 ? 'won' : ''} ${p.alive ? '' : 'out'} ${flippable ? 'can-flip' : ''}"
      ${flippable ? `role="button" tabindex="0" data-act='${JSON.stringify({ type: 'flip', target: p.id })}' aria-label="اكشف القرص العلوي من كومة ${nm(ctx, p.id)}"` : ''}>
      ${v.turn === p.id && v.phase !== 'roundEnd' && v.phase !== 'over' ? '<span class="turn-tag">الدور</span>' : ''}
      ${avatar(ctx.player(p.id), 'sm')}
      <div class="mname">${nm(ctx, p.id)}${isMe ? ' (أنت)' : ''}</div>
      <div class="meta">${p.alive ? `${ar(p.discs)} أقراص · ${p.wins ? '⭐ نقطة' : 'بلا نقاط'}` : 'خرج من اللعبة'}${p.passed ? ' · مرّر' : ''}</div>
      <div class="row" style="justify-content:center;gap:6px;min-height:42px">
        ${hidden > 0 ? `<div class="pile" title="${ar(hidden)} مخفية">${Array.from({ length: Math.min(hidden, 4) }, (_, k) => `<span class="disc sm" style="top:${12 - k * 4}px"><span class="disc-inner"><span class="disc-face disc-back">${discArt('back')}</span></span></span>`).join('')}</div><span class="meta">×${ar(hidden)}</span>` : ''}
        ${p.revealed.length ? `<div class="revealed">${revealed}</div>` : ''}
      </div>
      ${v.phase === 'over' && p.total ? `<div class="meta">بقي: ${ar(p.total.rose)} ورود${p.total.skull ? ' + جمجمة' : ''}</div>` : ''}
    </div>`;
  }).join('')}</div>`;

  if (!me || !myP) return html;

  // منطقة اللاعب
  if (myP.alive && v.phase !== 'over') {
    const canPlace = (v.phase === 'setup' && me.stack.length === 0) || (v.phase === 'turn' && myTurn);
    const handDiscs = [];
    for (let k = 0; k < me.hand.rose; k++) handDiscs.push('rose');
    for (let k = 0; k < me.hand.skull; k++) handDiscs.push('skull');
    const sel = ctx.ui.selected;
    html += `<div class="panel" style="margin-top:14px">
      <div class="row spread"><b>يدي</b><span class="muted" style="font-size:14px">أقراصي: ${ar(me.total.rose)} ورود${me.total.skull ? ' + جمجمة' : ' — بلا جمجمة'}</span></div>
      <div class="hand">${handDiscs.length ? handDiscs.map((k, j) => disc(k, { attrs: `data-ui="select" data-kind="${k}" aria-pressed="${canPlace && sel === k && handDiscs.indexOf(k) === j}" ${canPlace ? '' : 'disabled'}` })).join('') : '<p class="muted">كل أقراصك على الطاولة</p>'}</div>
      ${canPlace && handDiscs.length ? `<button class="btn block" ${sel && me.hand[sel] > 0 ? '' : 'disabled'} data-act='${JSON.stringify({ type: 'place', disc: sel || 'rose' })}'>${sel ? 'ضع ' + DISC_NAME[sel] + ' مقلوبة' : 'اختر قرصًا من يدك'}</button>` : ''}
      ${me.stack.length ? `<div class="row" style="margin-top:12px;gap:6px;flex-wrap:wrap"><span class="muted" style="font-size:14px">كومتي (من الأسفل للأعلى):</span>${me.stack.map(k => disc(k, { size: 'xs', attrs: 'tabindex="-1"' })).join('')}</div>` : ''}
    </div>`;
  }

  // التحدي
  if ((v.phase === 'turn' || v.phase === 'bidding') && myTurn && myP.alive) {
    const min = v.bid ? v.bid.amount + 1 : 1;
    const max = v.onTable;
    if (min <= max) {
      if (!(ctx.ui.bid >= min && ctx.ui.bid <= max)) ctx.ui.bid = min;
      html += `<div class="panel" style="margin-top:12px">
        <p class="center" style="margin:0 0 6px">${v.bid ? 'ارفع التحدي' : 'أو ابدأ تحديًا: كم وردة تستطيع كشفها؟'}</p>
        <div class="stepper"><button class="icon-btn" data-ui="bid-dec" aria-label="أقل">−</button><span class="num" aria-live="polite">${ar(ctx.ui.bid)}</span><button class="icon-btn" data-ui="bid-inc" aria-label="أكثر">+</button></div>
        <button class="btn block" style="margin-top:10px" data-act='${JSON.stringify({ type: 'bid', amount: ctx.ui.bid })}'>${v.bid ? 'ارفع إلى ' : 'أتحدى بـ '}${ar(ctx.ui.bid)}</button>
      </div>`;
    }
    if (v.phase === 'bidding') html += `<button class="btn ghost block" style="margin-top:10px" data-act='{"type":"pass"}'>مرّر</button>`;
  }

  if (v.phase === 'reveal' && v.challenger === ctx.me && !v.ownDone) {
    html += `<button class="btn block" style="margin-top:12px" data-act='{"type":"revealOwn"}'>اكشف أقراصي أولًا</button>`;
  }

  if (v.phase === 'discard' && v.challenger === ctx.me) {
    html += `<div class="panel" style="margin-top:12px"><p class="center">كشفت جمجمتك! اختر القرص الذي ستخسره:</p>
      <div class="row" style="justify-content:center;gap:24px">
        ${me.total.rose ? `<div class="center">${disc('rose', { attrs: `data-act='{"type":"discard","disc":"rose"}'` })}<div>وردة</div></div>` : ''}
        ${me.total.skull ? `<div class="center">${disc('skull', { attrs: `data-act='{"type":"discard","disc":"skull"}'` })}<div>الجمجمة</div></div>` : ''}
      </div></div>`;
  }

  if (v.phase === 'roundEnd') {
    const canNext = v.starter === ctx.me || ctx.isHost;
    html += `<div style="margin-top:12px">${canNext ? `<button class="btn block" data-act='{"type":"next"}'>ابدأ الجولة التالية</button>` : `<p class="center muted">${nm(ctx, v.starter)} يبدأ الجولة التالية</p>`}</div>`;
  }
  return html;
}

function statusLine(ctx) {
  const v = ctx.view, me = v.me;
  const myTurn = v.turn === ctx.me;
  switch (v.phase) {
    case 'setup': return me && me.stack.length === 0 && v.players.find(p => p.id === ctx.me)?.alive
      ? '<p class="h2" style="margin:0">ضع قرصك الأول مقلوبًا</p>'
      : `<p style="margin:0">بانتظار وضع الأقراص الأولى<span class="waiting-dots"></span></p>`;
    case 'turn': return myTurn ? '<p class="h2" style="margin:0">دورك</p><p class="soft" style="margin:0">أضف قرصًا لكومتك أو ابدأ التحدي</p>' : `<p style="margin:0">دور <b>${nm(ctx, v.turn)}</b></p>`;
    case 'bidding': return `<div class="bid-display">التحدي: <b>${ar(v.bid.amount)}</b> ورود</div><p class="soft" style="margin:0">من ${nm(ctx, v.bid.by)} · ${myTurn ? 'دورك: ارفع أو مرّر' : 'الدور لـ ' + nm(ctx, v.turn)}</p>`;
    case 'reveal': return `<div class="bid-display">${ar(v.rosesFound)} / <b>${ar(v.bid.amount)}</b></div><p class="soft" style="margin:0">${v.challenger === ctx.me ? (v.ownDone ? 'اختر كومة لاعب لتكشف قرصها العلوي' : 'ابدأ بكشف أقراصك') : nm(ctx, v.challenger) + ' يكشف الأقراص…'}</p>`;
    case 'discard': return `<p style="margin:0">${nm(ctx, v.challenger)} كشف جمجمته… يختار قرصًا ليخسره</p>`;
    case 'roundEnd': {
      const r = v.result;
      if (r.type === 'success') return `<p class="h2" style="margin:0">نجح ${nm(ctx, r.challenger)}!</p><p class="soft" style="margin:0">كشف ${ar(r.amount)} ورود وحصل على نقطة</p>`;
      let s = `<p class="h2" style="margin:0">جمجمة ${r.skullOwner === r.challenger ? 'المتحدي نفسه' : nm(ctx, r.skullOwner)}!</p><p class="soft" style="margin:0">${nm(ctx, r.challenger)} خسر قرصًا${r.eliminated ? ' وخرج من اللعبة' : ''}</p>`;
      if (me && me.lost) s += `<p class="private-note">خسرت: <b>${DISC_NAME[me.lost]}</b> — لا يعرف ذلك غيرك</p>`;
      return s;
    }
    case 'over': return `<p class="h1" style="margin:0">🏆 ${nm(ctx, v.winner)}</p><p class="soft" style="margin:0">${v.winner === ctx.me ? 'فزت باللعبة!' : 'فاز باللعبة'}</p>`;
  }
  return '';
}

export function screenKey(v) { return [v.phase, v.round].join(':'); }

export function after(root) {
  // أقراص كُشفت للتو: تُقلب أمام الجميع
  const fresh = root.querySelectorAll('[data-newflip]');
  if (fresh.length) requestAnimationFrame(() => requestAnimationFrame(() => fresh.forEach(d => d.classList.add('is-flipped'))));
}

export function onUi(name, el, ctx, rerender) {
  const v = ctx.view;
  if (name === 'select') { ctx.ui.selected = el.dataset.kind; ctx.sfx('tap'); rerender(); }
  if (name === 'bid-inc') { if (ctx.ui.bid < v.onTable) { ctx.ui.bid++; ctx.sfx('tap'); rerender(); } }
  if (name === 'bid-dec') { const min = v.bid ? v.bid.amount + 1 : 1; if (ctx.ui.bid > min) { ctx.ui.bid--; ctx.sfx('tap'); rerender(); } }
}

export function onAct(a, ctx) {
  if (a.type === 'place') ctx.ui.selected = null;
}

export function onFx(e, ctx, root) {
  switch (e.kind) {
    case 'place': ctx.sfx('place'); break;
    case 'bid': case 'challenge': ctx.sfx('bid'); break;
    case 'pass': ctx.sfx('pass'); break;
    case 'flip-rose': ctx.sfx('rose'); break;
    case 'flip-skull': ctx.sfx('skull'); shake(root); vibrate(90); break;
    case 'point': ctx.sfx('point'); burst(['#c9a14a', '#f1e6d0', '#a3122a'], 40); break;
    case 'lose-disc': ctx.sfx('lose'); break;
    case 'eliminated': ctx.sfx('skull'); break;
    case 'round-start': ctx.sfx('round'); ctx.ui.revealSeen = {}; break;
    case 'game-over': if (e.who === ctx.me) { ctx.sfx('win'); burst(['#c9a14a', '#f1e6d0', '#a3122a']); } else ctx.sfx('lose'); break;
  }
}

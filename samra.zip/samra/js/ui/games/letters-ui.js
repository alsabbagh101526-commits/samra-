// واجهة تحدي الحروف — شبكة سداسية بنفسجية، برتقالي وأخضر، وجرس كبير
import { ar, esc } from '../dom.js';
import { nm, who, btn, wait, panel, teamsBlock, winnerBanner, act } from '../kit.js';
import { burst, flash, vibrate } from '../../core/effects.js';

export const theme = 'letters';
export const kit = 'pop';
export const ambient = () => '';
const LBL = { A: 'البرتقالي ↕', B: 'الأخضر ↔' };

function grid(v, pickable) {
  let h = '<div class="hex-wrap"><div class="hex-edge top"></div><div class="hex-grid">';
  for (let r = 0; r < 5; r++) {
    h += `<div class="hex-row ${r % 2 ? 'odd' : ''}">`;
    for (let c = 0; c < 5; c++) {
      const k = r * 5 + c, o = v.owner[k];
      const can = pickable && !o;
      h += `<button class="hex ${o ? 'own-' + o : ''} ${v.cell === k ? 'now' : ''}" ${can ? act({ type: 'pick', cell: k }) : 'disabled'} aria-label="حرف ${v.letters[k]}">${v.letters[k]}</button>`;
    }
    h += '</div>';
  }
  return h + '</div><div class="hex-edge bottom"></div></div>';
}

export const screenKey = v => [v.phase, v.board, v.cell].join(':');

export function render(ctx) {
  const v = ctx.view;
  const isMod = v.host === ctx.me;
  const myTeam = v.myTeam;
  let h = teamsBlock(ctx, v.teams, LBL, v.boards > 1 ? v.wins : null);
  h += `<p class="center muted" style="margin:4px 0">المقدم: ${nm(ctx, v.host)}${v.boards > 1 ? ` • اللوحة ${ar(v.board)}` : ''}</p>`;
  const canPick = v.phase === 'pick' && (isMod || (v.picker && myTeam === v.picker));
  h += grid(v, canPick);
  if (v.phase === 'pick') {
    h += canPick ? `<p class="center">اختر حرفًا من الشبكة</p>` : wait(v.picker ? `${LBL[v.picker]} يختار الحرف` : 'المقدم يختار الحرف');
  } else if (v.phase === 'buzz') {
    const letter = v.letters[v.cell];
    h += `<div class="panel center letters-q pop-in"><p class="h2" style="margin:0">${esc(v.prompt)} يبدأ بحرف «${letter}»</p></div>`;
    if (v.buzz) h += `<p class="center h2" style="margin:10px 0">🔔 ${who(ctx, v.buzz.id)} يجاوب</p>`;
    if (isMod) {
      if (v.buzz) h += `<div class="row">${btn('صح ✓', { type: 'judge', correct: true }, 'grow-btn')}${btn('خطأ ✕', { type: 'judge', correct: false }, 'danger grow-btn')}</div>`;
      else h += wait('بانتظار الجرس');
      h += `<div class="row" style="margin-top:8px">${btn('سؤال آخر لنفس الحرف', { type: 'reprompt' }, 'soft grow-btn')}${btn('تخطَّ الحرف', { type: 'skip' }, 'soft grow-btn')}</div>`;
    } else if (myTeam) {
      const locked = v.locked.includes(myTeam);
      if (!v.buzz && !locked) h += `<button class="buzzer buzzer-${myTeam}" ${act({ type: 'buzz' })}>جرس!</button>`;
      else if (locked) h += `<p class="center muted">فريقك أخطأ في هذا الحرف</p>`;
    }
  } else if (v.phase === 'boardEnd') {
    h += panel(`<p class="center h2" style="margin:0">${LBL[v.boardWinner]} أكمل المسار!</p>`);
    if (isMod) h += btn('اللوحة التالية', { type: 'nextBoard' }, 'block');
  } else if (v.phase === 'over') {
    h = winnerBanner(`فاز ${LBL[v.winner]}`, '', v.winner === 'A' ? '#ff8800' : '#2bb673') + h;
  }
  return h;
}
export function onFx(e, ctx) {
  const m = { pick: 'flip', buzz: 'buzz', correct: 'correct', wrong: 'wrong', 'board-win': 'win', 'round-start': 'round' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'buzz') vibrate(40);
  if (e.kind === 'correct') flash(e.team === 'A' ? '#ff8800' : '#2bb673');
  if (e.kind === 'game-over') { if (ctx.view.winner === ctx.view.myTeam) burst(['#ff8800', '#2bb673', '#fff']); }
}

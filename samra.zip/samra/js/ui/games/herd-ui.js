// واجهة عقلية القطيع — مرعى أخضر فاتح وبقرة وردية
import { ar, esc } from '../dom.js';
import { nm, chip, btn, wait, panel, winnerBanner, act } from '../kit.js';
import { burst } from '../../core/effects.js';

export const theme = 'herd';
export const kit = 'pop';
export const ambient = () => '';
const cow = (pink) => `<svg viewBox="0 0 64 48" width="40" height="30"><ellipse cx="32" cy="28" rx="24" ry="16" fill="${pink ? '#ff70a6' : '#fff'}" stroke="#333" stroke-width="2"/><circle cx="22" cy="24" r="5" fill="${pink ? '#c2185b' : '#333'}"/><ellipse cx="50" cy="20" rx="10" ry="8" fill="${pink ? '#ff9ec4' : '#f5d0c5'}" stroke="#333" stroke-width="2"/></svg>`;

export const screenKey = v => [v.phase, v.round].join(':');

function scores(ctx, v) {
  return `<div class="herd-scores">${v.players.slice().sort((a, b) => b.score - a.score).map(p => `<div class="row spread"><span>${chip(ctx, p.id, p.id === ctx.me ? ' (أنت)' : '')}${v.cow === p.id ? ' ' + cow(true) : ''}</span><b>${'🐮'.repeat(Math.min(p.score, 10))} ${ar(p.score)}</b></div>`).join('')}</div>`;
}

export function render(ctx) {
  const v = ctx.view;
  let h = `<p class="center muted" style="margin:0">السؤال ${ar(v.round)} • الهدف ${ar(v.target)} أبقار</p><div class="herd-q pop-in"><p class="h2" style="margin:0">${esc(v.question)}</p></div>`;
  if (v.phase === 'answer') {
    if (v.me && !v.me.answer) h += `<div class="field"><input id="hans" maxlength="30" placeholder="اكتب إجابة الأغلبية" autocomplete="off"></div><button class="btn block" data-act='{"type":"answer"}' data-input='{"text":"#hans"}'>أرسل</button>`;
    else h += wait(`إجابتك: «${esc(v.me?.answer || '')}» — بانتظار البقية`);
    h += `<div class="row wrap" style="justify-content:center;gap:6px;margin-top:12px">${v.players.map(p => chip(ctx, p.id, p.answered ? ' ✓' : ' …', p.answered ? 'ok' : '')).join('')}</div>`;
    if (ctx.isHost && v.players.some(p => p.answered)) h += `<div style="margin-top:10px">${btn('اكشف الإجابات الآن', { type: 'close' }, 'soft block')}</div>`;
  } else if (v.phase === 'group') {
    h += `<p class="center">الإجابات المتشابهة جُمعت تلقائيًا${ctx.isHost ? '. ادمج المجموعات التي تعني نفس الشيء:' : '. المضيف يراجع الدمج:'}</p>`;
    const sel = ctx.ui.mergeFrom;
    h += `<div class="stack">${v.groups.map((g, k) => `<div class="panel herd-group ${sel === k ? 'sel' : ''}"><div class="row spread"><b>${esc(g.label)}</b><span class="badge">${ar(g.members.length)}</span></div><div class="row wrap" style="gap:4px;margin-top:6px">${g.members.map(id => chip(ctx, id)).join('')}</div>
      ${ctx.isHost ? `<div class="row" style="margin-top:8px">${sel == null ? `<button class="btn soft" data-ui="mfrom" data-k="${k}">ادمج هذه مع…</button>` : sel === k ? `<button class="btn soft" data-ui="mcancel">إلغاء</button>` : btn('ادمج هنا', { type: 'merge', from: sel, into: k }, 'soft')}</div>` : ''}</div>`).join('')}</div>`;
    if (ctx.isHost) h += `<div style="margin-top:12px">${btn('اعتمد النتيجة', { type: 'confirm' }, 'block')}</div>`;
    else h += wait('المضيف يعتمد النتيجة');
  } else if (v.phase === 'result' || v.phase === 'over') {
    const r = v.result;
    h += panel(r.herd.length ? `<p class="center" style="margin:0">القطيع: ${r.herd.map(id => chip(ctx, id)).join(' ')} — نقطة لكل واحد 🐮</p>` : '<p class="center" style="margin:0">تعادل في الأغلبية — لا نقاط هذه الجولة</p>');
    if (r.cowTo) h += panel(`<p class="center" style="margin:0">${cow(true)} البقرة الوردية انتقلت إلى <b>${nm(ctx, r.cowTo)}</b></p>`, '', 'margin-top:8px');
    if (v.phase === 'over') h = winnerBanner(`فاز ${v.winner.map(id => nm(ctx, id)).join(' و')}`, 'عقل القطيع الأصيل') + h;
    else if (ctx.isHost) h += `<div style="margin-top:12px">${btn('السؤال التالي', { type: 'next' }, 'block')}</div>`;
    else h += wait('بانتظار السؤال التالي');
  }
  return h + scores(ctx, v);
}
export function onUi(name, el, ctx, rerender) {
  if (name === 'mfrom') { ctx.ui.mergeFrom = Number(el.dataset.k); rerender(); }
  if (name === 'mcancel') { ctx.ui.mergeFrom = null; rerender(); }
}
export function onAct(a, ctx) { ctx.ui.mergeFrom = null; }
export function onFx(e, ctx) {
  const m = { 'round-start': 'round', answered: 'tap', herd: 'correct', 'no-herd': 'wrong', cow: 'buzz', phase: 'flip' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'game-over') { if ((ctx.view.winner || []).includes(ctx.me)) { ctx.sfx('win'); burst(['#ff70a6', '#7bdcb5', '#fff']); } else ctx.sfx('lose'); }
}

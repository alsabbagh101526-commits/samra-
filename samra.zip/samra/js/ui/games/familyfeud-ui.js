// واجهة فاميلي فيود — لوحة إجابات زرقاء وذهبية مثل استوديو التلفزيون
import { ar, esc } from '../dom.js';
import { nm, who, btn, wait, panel, teamsBlock, winnerBanner, act } from '../kit.js';
import { burst, flash, shake, vibrate } from '../../core/effects.js';

export const theme = 'familyfeud';
export const kit = 'pop';
export const ambient = () => '';
const LBL = { A: 'الفريق الأحمر', B: 'الفريق الأزرق' };

function board(v, isMod) {
  return `<div class="ff-board">${v.answers.map((a, k) => {
    const shown = a.shown;
    const inner = shown || isMod ? `<span class="ff-t">${esc(a.text)}</span><span class="ff-p">${ar(a.pts)}</span>` : `<span class="ff-n">${ar(k + 1)}</span>`;
    const canJudge = isMod && !shown && ['faceoff', 'play', 'steal'].includes(v.phase) && (v.phase !== 'faceoff' || v.face.buzz);
    return `<button class="ff-slot ${shown ? 'shown' : ''} ${isMod && !shown ? 'mod' : ''}" ${canJudge ? act({ type: 'judge', index: k }) : 'disabled'}>${inner}</button>`;
  }).join('')}</div>`;
}
const strikes = n => `<div class="ff-strikes">${Array.from({ length: 3 }, (_, k) => `<span class="${k < n ? 'on' : ''}">✕</span>`).join('')}</div>`;

export const screenKey = v => [v.phase, v.round].join(':');

export function render(ctx) {
  const v = ctx.view;
  const isMod = v.isMod;
  let h = teamsBlock(ctx, v.teams, LBL, v.score);
  h += `<p class="center muted" style="margin:4px 0">الجولة ${ar(v.round)} من ${ar(v.rounds)} • المقدم: ${nm(ctx, v.host)}</p>`;
  h += `<div class="ff-q"><p class="h2" style="margin:0">${esc(v.question)}</p><span class="ff-bank">${ar(v.bank)}</span></div>`;
  h += board(v, isMod);
  if (v.phase === 'faceoff') {
    const f = v.face;
    h += `<p class="center" style="margin:10px 0">المواجهة: ${who(ctx, f.A)} ضد ${who(ctx, f.B)}</p>`;
    if (f.buzz) h += `<p class="center h2">🔔 يجاوب ${nm(ctx, f[f.buzz])} (${LBL[f.buzz]})</p>`;
    if (isMod && f.buzz) h += `<p class="center muted">اضغط الإجابة التي قالها، أو:</p>${btn('ليست في اللوحة ✕', { type: 'judge', index: -1 }, 'danger block')}`;
    else if (!f.buzz && (ctx.me === f.A || ctx.me === f.B) && !(f.first && f.first === v.myTeam)) h += `<button class="buzzer buzzer-${v.myTeam}" ${act({ type: 'buzz' })}>جرس!</button>`;
    else if (!f.buzz) h += wait('بانتظار الجرس');
  } else if (v.phase === 'choose') {
    h += `<p class="center h2">${LBL[v.faceWinner]} كسب المواجهة</p>`;
    if (v.myTeam === v.faceWinner || isMod) h += `<div class="row">${btn('نلعب', { type: 'choose', value: 'play' }, 'grow-btn')}${btn('نمرّر', { type: 'choose', value: 'pass' }, 'soft grow-btn')}</div>`;
    else h += wait('الفريق الفائز يقرر');
  } else if (v.phase === 'play') {
    h += strikes(v.strikes) + `<p class="center">${LBL[v.control]} يلعب — يجاوب الآن: ${who(ctx, v.answerer)}</p>`;
    if (isMod) h += btn('إجابة خاطئة ✕', { type: 'judge', index: -1 }, 'danger block');
  } else if (v.phase === 'steal') {
    const st = v.control === 'A' ? 'B' : 'A';
    h += strikes(3) + `<p class="center h2">فرصة السرقة لـ${LBL[st]}!</p><p class="center soft">تشاوروا وأعطوا إجابة واحدة.</p>`;
    if (isMod) h += btn('إجابة السرقة خاطئة ✕', { type: 'judge', index: -1 }, 'danger block');
  } else if (v.phase === 'roundEnd') {
    const r = v.result;
    h += panel(`<p class="center h2" style="margin:0">${LBL[r.team]} +${ar(r.points)}${r.stolen ? ' (سرقة!)' : ''}</p>`);
    if (isMod) h += `<div class="row" style="margin-top:10px">${btn('اكشف الباقي', { type: 'revealAll' }, 'soft grow-btn')}${btn(v.round >= v.rounds ? 'النتيجة النهائية' : 'الجولة التالية', { type: 'next' }, 'grow-btn')}</div>`;
  } else if (v.phase === 'over') {
    h = winnerBanner(v.winner === 'tie' ? 'تعادل!' : `فاز ${LBL[v.winner]}`, `${ar(v.score.A)} — ${ar(v.score.B)}`) + h;
  }
  return h;
}
export function onFx(e, ctx) {
  const m = { buzz: 'buzz', reveal: 'correct', strike: 'wrong', award: 'coin', phase: 'phase', 'round-start': 'round' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'strike') { flash('#c62828'); shake(); }
  if (e.kind === 'buzz') vibrate(40);
  if (e.kind === 'game-over') { ctx.sfx('win'); if (ctx.view.winner === ctx.view.myTeam) burst(['#ffd34d', '#1e88e5', '#fff']); }
}

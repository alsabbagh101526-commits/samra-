// واجهة الخداع — مكتب تحقيق مظلم، أوراق أدلة صفراء، شريط مسرح الجريمة
import { ar, esc, openSheet, closeSheet } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, roleFront, revealStep, flipReveal, timerHtml, winnerBanner, act } from '../kit.js';
import { burst, flash } from '../../core/effects.js';

export const theme = 'deception';
export const kit = 'noir';
export const ambient = () => '<div class="tape tape-1">مسرح جريمة — ممنوع الاقتراب</div>';

const ROLE = {
  forensic: ['الطبيب الشرعي', 'يعرف الحل ويلمّح بالبلاطات فقط — لا تتكلم!', '#e1b84b'],
  murderer: ['القاتل', 'اختر أداة ودليلًا من بطاقاتك، ثم ضلّل المحققين.', '#b33a3a'],
  accomplice: ['الشريك', 'تعرف القاتل والحل. ساعده دون أن تنكشف.', '#8a3a3a'],
  witness: ['الشاهد', 'رأيت القاتل وشريكه دون تمييز. ساعد دون أن يكشفك القاتل.', '#3a7a8a'],
  investigator: ['محقق', 'اكشف القاتل والأداة والدليل معًا. لك شارة اتهام واحدة.', '#4a8a6a'],
};
const art = col => `<svg viewBox="0 0 120 120"><rect x="10" y="10" width="100" height="100" rx="10" fill="#1b2b2a"/><circle cx="60" cy="46" r="16" fill="${col}"/><path d="M30 104 Q60 58 90 104 Z" fill="${col}"/><path d="M36 30 H84 L78 22 H42 Z" fill="#111"/></svg>`;
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" fill="#16302e"/><path d="M0 120 L200 80 L200 110 L0 150 Z" fill="#e1b84b"/><text x="100" y="125" text-anchor="middle" font-size="16" fill="#111" transform="rotate(-11 100 115)">تحقيق</text></svg>`;
const roleCard = (r, flipped, attrs = '', size = '') => { const [n, d, c] = ROLE[r]; return card({ cls: `dc-card ${size}`, back: back(), front: roleFront({ type: 'دورك', name: n, desc: d, art: art(c) }), flipped, attrs, hint: flipped ? '' : 'اضغط لكشف دورك' }); };

function knows(ctx, me) {
  const k = me.knows; if (!k) return '';
  let t = '';
  if (k.murderer) t += `القاتل: ${chip(ctx, k.murderer)} `;
  if (k.accomplice) t += `الشريك: ${chip(ctx, k.accomplice)}`;
  if (k.suspects) t += `أحد هؤلاء القاتل والآخر شريكه: ${k.suspects.map(id => chip(ctx, id)).join(' ')}`;
  return t ? panel(t, '', 'margin-top:10px') : '';
}
function tiles(v, markable) {
  return `<div class="dc-tiles">${v.tiles.map((t, k) => `<div class="dc-tile ${v.newTile === k ? 'new' : ''}"><b>${esc(t.title)}</b><div class="dc-opts">${t.options.map((o, j) => markable && (v.round === 1 || v.newTile === k)
    ? `<button class="dc-opt ${t.mark === j ? 'on' : ''}" ${act({ type: 'mark', tile: k, option: j })}>${esc(o)}</button>`
    : `<span class="dc-opt ${t.mark === j ? 'on' : ''}">${esc(o)}</span>`).join('')}</div></div>`).join('')}</div>`;
}
function suspects(ctx, v) {
  return `<div class="dc-suspects">${v.players.filter(p => !p.forensic).map(p => `<div class="dc-sus"><div class="row spread">${chip(ctx, p.id, p.id === ctx.me ? ' (أنت)' : '')}<span class="badge ${p.badge ? '' : 'off'}">${p.badge ? '🔰' : 'استُخدمت'}</span></div>
    <div class="dc-cards"><div>${p.means.map(m => `<span class="dc-m">${esc(m)}</span>`).join('')}</div><div>${p.clues.map(c => `<span class="dc-c">${esc(c)}</span>`).join('')}</div></div></div>`).join('')}</div>`;
}

export function headerExtra(ctx) { return ctx.view.me && !['roles', 'over'].includes(ctx.view.phase) ? `<button class="icon-btn" data-ui="peek" aria-label="اعرض دوري">🕵️</button>` : ''; }
export const screenKey = v => [v.phase, v.round].join(':');

export function render(ctx) {
  const v = ctx.view, me = v.me;
  if (v.phase === 'roles') return revealStep(ctx, { cardHtml: roleCard(me.role, !!ctx.ui.revealed, 'data-ui="reveal" role="button" tabindex="0"'), readyCount: v.players.filter(p => p.ready).length, total: v.players.length, ready: me.ready, after: knows(ctx, me) });
  const F = v.players.find(p => p.forensic).id;
  let h = `<p class="center muted" style="margin:0">الجولة ${ar(v.round)} من ٣ • الطبيب الشرعي: ${nm(ctx, F)}</p>`;
  if (v.crime && v.phase !== 'over') h += `<p class="center" style="margin:6px 0">الحل (سري): <span class="dc-m">${esc(v.crime.means)}</span> + <span class="dc-c">${esc(v.crime.clue)}</span></p>`;
  if (v.phase === 'crime') {
    if (me.role === 'murderer') {
      const mine = v.players.find(p => p.id === ctx.me);
      const ui = ctx.ui;
      h += `<p class="h2 center">اختر أداة الجريمة:</p><div class="row wrap" style="gap:6px;justify-content:center">${mine.means.map((m, k) => `<button class="dc-m pick ${ui.cm === mine.meansIdx[k] ? 'on' : ''}" data-ui="cm" data-k="${mine.meansIdx[k]}">${esc(m)}</button>`).join('')}</div>
        <p class="h2 center">واختر الدليل الذي تتركه:</p><div class="row wrap" style="gap:6px;justify-content:center">${mine.clues.map((c, k) => `<button class="dc-c pick ${ui.cc === mine.cluesIdx[k] ? 'on' : ''}" data-ui="cc" data-k="${mine.cluesIdx[k]}">${esc(c)}</button>`).join('')}</div>
        <div style="margin-top:12px">${btn('نفّذ الجريمة', { type: 'commit', means: ui.cm, clue: ui.cc }, 'danger block', ui.cm != null && ui.cc != null ? '' : 'disabled')}</div>`;
    } else h += `<div class="big-status"><p class="h2">أغمضوا أعينكم…</p><p class="soft">القاتل يختار سلاحه ودليله</p></div>`;
    return h;
  }
  if (v.phase === 'scene') {
    if (me.role === 'forensic') {
      h += `<p class="center">ضع علامة على خيار واحد في كل بلاطة ليلمّح للحل:</p>` + tiles(v, true);
      h += `<div style="margin-top:12px">${btn('انشر الأدلة', { type: 'publish' }, 'block', v.tiles.every(t => t.mark != null) ? '' : 'disabled')}</div>`;
    } else h += wait('الطبيب الشرعي يفحص مسرح الجريمة') + suspects(ctx, v);
    return h;
  }
  if (v.phase === 'discuss') {
    h += timerHtml(v.deadline) + tiles(v, false);
    if (v.guesses.length) h += panel(v.guesses.map(g => `<div>${nm(ctx, g.by)} اتهم ${nm(ctx, g.target)} (${esc(v.players.find(p => p.id === g.target).means[v.players.find(p => p.id === g.target).meansIdx.indexOf(g.means)])} + ${esc(v.players.find(p => p.id === g.target).clues[v.players.find(p => p.id === g.target).cluesIdx.indexOf(g.clue)])}) — <b style="color:var(--danger)">خطأ</b></div>`).join(''), '', 'margin-top:8px');
    if (me.role !== 'forensic' && me.badge) h += `<div style="margin-top:10px">${`<button class="btn block" data-ui="solve">🔰 اتهام (مرة واحدة)</button>`}</div>`;
    h += suspects(ctx, v);
    if (me.role === 'forensic' || ctx.isHost) h += `<div style="margin-top:10px">${btn(v.round >= 3 ? 'أنهِ الجولة الأخيرة' : 'أنهِ الجولة', { type: 'endRound' }, 'soft block')}</div>`;
    return h;
  }
  if (v.phase === 'replace') {
    h += tiles(v, false);
    if (me.role === 'forensic') h += `<p class="center">اختر بلاطة مشهد لاستبدالها:</p><div class="row wrap" style="gap:6px;justify-content:center">${v.tiles.map((t, k) => k >= 2 ? btn(esc(t.title), { type: 'replace', tile: k }, 'soft') : '').join('')}</div>`;
    else h += wait('الطبيب الشرعي يستبدل بلاطة');
    return h;
  }
  if (v.phase === 'witnessHunt') {
    h += `<p class="h2 center">${nm(ctx, v.solvedBy)} كشف الجريمة!</p>`;
    if (me.role === 'murderer') h += `<p class="center">آخر فرصة: من الشاهد؟</p>` + targets(ctx, v.players.filter(p => !p.forensic && p.id !== ctx.me).map(p => p.id), { action: 'accuseWitness' });
    else h += wait('القاتل يبحث عن الشاهد');
    return h;
  }
  if (v.phase === 'over') {
    h = winnerBanner(v.winner === 'good' ? 'انتصر المحققون' : 'نجا القاتل', v.reason, v.winner === 'good' ? '#7bdcb5' : '#ff6b6b');
    if (v.crime) h += `<p class="center">الحل: <span class="dc-m">${esc(v.crime.means)}</span> + <span class="dc-c">${esc(v.crime.clue)}</span></p>`;
    h += `<div class="reveal-grid">${v.players.map((p, k) => `<div>${roleCard(p.role, false, `data-stagger="${k}"`, 'sm')}<div class="who">${nm(ctx, p.id)}</div></div>`).join('')}</div>`;
  }
  return h;
}
export function after(root) { root.querySelectorAll('[data-stagger]').forEach(c => setTimeout(() => c.classList.add('is-flipped'), 250 + Number(c.dataset.stagger) * 140)); }

function solveSheet(ctx) {
  const v = ctx.view;
  const draw = () => {
    const s = ctx.ui.solve || {};
    const p = s.target ? v.players.find(x => x.id === s.target) : null;
    let h = `<h2>اتهام</h2><p class="soft">اختر المتهم ثم أداته ودليله. لديك محاولة واحدة فقط.</p>`;
    h += `<div class="target-list">${v.players.filter(x => !x.forensic && x.id !== ctx.me).map(x => `<button class="target" aria-pressed="${s.target === x.id}" data-sv="target" data-v="${x.id}">${chip(ctx, x.id)}</button>`).join('')}</div>`;
    if (p) {
      h += `<p>الأداة:</p><div class="row wrap" style="gap:6px">${p.means.map((m, k) => `<button class="dc-m pick ${s.means === p.meansIdx[k] ? 'on' : ''}" data-sv="means" data-v="${p.meansIdx[k]}">${esc(m)}</button>`).join('')}</div>`;
      h += `<p>الدليل:</p><div class="row wrap" style="gap:6px">${p.clues.map((c, k) => `<button class="dc-c pick ${s.clue === p.cluesIdx[k] ? 'on' : ''}" data-sv="clue" data-v="${p.cluesIdx[k]}">${esc(c)}</button>`).join('')}</div>`;
    }
    const ready = p && s.means != null && s.clue != null;
    h += `<div class="row" style="margin-top:14px"><button class="btn danger grow-btn" ${ready ? act({ type: 'solve', target: s.target, means: s.means, clue: s.clue }) : 'disabled'} data-sheet-close>أتّهم!</button><button class="btn soft grow-btn" data-sheet-close>إلغاء</button></div>`;
    return h;
  };
  openSheet(`<div data-sc>${draw()}</div>`, {
    label: 'اتهام', onMount: el => {
      el.addEventListener('click', e => {
        const b = e.target.closest('[data-sv]'); if (!b) return;
        const s = (ctx.ui.solve ||= {});
        const k = b.dataset.sv;
        if (k === 'target') { s.target = b.dataset.v; s.means = null; s.clue = null; } else s[k] = Number(b.dataset.v);
        el.querySelector('[data-sc]').innerHTML = draw();
      });
    },
  });
}
export function onUi(name, el, ctx, rerender) {
  if (flipReveal(name, el, ctx, rerender, 'reveal')) return;
  if (name === 'cm') { ctx.ui.cm = Number(el.dataset.k); rerender(); }
  if (name === 'cc') { ctx.ui.cc = Number(el.dataset.k); rerender(); }
  if (name === 'solve') { ctx.ui.solve = {}; solveSheet(ctx); }
  if (name === 'peek') openSheet(`<h2>دوري</h2>${roleCard(ctx.view.me.role, true)}${knows(ctx, ctx.view.me)}<button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'دوري' });
}
export function onAct(a, ctx) { if (a.type === 'ready') ctx.ui.revealed = false; }
export function onFx(e, ctx) {
  const m = { night: 'night', committed: 'scream', phase: 'phase', 'wrong-guess': 'wrong', solved: 'correct' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'solved') flash('#e1b84b');
  if (e.kind === 'game-over') { const evil = ['murderer', 'accomplice'].includes(ctx.view.me?.role); if ((ctx.view.winner === 'evil') === evil) { ctx.sfx('win'); burst(['#e1b84b', '#fff']); } else ctx.sfx('lose'); }
}

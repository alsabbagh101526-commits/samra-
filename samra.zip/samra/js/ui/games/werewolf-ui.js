// واجهة المستذئب — قمر فضي فوق غابة، عواء وظلال
import { ar, openSheet } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, roleFront, revealStep, flipReveal, voteRow, timerHtml, winnerBanner } from '../kit.js';
import { burst, flash, shake } from '../../core/effects.js';

export const theme = 'werewolf';
export const kit = 'noir';
export const ambient = () => `<div class="ww-moon"></div><svg class="ww-forest" viewBox="0 0 400 120" preserveAspectRatio="none"><path d="M0 120 L0 70 L20 40 L35 70 L50 30 L70 72 L90 45 L105 75 L125 25 L145 70 L165 50 L180 78 L200 35 L222 74 L240 48 L258 76 L280 28 L300 72 L318 52 L335 78 L355 38 L375 74 L400 50 L400 120 Z" fill="#050b12"/></svg>`;

const ROLE = {
  wolf: ['ذئب', 'قطيع الذئاب', 'اتفق مع الذئاب ليلًا على ضحية، وتظاهر بالبراءة نهارًا.'],
  seer: ['العرّافة', 'القرية', 'كل ليلة تكشفين سرًا إن كان لاعب ما ذئبًا.'],
  witch: ['الساحرة', 'القرية', 'ترين ضحية الذئاب. جرعة شفاء وجرعة سم، كل منهما مرة واحدة.'],
  hunter: ['الصياد', 'القرية', 'إن مُتّ تطلق رصاصة أخيرة على من تختار.'],
  villager: ['قروي', 'القرية', 'لا قدرة ليلية. ناقش وصوّت لكشف الذئاب.'],
};
function art(role) {
  if (role === 'wolf') return `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" fill="#1d2b3a"/><path d="M30 92 L38 40 L52 58 L60 30 L68 58 L82 40 L90 92 Z" fill="#0a0f14"/><circle cx="50" cy="66" r="4" fill="#ffcc44"/><circle cx="70" cy="66" r="4" fill="#ffcc44"/></svg>`;
  const sym = { seer: '<circle cx="60" cy="58" r="22" fill="none" stroke="#cfd8de" stroke-width="5"/><circle cx="60" cy="58" r="8" fill="#9fd1ff"/>', witch: '<path d="M44 92 h32 l-6 -36 h-20 z" fill="#5a3f7a"/><circle cx="60" cy="48" r="10" fill="#7be08a"/>', hunter: '<path d="M30 80 L90 40" stroke="#cfd8de" stroke-width="6"/><circle cx="60" cy="60" r="20" fill="none" stroke="#e05555" stroke-width="4"/>', villager: '<path d="M38 92 Q60 40 82 92 Z" fill="#cfd8de"/><circle cx="60" cy="44" r="12" fill="#cfd8de"/>' }[role];
  return `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" fill="#1d2b3a"/>${sym}</svg>`;
}
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" fill="#0e1b29"/><circle cx="100" cy="110" r="46" fill="#cfd8de"/><circle cx="118" cy="98" r="40" fill="#0e1b29"/><path d="M0 280 L0 220 L30 180 L50 220 L80 170 L110 222 L140 176 L170 220 L200 190 L200 280Z" fill="#050b12"/></svg>`;
const roleCard = (role, flipped, attrs = '', size = '') => { const [n, t, d] = ROLE[role]; return card({ cls: `ww-card ${size} ${role === 'wolf' ? 'evil' : ''}`, back: back(), front: roleFront({ type: t, name: n, desc: d, art: art(role) }), flipped, attrs, hint: flipped ? '' : 'اضغط لكشف دورك' }); };

const alive = v => v.players.filter(p => p.alive);
const causes = { wolves: 'افترسته الذئاب', poison: 'مات مسمومًا', hunter: 'أصابته رصاصة الصياد', vote: 'أُقصي بالتصويت' };

export function headerExtra(ctx) { return ctx.view.me && !['roles', 'over'].includes(ctx.view.phase) ? `<button class="icon-btn" data-ui="peek" aria-label="اعرض دوري">🌕</button>` : ''; }
export const screenKey = v => [v.phase, v.night, v.day].join(':');

function deathsBlock(ctx, list) {
  if (!list || !list.length) return panel('<p class="center" style="margin:0">مرّت الليلة بسلام… لم يمت أحد.</p>');
  return panel(list.map(d => `<p style="margin:4px 0">${who(ctx, d.id)} — ${causes[d.cause] || ''}${ctx.view.players.find(p => p.id === d.id)?.role ? ` <span class="badge">${ROLE[ctx.view.players.find(p => p.id === d.id).role][0]}</span>` : ''}</p>`).join(''));
}

export function render(ctx) {
  const v = ctx.view, me = v.me;
  if (v.phase === 'roles') {
    const pack = me.role === 'wolf' ? panel(`<b>قطيعك:</b> ${me.pack.filter(p => p.id !== ctx.me).map(p => chip(ctx, p.id)).join(' ') || 'أنت الذئب الوحيد'}`, '', 'margin-top:12px') : '';
    return revealStep(ctx, { cardHtml: roleCard(me.role, !!ctx.ui.revealed, 'data-ui="reveal" role="button" tabindex="0"'), readyCount: v.players.filter(p => p.ready).length, total: v.players.length, ready: me.ready, after: pack });
  }
  if (v.phase === 'night') {
    let h = `<div class="big-status"><p class="h2">الليلة ${ar(v.night)}</p><p class="soft">أنهى ${ar(v.nightDone)} من ${ar(v.nightTotal)} أدوارهم</p></div>`;
    if (!me.alive) return h + wait('أنت ميت — راقب بصمت');
    const others = alive(v).filter(p => p.id !== ctx.me).map(p => p.id);
    if (me.role === 'wolf') {
      if (me.locked) return h + panel(`اتفق القطيع على: ${who(ctx, me.locked)}`, 'center');
      const picks = me.picks || {};
      h += `<p class="center">اختر الضحية مع قطيعك (يجب أن تتفقوا):</p>`;
      h += targets(ctx, alive(v).map(p => p.id).filter(id => !me.pack.some(w => w.id === id)), { action: 'wolfPick', selected: picks[ctx.me], mark: id => Object.entries(picks).filter(([, t]) => t === id).map(([w]) => ctx.player(w)?.name).join('، ') });
      return h;
    }
    if (me.role === 'seer') {
      if (me.done) { const last = me.seen[me.seen.length - 1]; return h + panel(`${who(ctx, last.target)} ${last.wolf ? '<b style="color:var(--danger)">ذئب!</b>' : '<b style="color:var(--ok)">ليس ذئبًا</b>'}`, 'center'); }
      return h + `<p class="center">اختر لاعبًا لتكشفه:</p>` + targets(ctx, others, { action: 'see' });
    }
    if (me.role === 'witch') {
      if (me.done) return h + wait('أنهيت دورك');
      if (!me.victim) return h + wait('انتظري حتى تختار الذئاب');
      const ui = ctx.ui;
      h += panel(`ضحية الذئاب الليلة: ${who(ctx, me.victim)}`, 'center');
      if (me.potions.heal) h += `<label class="switch-row panel" style="margin-top:10px"><span>استخدم جرعة الشفاء</span><input type="checkbox" data-ui="heal" ${ui.heal ? 'checked' : ''}></label>`;
      if (me.potions.poison) h += `<p style="margin:12px 0 6px">جرعة السم (اختياري):</p>` + targets(ctx, others, { ui: 'poison', selected: ui.poison || null });
      h += `<div style="margin-top:12px">${btn('تأكيد', { type: 'witch', heal: !!ui.heal, poison: ui.poison || null }, 'block')}</div>`;
      return h;
    }
    return h + (me.done ? wait('نائم') : `<p class="center soft">أغمض عينيك… القرية نائمة.</p>${btn('نمت 😴', { type: 'sleep' }, 'block')}`);
  }
  if (v.phase === 'hunter') {
    let h = deathsBlock(ctx, v.dawn?.deaths);
    if (v.hunter === ctx.me) return h + `<p class="h2 center">أنت الصياد! أطلق رصاصتك الأخيرة:</p>` + targets(ctx, alive(v).map(p => p.id), { action: 'shoot' }) + `<div style="margin-top:10px">${btn('لا أطلق', { type: 'shoot', target: 'none' }, 'soft block')}</div>`;
    return h + wait(`${nm(ctx, v.hunter)} الصياد يصوّب`);
  }
  if (v.phase === 'day') {
    let h = `<p class="h2 center">صباح اليوم ${ar(v.day)}</p>` + deathsBlock(ctx, v.dawn?.deaths);
    if (v.lastShot?.target) h += panel(`رصاصة الصياد أصابت ${who(ctx, v.lastShot.target)}`, 'center', 'margin-top:8px');
    h += timerHtml(v.deadline);
    h += `<p class="center soft">ناقشوا: من الذئب بينكم؟</p>`;
    if (ctx.isHost) h += btn('ابدأ التصويت الآن', { type: 'startVote' }, 'block');
    return h;
  }
  if (v.phase === 'vote') {
    let h = `<p class="h2 center">التصويت</p>`;
    if (!me.alive) h += wait('الأموات لا يصوّتون');
    else if (me.vote) h += wait(`صوّتّ ضد ${me.vote === 'skip' ? 'لا أحد' : nm(ctx, me.vote)}`);
    else h += targets(ctx, alive(v).filter(p => p.id !== ctx.me).map(p => p.id), { action: 'vote' }) + `<div style="margin-top:10px">${btn('لا أحد', { type: 'vote', target: 'skip' }, 'soft block')}</div>`;
    h += voteRow(ctx, alive(v));
    if (ctx.isHost) h += `<div style="margin-top:10px">${btn('أغلق التصويت', { type: 'closeVote' }, 'soft block')}</div>`;
    return h;
  }
  if (v.phase === 'over') {
    let h = winnerBanner(v.winner === 'village' ? 'انتصرت القرية' : 'انتصرت الذئاب', '', v.winner === 'village' ? '#9fd1ff' : '#ff6b6b');
    h += `<div class="reveal-grid">${v.players.map((p, k) => `<div>${roleCard(p.role, false, `data-stagger="${k}"`, 'sm')}<div class="who">${nm(ctx, p.id)}${p.alive ? '' : ' ✝'}</div></div>`).join('')}</div>`;
    return h;
  }
  return '';
}
export function after(root) { root.querySelectorAll('[data-stagger]').forEach(c => setTimeout(() => c.classList.add('is-flipped'), 250 + Number(c.dataset.stagger) * 140)); }
export function onUi(name, el, ctx, rerender) {
  if (flipReveal(name, el, ctx, rerender, 'reveal')) return;
  if (name === 'heal') { ctx.ui.heal = el.checked; rerender(); }
  if (name === 'poison') { ctx.ui.poison = ctx.ui.poison === el.dataset.id ? null : el.dataset.id; ctx.sfx('tap'); rerender(); }
  if (name === 'peek') openSheet(`<h2>دوري</h2>${roleCard(ctx.view.me.role, true)}<button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'دوري' });
}
export function onAct(a, ctx) { if (a.type === 'ready') ctx.ui.revealed = false; if (a.type === 'witch') { ctx.ui.heal = false; ctx.ui.poison = null; } }
export function onFx(e, ctx) {
  const m = { night: 'night', 'dawn-death': 'scream', 'dawn-safe': 'dawn', vote: 'vote', eliminated: 'gavel', 'no-elim': 'pass', hunter: 'phase', seen: 'secret', locked: 'secret', 'witch-wake': 'secret', shot: 'boom' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'dawn-death' || e.kind === 'shot') { flash('#600'); shake(); }
  if (e.kind === 'game-over') { const wolf = ctx.view.me?.role === 'wolf'; if ((ctx.view.winner === 'wolves') === wolf) { ctx.sfx('win'); burst(['#cfd8de', '#9fd1ff', '#ffcc44']); } else ctx.sfx('lose'); }
}

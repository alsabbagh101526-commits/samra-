// واجهة "هتلر السري" — برلمان محايد: أزرق ليبرالي وأحمر طوبي، بلا أي رموز تاريخية
import { ar, openSheet } from '../dom.js';
import { nm, who, chip, btn, wait, panel, targets, card, roleFront, revealStep, flipReveal, voteRow, winnerBanner } from '../kit.js';
import { burst } from '../../core/effects.js';

export const theme = 'secret';
export const kit = 'luxe';
export const ambient = () => '';

const ROLE = {
  liberal: ['ليبرالي', 'الحزب الليبرالي', 'شرّعوا ٥ قوانين ليبرالية أو اكشفوا القائد السري وأعدموه.', '#3d6fa8'],
  fascist: ['فاشي', 'الحزب الفاشي', 'تعرف فريقك والقائد السري. ساعده ليصل للسلطة.', '#b5523f'],
  hitler: ['هتلر (القائد السري)', 'الحزب الفاشي', 'ابقَ مخفيًا. انتخابك مستشارًا بعد ٣ قوانين فاشية = فوز فريقك.', '#7a2d22'],
};
const art = (col, lead) => `<svg viewBox="0 0 120 120"><rect x="10" y="10" width="100" height="100" rx="14" fill="${col}"/><circle cx="60" cy="46" r="16" fill="#1a1c20"/><path d="M28 104 Q60 56 92 104 Z" fill="#1a1c20"/>${lead ? '<rect x="44" y="20" width="32" height="8" rx="3" fill="#f0e6c8"/>' : ''}</svg>`;
const back = () => `<svg viewBox="0 0 200 280"><rect width="200" height="280" fill="#2e3036"/><rect x="16" y="16" width="168" height="248" rx="10" fill="none" stroke="#c9b37e" stroke-width="3"/><text x="100" y="150" text-anchor="middle" font-size="40" fill="#c9b37e">؟</text></svg>`;
const roleCard = (r, flipped, attrs = '', size = '') => { const [n, t, d, c] = ROLE[r]; return card({ cls: `sh-card ${size}`, back: back(), front: roleFront({ type: t, name: n, desc: d, art: art(c, r === 'hitler') }), flipped, attrs, hint: flipped ? '' : 'اضغط لكشف دورك' }); };
const POW = { investigate: 'كشف ولاء', special: 'انتخاب خاص', peek: 'نظرة على القوانين', kill: 'إعدام' };
const pol = (p, extra = '') => `<span class="policy ${p === 'L' ? 'lib' : 'fas'}" ${extra}>${p === 'L' ? 'ليبرالي' : 'فاشي'}</span>`;

function boards(v) {
  const lib = Array.from({ length: 5 }, (_, k) => `<div class="slot ${k < v.lib ? 'lib on' : 'lib'}"></div>`).join('');
  const fas = Array.from({ length: 6 }, (_, k) => `<div class="slot ${k < v.fas ? 'fas on' : 'fas'}">${v.powers[k] && k >= v.fas ? `<small>${POW[v.powers[k]]}</small>` : ''}</div>`).join('');
  return `<div class="sh-board"><div class="track">${lib}</div><div class="track">${fas}</div><div class="row spread muted" style="font-size:13px"><span>حكومات فاشلة: ${ar(v.tracker)}/٣</span><span>الكومة: ${ar(v.deck)}</span></div></div>`;
}
function knows(ctx, me) {
  if (!me.knows) return '';
  return panel(`<b>فريقك:</b> ${me.knows.map(k => chip(ctx, k.id, k.role === 'hitler' ? ' — القائد السري' : '')).join(' ')}`, '', 'margin-top:12px');
}

export function headerExtra(ctx) { return ctx.view.me && !['reveal', 'over'].includes(ctx.view.phase) ? `<button class="icon-btn" data-ui="peek" aria-label="اعرض دوري">🗂️</button>` : ''; }
export const screenKey = v => [v.phase, v.president, v.lib, v.fas, v.tracker].join(':');

export function render(ctx) {
  const v = ctx.view, me = v.me;
  if (v.phase === 'reveal') return revealStep(ctx, { cardHtml: roleCard(me.role, !!ctx.ui.revealed, 'data-ui="reveal" role="button" tabindex="0"'), readyCount: v.players.filter(p => p.ready).length, total: v.players.length, ready: me.ready, after: knows(ctx, me) });
  let h = boards(v);
  const gov = `<p class="center" style="margin:10px 0">الرئيس: ${who(ctx, v.president)}${v.chancellor ? ` — المستشار: ${who(ctx, v.chancellor)}` : ''}</p>`;
  if (v.phase === 'over') {
    h = winnerBanner(v.winner === 'liberal' ? 'فاز الليبراليون' : 'فاز الفاشيون', v.reason, v.winner === 'liberal' ? '#6fa0dc' : '#e07a62') + h;
    return h + `<div class="reveal-grid" style="margin-top:12px">${v.players.map((p, k) => `<div>${roleCard(p.role, false, `data-stagger="${k}"`, 'sm')}<div class="who">${nm(ctx, p.id)}${p.alive ? '' : ' ✝'}</div></div>`).join('')}</div>`;
  }
  if (!me.alive) h += `<p class="center" style="color:var(--danger)">أُعدمت — لا تتكلم ولا تصوّت.</p>`;
  if (v.lastVote && v.phase === 'nominate') h += `<details class="panel"><summary>آخر تصويت: <b>${v.lastVote.pass ? 'نجح' : 'فشل'}</b></summary>${v.lastVote.votes.map(x => `<div class="row spread"><span>${nm(ctx, x.id)}</span><span class="badge ${x.v === 'ja' ? 'ok' : 'off'}">${x.v === 'ja' ? 'نعم' : 'لا'}</span></div>`).join('')}</details>`;
  if (v.phase === 'nominate') {
    h += gov;
    if (v.president === ctx.me) h += `<p class="center">رشّح مستشارًا:</p>` + targets(ctx, v.eligible, { action: 'nominate' });
    else h += wait('الرئيس يختار المستشار');
    return h;
  }
  if (v.phase === 'vote') {
    h += gov;
    if (me.alive && !me.vote) h += `<div class="row">${btn('نعم ✓', { type: 'vote', value: 'ja' }, 'grow-btn')}${btn('لا ✕', { type: 'vote', value: 'nein' }, 'danger grow-btn')}</div>`;
    else if (me.vote) h += wait(`صوّتّ: ${me.vote === 'ja' ? 'نعم' : 'لا'}`);
    return h + voteRow(ctx, v.players.filter(p => p.alive));
  }
  if (v.phase === 'presLeg' || v.phase === 'chanLeg' || v.phase === 'vetoAsk') {
    h += gov;
    if (me.hand && v.phase === 'presLeg') h += `<p class="center">تخلّص سرًا من قانون واحد:</p><div class="row" style="justify-content:center;gap:10px">${me.hand.map((p, k) => `<button class="card-btn" data-act='{"type":"discard","index":${k}}'>${pol(p)}</button>`).join('')}</div>`;
    else if (me.hand && v.phase === 'chanLeg') {
      h += `<p class="center">اختر القانون الذي تشرّعه:</p><div class="row" style="justify-content:center;gap:10px">${me.hand.map((p, k) => `<button class="card-btn" data-act='{"type":"enact","index":${k}}'>${pol(p)}</button>`).join('')}</div>`;
      if (me.canVeto) h += `<div style="margin-top:12px">${btn('أطلب حق النقض', { type: 'veto' }, 'soft block')}</div>`;
    } else if (v.phase === 'vetoAsk' && v.president === ctx.me) h += `<p class="center">المستشار يطلب النقض:</p><div class="row">${btn('أوافق', { type: 'vetoAnswer', accept: true }, 'grow-btn')}${btn('أرفض', { type: 'vetoAnswer', accept: false }, 'soft grow-btn')}</div>`;
    else h += wait('الحكومة تشرّع');
    return h;
  }
  if (v.phase === 'power' || v.phase === 'invResult') {
    h += `<p class="h2 center">صلاحية الرئيس: ${POW[v.power] || 'كشف ولاء'}</p>`;
    if (v.president !== ctx.me) return h + wait(`${nm(ctx, v.president)} يستخدم صلاحيته`);
    const others = v.players.filter(p => p.alive && p.id !== ctx.me);
    if (v.phase === 'invResult') return h + panel(`${who(ctx, me.investigation.target)} من <b>${me.investigation.party === 'liberal' ? 'الحزب الليبرالي' : 'الحزب الفاشي'}</b>`, 'center') + btn('تم', { type: 'invDone' }, 'block');
    if (v.power === 'peek') return h + `<div class="row" style="justify-content:center;gap:8px">${me.peek.map(p => pol(p)).join('')}</div><p class="center muted">أعلى ٣ قوانين بالترتيب</p>` + btn('تم', { type: 'peekDone' }, 'block');
    if (v.power === 'investigate') return h + targets(ctx, others.filter(p => !p.investigated).map(p => p.id), { action: 'investigate' });
    if (v.power === 'special') return h + `<p class="center">اختر الرئيس القادم:</p>` + targets(ctx, others.map(p => p.id), { action: 'special' });
    if (v.power === 'kill') return h + `<p class="center" style="color:var(--danger)">اختر من يُعدم:</p>` + targets(ctx, others.map(p => p.id), { action: 'kill' });
  }
  return h;
}
export function after(root) { root.querySelectorAll('[data-stagger]').forEach(c => setTimeout(() => c.classList.add('is-flipped'), 250 + Number(c.dataset.stagger) * 140)); }
export function onUi(name, el, ctx, rerender) {
  if (flipReveal(name, el, ctx, rerender, 'reveal')) return;
  if (name === 'peek') openSheet(`<h2>دوري</h2>${roleCard(ctx.view.me.role, true)}${knows(ctx, ctx.view.me)}<button class="btn soft block" style="margin-top:14px" data-sheet-close>إخفاء</button>`, { label: 'دوري' });
}
export function onAct(a, ctx) { if (a.type === 'ready') ctx.ui.revealed = false; }
export function onFx(e, ctx) {
  const m = { nominated: 'bid', vote: 'vote', elected: 'correct', failed: 'wrong', 'policy-l': 'flip', 'policy-f': 'flip', chaos: 'buzz', power: 'phase', kill: 'boom', veto: 'pass', vetoed: 'pass', investigated: 'secret' };
  if (m[e.kind]) ctx.sfx(m[e.kind]);
  if (e.kind === 'game-over') { const mine = ctx.view.me && (ctx.view.me.role === 'liberal' ? 'liberal' : 'fascist'); if (mine === ctx.view.winner) { ctx.sfx('win'); burst(['#c9b37e', '#6fa0dc', '#fff']); } else ctx.sfx('lose'); }
}

// متحكم الجلسة: إنشاء الغرفة، الانضمام، اللوبي، شاشة اللعب، المؤثرات والمؤقتات
import { ENGINES } from '../engines/index.js';
import { HostSession } from '../net/host-session.js';
import { ClientSession } from '../net/client-session.js';
import { localTransport } from '../net/local-transport.js';
import { startPeerHost, peerClientTransport, NET_MESSAGES } from '../net/peer-transport.js';
import { randomCode } from '../net/protocol.js';
import { store } from '../core/storage.js';
import { settings, profile } from '../core/settings.js';
import { play, unlockAudio } from '../core/audio.js';
import { burst } from '../core/effects.js';
import { byId } from '../games/catalog.js';
import { BARA_CATEGORIES } from '../data/bara-words.js';
import { esc, ar, avatar, toast, openSheet, closeSheet, qrSvg, profileSheet, settingsSheet, fmtTime, withSheetScope, closeSheetOfScope } from './dom.js';
import * as mafiaUI from './games/mafia-ui.js';
import * as skullUI from './games/skull-ui.js';
import * as baraUI from './games/bara-ui.js';
import * as avalonUI from './games/avalon-ui.js';
import * as werewolfUI from './games/werewolf-ui.js';
import * as coupUI from './games/coup-ui.js';
import * as secretUI from './games/secret-ui.js';
import * as kittensUI from './games/kittens-ui.js';
import * as wavelengthUI from './games/wavelength-ui.js';
import * as herdUI from './games/herd-ui.js';
import * as lettersUI from './games/letters-ui.js';
import * as familyfeudUI from './games/familyfeud-ui.js';
import * as deceptionUI from './games/deception-ui.js';
import * as shareefUI from './games/shareef-ui.js';
import * as monopolyUI from './games/monopoly-ui.js';

const GAME_UI = { mafia: mafiaUI, skull: skullUI, bara: baraUI, avalon: avalonUI, werewolf: werewolfUI, coup: coupUI, secret: secretUI, kittens: kittensUI, wavelength: wavelengthUI, herd: herdUI, letters: lettersUI, familyfeud: familyfeudUI, deception: deceptionUI, shareef: shareefUI, monopoly: monopolyUI };
const HOST_KEY = 'samra.host';
const LAST_ROOM_KEY = 'samra.lastRoom';

let S = null; // الجلسة الحالية
let timerLoop = null;
let navigate = h => { location.hash = h; };
export function setNavigator(fn) { navigate = fn; }
export const current = () => S;

// ================= إنشاء غرفة (المضيف) =================
export async function createRoom(gameId) {
  const p = profile.get() || await profileSheet({ title: 'قبل إنشاء الغرفة: من أنت؟', submit: 'أنشئ الغرفة' });
  if (!p) return;
  unlockAudio();
  showBusy('جارٍ تجهيز الغرفة…');
  endSession(false);
  let host = null, peer = null, lastErr = null;
  for (let attempt = 0; attempt < 4 && !peer; attempt++) {
    const code = randomCode();
    host = new HostSession({ engines: ENGINES, code, gameId, onSave: saveHostSoon });
    try {
      peer = await startPeerHost({ code, onConnection: c => host.attach(c), onStatus: s => onHostPeerStatus(s) });
    } catch (e) {
      lastErr = e;
      if (e.code !== 'unavailable-id') break;
    }
  }
  if (!peer) return showFatal(NET_MESSAGES[lastErr?.code] || 'تعذّر إنشاء الغرفة. تأكد من اتصال الإنترنت ثم حاول مجددًا.', () => createRoom(gameId));
  startLocalHostClient(host, peer, p);
}

// إبقاء شاشة جوال المضيف مضاءة ما دامت الغرفة مفتوحة (إن دعمها المتصفح؛ وإلا لا شيء)
let wakeLock = null;
async function keepAwake(on) {
  try {
    if (on) {
      if (wakeLock || typeof navigator === 'undefined' || !navigator.wakeLock || document.visibilityState !== 'visible') return;
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', () => { wakeLock = null; });
    } else if (wakeLock) { const w = wakeLock; wakeLock = null; await w.release(); }
  } catch { wakeLock = null; }
}
if (typeof document !== 'undefined') document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible' || !S) return;
  if (S.isHost && S.host && !S.host.closed) keepAwake(true);
  try { S.client?.wake(); } catch {} // عودة التطبيق للواجهة: فحص الاتصال فورًا
});

function startLocalHostClient(host, peer, p) {
  const client = new ClientSession({ transport: localTransport(host, { local: true }), code: host.room.code, store, profile: p, asHost: true });
  S = newSession({ client, host, peer, code: host.room.code, isHost: true });
  wireClient(S);
  saveHostNow();
  navigate('#/play');
  client.start();
  if (host.room.status === 'playing') host.startTimer();
  host.startLiveness();
  keepAwake(true);
}

let saveT = null;
// حفظ مضمون خلال ٣٠٠ms من أول تغيير (لا نؤجله مع كل حركة جديدة وإلا قد لا يُحفظ أبدًا أثناء اللعب السريع)
function saveHostSoon() { if (saveT) return; saveT = setTimeout(() => { saveT = null; saveHostNow(); }, 300); }
// عند إعادة التحميل أو إغلاق الصفحة أو انتقال الجوال لتطبيق آخر: حفظ فوري
if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', () => saveHostNow());
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveHostNow(); });
}
function saveHostNow() {
  if (!S || !S.host || S.host.closed) return;
  store.set(HOST_KEY, { code: S.host.room.code, room: S.host.serialize(), savedAt: Date.now() });
}

export function savedHostRoom() {
  const h = store.get(HOST_KEY);
  if (!h || !h.room || Date.now() - h.savedAt > 12 * 3600 * 1000) return null;
  return h;
}
export function forgetHostRoom() { store.remove(HOST_KEY); }

// استعادة غرفة المضيف بعد تحديث الصفحة أو إغلاق المتصفح
export async function resumeHost() {
  const saved = savedHostRoom();
  if (!saved) return navigate('#/');
  const p = profile.get() || { name: 'المضيف', emoji: '👑' };
  unlockAudio();
  showBusy('جارٍ استعادة الغرفة ' + saved.code + '…');
  const host = new HostSession({ engines: ENGINES, restored: saved.room, onSave: saveHostSoon });
  let peer = null, lastErr = null;
  // خادم التعارف قد يحتفظ بالمعرّف القديم لبضع ثوانٍ
  for (let attempt = 0; attempt < 8 && !peer; attempt++) {
    try { peer = await startPeerHost({ code: saved.code, onConnection: c => host.attach(c), onStatus: s => onHostPeerStatus(s) }); }
    catch (e) {
      lastErr = e;
      if (e.code !== 'unavailable-id') break;
      showBusy(`ننتظر تحرير رمز الغرفة… (${ar(attempt + 1)}/٨)`);
      await new Promise(r => setTimeout(r, 5000));
    }
  }
  if (!peer) return showFatal(NET_MESSAGES[lastErr?.code] || 'تعذّر استعادة الغرفة.', () => resumeHost());
  startLocalHostClient(host, peer, p);
}

function onHostPeerStatus(s) {
  if (!S || !S.isHost) return;
  S.hostSignal = s;
  renderConn();
}

// ================= الانضمام (لاعب) =================
export async function joinRoom(code) {
  const p = profile.get() || await profileSheet({ title: 'قبل الدخول: من أنت؟', submit: 'ادخل الغرفة' });
  if (!p) return;
  unlockAudio();
  if (S && S.code === code && !S.dead) return navigate('#/play');
  endSession(false);
  const client = new ClientSession({ transport: peerClientTransport({ code }), code, store, profile: p });
  S = newSession({ client, code, isHost: false });
  store.set(LAST_ROOM_KEY, { code, at: Date.now() });
  wireClient(S);
  navigate('#/play');
  client.start();
}

export function lastRoom() {
  const r = store.get(LAST_ROOM_KEY);
  if (!r || Date.now() - r.at > 6 * 3600 * 1000) return null;
  if (!store.get('samra.session.' + r.code)) return null;
  return r;
}

function newSession(o) {
  return { ...o, state: null, ui: {}, matchNo: null, fxReady: false, lastFxId: 0, lastRoomFx: 0, status: 'connecting', detail: null, busy: false };
}

function wireClient(s) {
  const c = s.client;
  c.on('status', ({ status, detail }) => {
    if (S !== s) return;
    s.status = status; s.detail = detail;
    if (status === 'online') s.fxReady = false; // بعد إعادة الاتصال لا نعيد تشغيل المؤثرات القديمة
    if (status === 'closed' || status === 'rejected' || status === 'failed') { s.dead = status !== 'failed'; }
    if (status === 'closed' && s.isHost) cleanupHost();
    if (!s.state || status !== 'online') renderPlay();
    else renderConn();
  });
  c.on('state', msg => { if (S === s) onState(msg); });
  c.on('error', e => { if (S === s && e && e !== 'offline') { toast(e, 'err'); play('shell', 'error'); } });
}

// ================= استقبال الحالة =================
function onState(msg) {
  const s = S;
  const prevStatus = s.state?.room.status;
  s.state = msg;
  const room = msg.room;
  // تغيّر المباراة: تصفير الحالة المحلية للواجهة
  if (room.matchNo !== s.matchNo) { s.matchNo = room.matchNo; s.ui = {}; s.fxReady = false; }
  // مؤثرات الغرفة
  if (room.roomFx && s.roomFxReady && room.roomFx.id > s.lastRoomFx && room.roomFx.who !== msg.you) play('shell', room.roomFx.kind === 'join' ? 'join' : 'leave');
  if (room.roomFx) s.lastRoomFx = room.roomFx.id;
  s.roomFxReady = true;

  const gameUi = GAME_UI[room.gameId];
  renderPlay();
  // مؤثرات اللعبة: كل حدث مرة واحدة فقط
  if (msg.game && gameUi) {
    const fx = msg.game.fx || [];
    const maxId = fx.reduce((m, e) => Math.max(m, e.id), 0);
    if (s.fxReady) {
      const root = document.getElementById('stage');
      for (const e of fx) if (e.id > s.lastFxId) gameUi.onFx?.(e, ctxFor(s), root);
    }
    s.lastFxId = Math.max(s.lastFxId, maxId);
    s.fxReady = true;
  }
  if (prevStatus === 'lobby' && room.status === 'playing') play(gameUi?.kit || 'shell', 'reveal');
}

function ctxFor(s) {
  const msg = s.state;
  const players = new Map(msg.room.players.map(p => [p.id, p]));
  const gameUi = GAME_UI[msg.room.gameId];
  return {
    view: msg.game, room: msg.room, me: msg.you,
    isHost: s.isHost,
    player: id => players.get(id),
    ui: s.ui,
    sfx: name => play(gameUi?.kit || 'shell', name),
    serverNow: () => s.client.serverNow(),
    send: async a => { const r = await s.client.act(a); return r; },
  };
}

// ================= الرسم =================
let bound = false;
export function renderPlay() {
  const app = document.getElementById('app');
  const s = S;
  if (!s) return navigate('#/');
  if (location.hash !== '#/play') return;
  const msg = s.state;
  const gameId = msg?.room.gameId;
  const gameUi = GAME_UI[gameId];
  const meta = byId(gameId);
  setTheme(msg && msg.room.status === 'playing' ? gameUi?.theme : (gameUi?.theme || 'shell'), gameUi);

  if (!app.querySelector('#stage')) {
    app.innerHTML = `<div class="page"><header class="topbar glass" id="topbar"></header><div id="conn"></div><main id="stage"></main></div>`;
  }
  if (!bound) bindStage(app);

  // قبل أول حالة
  if (!msg) {
    renderTop(null);
    const st = s.status;
    if (st === 'failed' || st === 'rejected' || st === 'closed') return renderEnded(s);
    document.getElementById('conn').innerHTML = '';
    document.getElementById('stage').innerHTML = `<div class="big-status"><p class="h2">جارٍ الاتصال بالغرفة <span dir="ltr">${esc(s.code)}</span><span class="waiting-dots"></span></p>
      <p class="soft">${esc(NET_MESSAGES[s.detail] && s.detail !== 'room-not-found' ? NET_MESSAGES[s.detail] : 'قد يستغرق ذلك بضع ثوانٍ.')}</p>
      <button class="btn ghost" data-cmd="leave">إلغاء</button></div>`;
    return;
  }
  if (s.status === 'closed' || s.status === 'rejected') return renderEnded(s);

  renderTop(msg);
  renderConn();
  const stage = document.getElementById('stage');
  const ctx = ctxFor(s);
  // الحفاظ على ما يكتبه اللاعب عند وصول تحديثات من الآخرين
  const kept = {};
  stage.querySelectorAll('input[id], textarea[id], select[id]').forEach(el => {
    kept[el.id] = { v: el.value, f: document.activeElement === el, st: el.selectionStart, type: el.type };
  });
  // حركة الدخول تُعرض فقط عند تغيّر الشاشة، لا مع كل تحديث صغير
  const key = msg.room.status === 'lobby' || !msg.game ? 'lobby:' + msg.room.players.length : msg.room.matchNo + ':' + (gameUi.screenKey ? gameUi.screenKey(msg.game) : msg.game.phase);
  stage.classList.toggle('no-enter', key === s.screenKey);
  if (key !== s.screenKey) closeSheetOfScope('game'); // نافذة لعبة من مرحلة سابقة قد تحمل أزرارًا لم تعد صالحة
  s.screenKey = key;
  if (msg.room.status === 'lobby' || !msg.game) {
    stage.innerHTML = lobbyHtml(ctx, meta);
  } else {
    let html = `<div class="game-${gameId}">${gameUi.render(ctx)}</div>`;
    if (msg.game.phase === 'over') html += endActions(ctx);
    stage.innerHTML = html;
    gameUi.after?.(stage, ctx);
  }
  for (const [id, k] of Object.entries(kept)) {
    const el = document.getElementById(id);
    if (!el || el.dataset.fresh != null) continue;
    if (k.type === 'range' && !k.f) continue;
    el.value = k.v;
    if (k.f) { el.focus(); try { if (k.st != null) el.setSelectionRange(k.st, k.st); } catch {} }
  }
  tickTimers();
}

function setTheme(theme, gameUi) {
  if (document.body.dataset.theme !== theme) {
    document.body.dataset.theme = theme;
    document.body.classList.remove('is-night');
    let amb = document.querySelector('.ambient-layer');
    const html = gameUi?.ambient?.() || '';
    if (html && !settings.get().performance) {
      if (!amb) { amb = document.createElement('div'); amb.className = 'ambient-layer'; amb.setAttribute('aria-hidden', 'true'); document.body.prepend(amb); }
      amb.innerHTML = html;
    } else if (amb) amb.remove();
    const meta = document.querySelector('meta[name=theme-color]');
    if (meta) meta.content = getComputedStyle(document.body).getPropertyValue('--bg').trim() || '#231b2e';
  }
}

function renderTop(msg) {
  const top = document.getElementById('topbar');
  if (!top) return;
  const meta = msg ? byId(msg.room.gameId) : null;
  const gameUi = msg ? GAME_UI[msg.room.gameId] : null;
  const extra = msg && msg.game && msg.room.status === 'playing' && gameUi?.headerExtra ? gameUi.headerExtra(ctxFor(S)) : '';
  const snd = settings.get().sound;
  top.innerHTML = `<button class="icon-btn" data-cmd="leave" aria-label="مغادرة الغرفة">✕</button>
    <div class="title">${esc(meta?.name || 'سمرة')}</div>${extra}
    <button class="icon-btn" data-cmd="mute" aria-label="${snd ? 'كتم الصوت' : 'تشغيل الصوت'}">${snd ? '🔊' : '🔇'}</button>
    <button class="icon-btn" data-cmd="settings" aria-label="الإعدادات">⚙️</button>`;
}

function renderConn() {
  const el = document.getElementById('conn');
  if (!el || !S) return;
  const s = S;
  let html = '';
  if (s.state && (s.status === 'reconnecting' || s.status === 'connecting')) {
    html = `<div class="banner warn conn-banner" role="alert"><span aria-hidden="true">📡</span><div class="grow"><b>انقطع الاتصال</b><br><small>${esc(NET_MESSAGES[s.detail] || 'جارٍ إعادة الاتصال تلقائيًا…')}</small></div></div>`;
  } else if (s.state && s.status === 'failed') {
    html = `<div class="banner err conn-banner" role="alert"><div class="grow"><b>تعذّرت إعادة الاتصال</b><br><small>${esc(NET_MESSAGES[s.detail] || 'تحقق من الإنترنت.')}</small></div><button class="btn small" data-cmd="retry">أعد المحاولة</button></div>`;
  } else if (s.isHost && s.hostSignal === 'signal-lost') {
    html = `<div class="banner warn" role="status"><div class="grow"><small>انقطع خادم التعارف مؤقتًا. اللاعبون الحاليون متصلون، لكن لا يمكن دخول لاعبين جدد حتى يعود.</small></div></div>`;
  }
  if (s.isHost && s.state && s.state.room.players.some(p => !p.connected) && s.state.room.status === 'playing') {
    html += `<div class="banner" role="status"><div class="grow"><small>لاعب غير متصل: ${s.state.room.players.filter(p => !p.connected).map(p => esc(p.name)).join('، ')} — اللعبة تنتظره إن جاء دوره.</small></div></div>`;
  }
  el.innerHTML = html;
}

function renderEnded(s) {
  const reasons = {
    'in-progress': 'اللعبة في هذه الغرفة بدأت بالفعل. انتظر حتى يعيد المضيف الغرفة للانتظار.',
    full: 'الغرفة ممتلئة.',
    version: 'نسخة المنصة لديك تختلف عن نسخة المضيف. حدّث الصفحة.',
    kicked: 'أخرجك المضيف من الغرفة.',
    ended: 'أنهى المضيف الغرفة.',
    replaced: 'فتحت هذه الغرفة في نافذة أو جهاز آخر.',
  };
  const msg = reasons[s.detail] || NET_MESSAGES[s.detail] || 'انتهى الاتصال بالغرفة.';
  document.getElementById('conn').innerHTML = '';
  document.getElementById('stage').innerHTML = `<div class="big-status"><p class="h2">${s.status === 'failed' ? 'تعذّر الاتصال' : 'خرجت من الغرفة'}</p>
    <p class="soft">${esc(msg)}</p>
    <div class="stack" style="max-width:320px;margin:16px auto 0">
      ${s.status === 'failed' ? '<button class="btn" data-cmd="retry">أعد المحاولة</button>' : ''}
      <button class="btn ghost" data-cmd="home">الصفحة الرئيسية</button></div></div>`;
}

// ================= اللوبي =================
function lobbyHtml(ctx, meta) {
  const room = ctx.room;
  const meP = ctx.player(ctx.me);
  const url = joinUrl(room.code);
  const eng = ENGINES[room.gameId];
  const n = room.players.length;
  let html = `<section class="panel code-card">
      <p class="soft" style="margin:0">كود الغرفة</p>
      <div class="code-digits">${esc(room.code)}</div>
      <div class="qr" aria-label="رمز QR للانضمام">${qrSvg(url)}</div>
      <p class="muted" style="margin:0 0 10px;font-size:15px">امسح الرمز بكاميرا الجوال للانضمام</p>
      <div class="row" style="justify-content:center"><button class="btn soft small" data-cmd="share">مشاركة الرابط</button><button class="btn soft small" data-cmd="copy">نسخ الرابط</button></div>
    </section>
    <div class="row spread" style="margin:18px 0 8px"><h2 class="h2">اللاعبون</h2><span class="badge">${ar(n)} / ${ar(eng.meta.maxPlayers)}</span></div>
    <div>${room.players.map(p => `<div class="player-row">${avatar(p)}
      <span class="name">${esc(p.name)}${p.id === ctx.me ? ' <span class="muted">(أنت)</span>' : ''}</span>
      ${p.isHost ? '<span class="badge host">المضيف</span>' : p.connected ? (p.ready ? '<span class="badge ok">✓ جاهز</span>' : '<span class="badge">غير جاهز</span>') : '<span class="badge off">منقطع</span>'}
      ${ctx.isHost && !p.isHost ? `<button class="icon-btn" style="width:40px;height:40px;font-size:16px" data-cmd="kick" data-id="${p.id}" aria-label="إخراج ${esc(p.name)}">✕</button>` : ''}
    </div>`).join('')}</div>
    <p class="muted center" style="font-size:14px">هذه اللعبة تحتاج من ${ar(eng.meta.minPlayers)} إلى ${ar(eng.meta.maxPlayers)} لاعبين${byId(room.gameId)?.moderator ? ' (بمن فيهم المقدم)' : ''}.</p>
    ${byId(room.gameId)?.moderator ? '<p class="private-note">في هذه اللعبة المضيف هو <b>المقدم والحَكَم</b> ولا ينضم لأي فريق. باقي اللاعبين يُقسّمون عشوائيًا لفريقين عند البدء.</p>' : ''}`;

  html += `<div class="row" style="margin:6px 0 12px"><button class="btn ghost small" data-cmd="profile">${avatar(meP, 'sm')} تعديل اسمي وصورتي</button><a class="btn ghost small" href="#/g/${room.gameId}" data-cmd="rules">طريقة اللعب</a></div>`;
  html += optionsHtml(ctx);

  if (ctx.isHost) {
    const cs = room.canStart;
    html += `<div class="sticky-cta"><button class="btn block" data-cmd="start" ${cs.ok ? '' : 'disabled'}>ابدأ اللعبة</button>
      ${cs.ok ? '' : `<p class="center muted" style="margin:6px 0 0;font-size:15px">${esc(cs.error)}</p>`}</div>`;
  } else {
    html += `<div class="sticky-cta"><button class="btn block ${meP.ready ? 'soft' : ''}" data-cmd="ready" aria-pressed="${meP.ready}">${meP.ready ? '✓ جاهز — اضغط للإلغاء' : 'أنا جاهز'}</button>
      <p class="center muted" style="margin:6px 0 0;font-size:15px">المضيف يبدأ اللعبة عندما يكون الجميع جاهزًا.</p></div>`;
  }
  return html;
}

function optionsHtml(ctx) {
  const room = ctx.room, o = room.options || {}, g = room.gameId, host = ctx.isHost;
  const sel = (key, val, opts) => `<select class="input" data-opt="${key}" ${host ? '' : 'disabled'}>${opts.map(([v, l]) => `<option value="${esc(JSON.stringify(v))}" ${JSON.stringify(v) === JSON.stringify(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
  const sw = (key, val, label) => `<label class="switch-row"><span class="grow">${label}</span><input type="checkbox" class="switch" data-opt="${key}" ${val ? 'checked' : ''} ${host ? '' : 'disabled'}></label>`;
  if (g === 'mafia') {
    const d = ENGINES.mafia.normalizeOptions(o, room.players.length);
    const maxM = Math.max(1, Math.floor((Math.max(room.players.length, 5) - 1) / 2));
    return `<details class="panel" ${host ? 'open' : ''}><summary><b>إعدادات اللعبة</b>${host ? '' : ' <span class="muted">(يحددها المضيف)</span>'}</summary>
      <div class="stack" style="margin-top:10px">
      <div class="field"><label>عدد المافيا</label>${sel('mafiaCount', d.mafiaCount, [['auto', 'تلقائي حسب عدد اللاعبين (' + ar(ENGINES.mafia.autoMafia(Math.max(5, room.players.length))) + ')'], ...Array.from({ length: maxM }, (_, k) => [k + 1, ar(k + 1)])])}</div>
      <div class="field"><label>مدة النقاش</label>${sel('discussionSec', d.discussionSec, [[0, 'بدون مؤقت'], [60, 'دقيقة'], [120, 'دقيقتان'], [180, '٣ دقائق'], [300, '٥ دقائق']])}</div>
      ${sw('detective', d.detective, 'وجود المحقق')}${sw('doctor', d.doctor, 'وجود الطبيب')}
      ${sw('firstNightKill', d.firstNightKill, 'قتل في الليلة الأولى')}${sw('revealOnDeath', d.revealOnDeath, 'كشف دور من يخرج')}
      ${sw('doctorSelf', d.doctorSelf, 'الطبيب يحمي نفسه')}${sw('doctorRepeat', d.doctorRepeat, 'الطبيب يكرر نفس الشخص ليلتين')}
      </div></details>`;
  }
  if (g === 'bara') {
    const d = ENGINES.bara.normalizeOptions(o);
    const pts = [0, 1, 2, 3, 5].map(x => [x, ar(x)]);
    return `<details class="panel" ${host ? 'open' : ''}><summary><b>إعدادات اللعبة</b>${host ? '' : ' <span class="muted">(يحددها المضيف)</span>'}</summary>
      <div class="stack" style="margin-top:10px">
      <div class="field"><label>التصنيف</label>${sel('categoryId', d.categoryId, [['random', 'عشوائي كل جولة'], ...BARA_CATEGORIES.map(c => [c.id, c.icon + ' ' + c.name])])}</div>
      <div class="field"><label>عدد الجولات</label>${sel('rounds', d.rounds, [3, 5, 7, 10].map(x => [x, ar(x)]))}</div>
      <div class="field"><label>نقاط التصويت الصحيح</label>${sel('score.voteRight', d.score.voteRight, pts)}</div>
      <div class="field"><label>نقاط إفلات برا السالفة</label>${sel('score.outsiderEscape', d.score.outsiderEscape, pts)}</div>
      <div class="field"><label>نقاط تخمين الكلمة</label>${sel('score.outsiderGuess', d.score.outsiderGuess, pts)}</div>
      </div></details>`;
  }
  const eng = ENGINES[g];
  if (eng.optionSchema) {
    const d = eng.normalizeOptions ? eng.normalizeOptions(o, room.players.length) : o;
    const fields = eng.optionSchema(room.players.length);
    if (!fields.length) return '';
    return `<details class="panel" ${host ? 'open' : ''}><summary><b>إعدادات اللعبة</b>${host ? '' : ' <span class="muted">(يحددها المضيف)</span>'}</summary>
      <div class="stack" style="margin-top:10px">${fields.map(f => f.type === 'switch' ? sw(f.key, d[f.key], esc(f.label)) : `<div class="field"><label>${esc(f.label)}</label>${sel(f.key, d[f.key], f.options)}</div>`).join('')}</div></details>`;
  }
  return '';
}

function endActions(ctx) {
  return `<div class="stack" style="margin-top:20px">
    ${ctx.isHost ? `<button class="btn block" data-cmd="rematch">العب مرة أخرى بنفس اللاعبين</button><button class="btn soft block" data-cmd="toLobby">العودة لغرفة الانتظار</button>` : '<p class="center muted">بانتظار قرار المضيف: إعادة اللعب أو العودة للغرفة.</p>'}
  </div>`;
}

function joinUrl(code) {
  return location.origin + location.pathname + location.search + '#/join/' + code;
}

// ================= الأحداث =================
function bindStage(app) {
  bound = true;
  app.addEventListener('click', onClick);
  app.addEventListener('change', onChange);
  // أزرار الإجراءات داخل النوافذ المنبثقة (مثل ورقة الاتهام)
  document.getElementById('sheet-root')?.addEventListener('click', onClick);
  app.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role=button]')) { e.preventDefault(); e.target.click(); }
  });
}

async function onClick(e) {
  if (!S || location.hash !== '#/play') return;
  unlockAudio();
  const s = S;
  const ctx = s.state ? ctxFor(s) : null;
  const gameUi = s.state ? GAME_UI[s.state.room.gameId] : null;

  const actEl = e.target.closest('[data-act]');
  if (actEl && !actEl.disabled) {
    e.preventDefault();
    if (s.busy) return;
    let a; try { a = JSON.parse(actEl.dataset.act); } catch { return; }
    if (actEl.dataset.input) {
      // زر يأخذ قيمة من حقل إدخال: data-input='{"text":"#clue"}'
      let map; try { map = JSON.parse(actEl.dataset.input); } catch { map = {}; }
      for (const [k, sel] of Object.entries(map)) {
        const inp = document.querySelector(sel);
        if (!inp) continue;
        a[k] = inp.type === 'range' || inp.type === 'number' ? Number(inp.value) : inp.value;
      }
      if (a.text !== undefined && !String(a.text).trim()) { toast('اكتب شيئًا أولًا', 'err'); return; }
    }
    s.busy = true;
    actEl.disabled = true;
    gameUi?.onAct?.(a, ctx);
    play(gameUi?.kit || 'shell', 'tap');
    const r = await s.client.act(a);
    s.busy = false;
    if (!r.ok && actEl.isConnected) actEl.disabled = false;
    return;
  }
  const uiEl = e.target.closest('[data-ui]');
  if (uiEl && ctx && gameUi?.onUi) {
    withSheetScope('game', () => gameUi.onUi(uiEl.dataset.ui, uiEl, ctx, () => renderPlay()));
    return;
  }
  const cmdEl = e.target.closest('[data-cmd]');
  if (!cmdEl) return;
  const cmd = cmdEl.dataset.cmd;
  switch (cmd) {
    case 'leave': return confirmLeave();
    case 'home': endSession(true); return navigate('#/');
    case 'retry': s.client.retryNow(); return renderPlay();
    case 'mute': settings.set({ sound: !settings.get().sound }); return renderTop(s.state);
    case 'settings': return settingsSheet();
    case 'share': {
      const url = joinUrl(s.state.room.code);
      if (navigator.share) { try { await navigator.share({ title: 'سمرة', text: 'تعال العب معنا في سمرة — كود الغرفة ' + s.state.room.code, url }); } catch {} }
      else copy(url);
      return;
    }
    case 'copy': return copy(joinUrl(s.state.room.code));
    case 'profile': return editProfile();
    case 'rules': return; // الرابط ينتقل لصفحة الشرح
    case 'ready': {
      const me = s.state.room.players.find(p => p.id === s.state.you);
      play('shell', 'tap');
      return s.client.setReady(!me.ready);
    }
    case 'start': {
      cmdEl.disabled = true;
      const r = await s.client.hostCmd('start');
      if (!r.ok) cmdEl.disabled = false;
      return;
    }
    case 'kick': {
      const p = s.state.room.players.find(x => x.id === cmdEl.dataset.id);
      if (p && confirm(`إخراج ${p.name} من الغرفة؟`)) await s.client.hostCmd('kick', { target: p.id });
      return;
    }
    case 'rematch': case 'toLobby': {
      cmdEl.disabled = true;
      await s.client.hostCmd(cmd);
      return;
    }
  }
}

function onChange(e) {
  const el = e.target.closest('[data-opt]');
  if (!el || !S || !S.isHost) return;
  const key = el.dataset.opt;
  const value = el.type === 'checkbox' ? el.checked : JSON.parse(el.value);
  const o = JSON.parse(JSON.stringify(S.state.room.options || {}));
  if (key.startsWith('score.')) { o.score = { ...(ENGINES.bara.normalizeOptions(o).score), [key.slice(6)]: value }; }
  else o[key] = value;
  S.client.hostCmd('setOptions', { options: o });
}

async function copy(text) {
  try { await navigator.clipboard.writeText(text); toast('تم نسخ الرابط'); }
  catch { prompt('انسخ الرابط:', text); }
}

export async function editProfile() {
  const p = await profileSheet({ title: 'تعديل اسمي وصورتي' });
  if (!p || !S || !S.state) return;
  if (S.state.room.status !== 'lobby') { toast('سيُطبق التعديل في الغرفة القادمة'); return; }
  S.client.setProfile(p);
}

function confirmLeave() {
  const s = S;
  if (!s) return navigate('#/');
  if (!s.state || s.dead) { endSession(true); return navigate('#/'); }
  openSheet(`<h2>${s.isHost ? 'إنهاء الغرفة؟' : 'مغادرة الغرفة؟'}</h2>
    <p class="soft">${s.isHost ? 'أنت المضيف: إغلاق الغرفة ينهيها لجميع اللاعبين. إن أغلقت الصفحة بالخطأ يمكنك استعادتها من الصفحة الرئيسية.' : s.state.room.status === 'playing' ? 'ستبقى مقعدك محفوظًا ويمكنك العودة لاحقًا بنفس الكود.' : 'يمكنك الدخول مرة أخرى بنفس الكود.'}</p>
    <div class="stack"><button class="btn danger block" id="lv-yes">${s.isHost ? 'إنهاء الغرفة للجميع' : 'مغادرة'}</button>
    <button class="btn ghost block" data-sheet-close>رجوع</button></div>`, {
    label: 'تأكيد المغادرة',
    onMount(sheet, close) {
      sheet.querySelector('#lv-yes').addEventListener('click', async () => {
        close();
        if (s.isHost) { await s.client.hostCmd('close'); cleanupHost(); }
        else await s.client.leave();
        endSession(true);
        navigate('#/');
      });
    },
  });
}

function cleanupHost() {
  if (!S || !S.isHost) return;
  forgetHostRoom();
  const peer = S.peer;
  S.host?.stopTimer();
  S.host?.stopLiveness();
  keepAwake(false);
  if (S.host) S.host.closed = true;
  setTimeout(() => { try { peer?.destroy(); } catch {} }, 800);
}

export function endSession(forget) {
  if (!S) return;
  const s = S;
  S = null;
  try { s.client.close(); } catch {}
  if (s.isHost) {
    s.host?.stopTimer();
    s.host?.stopLiveness();
    keepAwake(false);
    try { s.peer?.destroy(); } catch {}
  }
  if (forget && !s.isHost) store.remove(LAST_ROOM_KEY);
  document.body.classList.remove('is-night');
}

// ================= شاشات انتظار/خطأ عامة =================
function showBusy(text) {
  const app = document.getElementById('app');
  app.innerHTML = `<div class="page"><div class="big-status" style="padding-top:30vh"><p class="h2">${esc(text)}<span class="waiting-dots"></span></p></div></div>`;
}

function showFatal(text, retry) {
  const app = document.getElementById('app');
  app.innerHTML = `<div class="page"><div class="big-status" style="padding-top:22vh"><p class="h2">تعذّر الاتصال</p><p class="soft">${esc(text)}</p>
    <div class="stack" style="max-width:320px;margin:16px auto"><button class="btn" id="f-retry">أعد المحاولة</button><a class="btn ghost" href="#/">الصفحة الرئيسية</a></div></div></div>`;
  app.querySelector('#f-retry').addEventListener('click', retry);
}

// ================= المؤقتات (عرض فقط — المضيف هو من ينهي الوقت) =================
const ticked = new Set();
function tickTimers() {
  if (!S || !S.state) return;
  const els = document.querySelectorAll('[data-deadline]');
  if (!els.length) return;
  const kit = GAME_UI[S.state.room.gameId]?.kit || 'shell';
  els.forEach(el => {
    const dl = Number(el.dataset.deadline);
    const left = dl - S.client.serverNow();
    el.textContent = fmtTime(left);
    el.classList.toggle('low', left < 10000);
    const sec = Math.ceil(left / 1000);
    const key = dl + ':' + sec;
    if (sec > 0 && sec <= 5 && !ticked.has(key)) { ticked.add(key); play(kit, 'tick'); }
    if (left <= 0 && !ticked.has(dl + ':up')) { ticked.add(dl + ':up'); play(kit, 'timeUp'); }
  });
}

export function startTimerLoop() {
  if (timerLoop) return;
  timerLoop = setInterval(tickTimers, 250);
}

document.addEventListener('samra:edit-profile', () => { if (S && location.hash === '#/play') editProfile(); else profileSheet({ title: 'تعديل اسمي وصورتي' }); });
settings.subscribe(() => { if (S && location.hash === '#/play') renderTop(S.state); });

// أداة فحص للاختبارات فقط (?debug): تعرض آخر رسالة استلمها هذا الجهاز كما هي
if (typeof location !== 'undefined' && new URLSearchParams(location.search).has('debug')) {
  window.__samraDebug = () => (S ? { state: S.state, status: S.status, isHost: S.isHost, hostRoom: S.host ? S.host.room : null } : null);
  window.__samraS = () => S; // وصول للاختبار فقط: محاكاة انقطاعات
  window.__samraWake = () => (wakeLock ? 'held' : 'none');
}

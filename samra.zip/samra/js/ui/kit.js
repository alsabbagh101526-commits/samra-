// مكونات واجهة مشتركة بين الألعاب
import { esc, ar, avatar } from './dom.js';

export const nm = (ctx, id) => esc(ctx.player(id)?.name || '؟');
export const who = (ctx, id, size = 'sm') => `${avatar(ctx.player(id), size)} <b>${nm(ctx, id)}</b>`;
export const chip = (ctx, id, extra = '', cls = '') => `<span class="badge ${cls}">${esc(ctx.player(id)?.emoji || '')} ${nm(ctx, id)}${extra}</span>`;
export const act = a => `data-act='${JSON.stringify(a).replace(/'/g, '&#39;')}'`;
export const btn = (label, a, cls = '', extra = '') => `<button class="btn ${cls}" ${act(a)} ${extra}>${label}</button>`;
export const wait = t => `<p class="center soft" style="margin:12px 0">${t}<span class="waiting-dots"></span></p>`;
export const panel = (html, cls = '', style = '') => `<div class="panel ${cls}" style="${style}">${html}</div>`;

export function targets(ctx, ids, { action, field = 'target', extra = {}, disabled = () => false, mark = () => '', selected = null, ui = null } = {}) {
  return `<div class="target-list">${ids.map(id => {
    const d = disabled(id), m = mark(id);
    const attr = ui ? `data-ui="${ui}" data-id="${id}"` : act({ type: action, [field]: id, ...extra });
    const sel = Array.isArray(selected) ? selected.includes(id) : selected === id;
    return `<button class="target" ${d ? 'disabled' : ''} aria-pressed="${sel}" ${attr}>${avatar(ctx.player(id), 'sm')}<span class="t-name">${nm(ctx, id)}${id === ctx.me ? ' (أنت)' : ''}${m ? `<br><span class="t-mark">${esc(m)}</span>` : ''}</span></button>`;
  }).join('')}</div>`;
}

export function teamsBlock(ctx, teams, labels = { A: 'الفريق الأول', B: 'الفريق الثاني' }, score = null) {
  return `<div class="teams">${['A', 'B'].map(t => `<div class="team team-${t}"><div class="row spread"><b>${labels[t]}</b>${score ? `<span class="team-score">${ar(score[t])}</span>` : ''}</div>
    <div class="row wrap" style="gap:6px;margin-top:6px">${teams[t].map(id => chip(ctx, id, id === ctx.me ? ' (أنت)' : '')).join('')}</div></div>`).join('')}</div>`;
}

// بطاقة لعب سرية عامة: ظهر + وجه
export function card({ cls = '', back = '', front = '', flipped = false, attrs = '', hint = '' }) {
  return `<div class="card ${cls} ${flipped ? 'is-flipped' : ''}" ${attrs}><div class="card-inner">
    <div class="card-face card-back">${back}${hint ? `<div class="tap-hint">${hint}</div>` : ''}</div>
    <div class="card-face card-front">${front}</div></div></div>`;
}

export function roleFront({ type = '', name, desc, art = '', tone = '' }) {
  return `<div class="cf role-front ${tone}"><div class="cf-head"><span class="cf-type">${type}</span></div>
    <div class="cf-art">${art}</div><div><h3 class="cf-name">${name}</h3><p class="cf-desc">${desc}</p></div></div>`;
}

// مرحلة كشف الدور ثم "جاهز" — مشتركة بين ألعاب الأدوار السرية
export function revealStep(ctx, { cardHtml, readyCount, total, ready, after = '' }) {
  if (ready) return `<div class="big-status"><p class="h2">بانتظار البقية<span class="waiting-dots"></span></p><p class="soft">${ar(readyCount)} من ${ar(total)} جاهزون</p></div>`;
  let h = `<p class="center soft" style="margin:4px 0 14px">اكشف بطاقتك بعيدًا عن أعين الآخرين.</p>${cardHtml}`;
  if (ctx.ui.revealed) h += `<p class="private-note">هذه المعلومة خاصة بك — لا تعرضها لأحد.</p>${after}<div style="margin-top:16px">${btn('حفظت دوري — جاهز', { type: 'ready' }, 'block')}</div>`;
  return h;
}

export function flipReveal(name, el, ctx, rerender, sound = 'flip') {
  if (name === 'reveal' && !ctx.ui.revealed) {
    ctx.ui.revealed = true;
    el.classList.add('is-flipped');
    ctx.sfx(sound);
    setTimeout(rerender, 760);
    return true;
  }
  return false;
}

export function toggleSel(ctx, key, value, max = Infinity) {
  const arr = (ctx.ui[key] ||= []);
  const k = arr.indexOf(value);
  if (k >= 0) arr.splice(k, 1);
  else if (arr.length < max) arr.push(value);
}

export function voteRow(ctx, players, flag = 'voted') {
  return `<div class="row wrap" style="justify-content:center;margin-top:12px;gap:6px">${players.map(p => chip(ctx, p.id, p[flag] ? ' ✓' : ' …', p[flag] ? 'ok' : '')).join('')}</div>`;
}

export function timerHtml(deadline) {
  return deadline ? `<div class="timer" data-deadline="${deadline}">--:--</div>` : '';
}

export function winnerBanner(title, sub = '', color = 'var(--accent)') {
  return `<div class="center pop-in" style="padding:8px 0 14px"><p class="h1" style="color:${color}">${title}</p>${sub ? `<p class="soft" style="margin:0">${sub}</p>` : ''}</div>`;
}

export function logBlock(lines) {
  if (!lines || !lines.length) return '';
  return `<details class="panel" style="margin-top:12px"><summary class="soft" style="cursor:pointer">سجل الأحداث</summary>${lines.slice().reverse().map(l => `<div style="font-size:14px;padding:2px 0">${esc(l)}</div>`).join('')}</details>`;
}

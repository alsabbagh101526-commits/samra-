// نقل محلي داخل نفس الجهاز — يستخدمه المضيف ليلعب بنفس مسار اللاعبين تمامًا
export function createLocalPair({ local = true } = {}) {
  const make = () => ({ msgH: [], closeH: [], open: true });
  const a = make(), b = make();
  const side = (me, other, isLocal) => ({
    local: isLocal,
    send(msg) {
      if (!me.open) throw new Error('closed');
      const copy = JSON.parse(JSON.stringify(msg)); // نفس سلوك الشبكة: نسخة وليست مرجعًا
      queueMicrotask(() => { if (other.open) other.msgH.forEach(f => f(copy)); });
    },
    close() {
      if (!me.open) return;
      me.open = false; other.open = false;
      queueMicrotask(() => { me.closeH.forEach(f => f()); other.closeH.forEach(f => f()); });
    },
    onMessage(f) { me.msgH.push(f); },
    onClose(f) { me.closeH.push(f); },
  });
  return { client: side(a, b, false), host: side(b, a, local) };
}

export function localTransport(hostSession, opts) {
  return {
    async connect() {
      const { client, host } = createLocalPair(opts);
      hostSession.attach(host);
      return client;
    },
  };
}

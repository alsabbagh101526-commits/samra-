// طبقة النقل عبر WebRTC (PeerJS). خادم PeerJS يُستخدم فقط لتعارف الأجهزة،
// أما بيانات اللعب فتنتقل مباشرة بين الأجهزة.
import { peerIdFor } from './protocol.js';

export function peerConfig() {
  const q = new URLSearchParams(location.search);
  const custom = q.get('peer'); // للاختبار أو لخادم ربط خاص: ?peer=host:port
  const base = { debug: 0, config: undefined };
  if (custom) {
    const [host, port] = custom.split(':');
    return { ...base, host, port: Number(port) || 9000, path: '/', secure: location.protocol === 'https:' && q.get('peerSecure') !== '0' && host !== '127.0.0.1' && host !== 'localhost' };
  }
  return base;
}

const PeerCtor = () => {
  if (typeof window === 'undefined' || !window.Peer) throw Object.assign(new Error('peerjs missing'), { code: 'no-peerjs' });
  if (!window.RTCPeerConnection) throw Object.assign(new Error('no webrtc'), { code: 'no-webrtc' });
  return window.Peer;
};

// PeerJS يرفض أي رسالة JSON حجمها 16300 بايت أو أكثر (لا يرسلها ويطلق error دون إغلاق).
// لذلك نقسّم الرسائل الكبيرة بأنفسنا إلى أجزاء صغيرة ونعيد تجميعها عند الاستلام.
const CHUNK_OVER = 12000;   // بايت: ما فوقه يُقسَّم
const CHUNK_CHARS = 3000;   // حرف لكل جزء (أسوأ حالة ≈ 9–12 ألف بايت بعد الترميز)
const enc = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;
const byteLen = str => (enc ? enc.encode(str).length : str.length * 3);
let chunkSeq = 0;

// تغليف اتصال PeerJS بواجهة النقل الموحدة
export function wrap(dc) {
  const parts = new Map(); // id -> {n, got, arr}
  const conn = {
    local: false,
    send(m) {
      const str = JSON.stringify(m);
      if (byteLen(str) < CHUNK_OVER) { dc.send(m); return; }
      const id = ++chunkSeq;
      const n = Math.ceil(str.length / CHUNK_CHARS);
      for (let i = 0; i < n; i++) dc.send({ t: '~', id, i, n, d: str.slice(i * CHUNK_CHARS, (i + 1) * CHUNK_CHARS) });
    },
    close() { try { dc.close(); } catch {} },
    onMessage(f) {
      dc.on('data', m => {
        if (m && m.t === '~') {
          if (!Number.isInteger(m.id) || !Number.isInteger(m.i) || !Number.isInteger(m.n) || m.n < 1 || m.n > 400 || m.i < 0 || m.i >= m.n || typeof m.d !== 'string') return;
          let p = parts.get(m.id);
          if (!p) { if (parts.size > 8) parts.clear(); p = { n: m.n, got: 0, arr: new Array(m.n) }; parts.set(m.id, p); }
          if (p.arr[m.i] === undefined) { p.arr[m.i] = m.d; p.got++; }
          if (p.got === p.n) { parts.delete(m.id); let whole; try { whole = JSON.parse(p.arr.join('')); } catch { return; } f(whole); }
          return;
        }
        f(m);
      });
    },
    // الإغلاق الفعلي فقط. حدث error لا يعني الإغلاق إذا كانت القناة ما زالت مفتوحة
    onClose(f) {
      let done = false;
      const once = () => { if (!done) { done = true; f(); } };
      dc.on('close', once);
      dc.on('error', () => { if (!dc.open) once(); });
    },
  };
  if (typeof location !== 'undefined' && /[?&]debug/.test(location.search)) conn._dc = dc; // للاختبار فقط
  return conn;
}

export function startPeerHost({ code, onConnection, onStatus }) {
  return new Promise((resolve, reject) => {
    let Peer;
    try { Peer = PeerCtor(); } catch (e) { return reject(e); }
    const peer = new Peer(peerIdFor(code), peerConfig());
    let opened = false;
    const t = setTimeout(() => { if (!opened) { peer.destroy(); reject(Object.assign(new Error('timeout'), { code: 'signal-timeout' })); } }, 20000);
    peer.on('open', () => { opened = true; clearTimeout(t); onStatus?.('online'); resolve(peer); });
    peer.on('connection', dc => {
      let done = false;
      const go = () => { if (!done) { done = true; onConnection(wrap(dc)); } };
      if (dc.open) go(); else dc.on('open', go);
    });
    peer.on('disconnected', () => {
      // انقطع خادم التعارف فقط — الاتصالات القائمة تبقى؛ نحاول العودة
      onStatus?.('signal-lost');
      setTimeout(() => { if (!peer.destroyed) try { peer.reconnect(); } catch {} }, 1500);
    });
    peer.on('error', e => {
      if (!opened) { clearTimeout(t); peer.destroy(); reject(Object.assign(new Error(e.type), { code: e.type })); }
      else onStatus?.('error:' + e.type);
    });
  });
}

export function peerClientTransport({ code, timeoutMs = 15000 }) {
  let peer = null;
  return {
    connect() {
      return new Promise((resolve, reject) => {
        let Peer;
        try { Peer = PeerCtor(); } catch (e) { return reject(e); }
        if (peer) { try { peer.destroy(); } catch {} }
        peer = new Peer(peerConfig());
        let settled = false;
        const fail = codeStr => { if (settled) return; settled = true; clearTimeout(t); try { peer.destroy(); } catch {} reject(Object.assign(new Error(codeStr), { code: codeStr })); };
        const t = setTimeout(() => fail('peer-timeout'), timeoutMs);
        peer.on('error', e => fail(e.type === 'peer-unavailable' ? 'room-not-found' : e.type));
        peer.on('open', () => {
          const dc = peer.connect(peerIdFor(code), { reliable: true, serialization: 'json' });
          dc.on('open', () => { if (settled) return; settled = true; clearTimeout(t); resolve(wrap(dc)); });
          dc.on('error', () => fail('peer-error'));
        });
      });
    },
  };
}

export const NET_MESSAGES = {
  'room-not-found': 'لم يتم العثور على الغرفة. تأكد من الكود وأن المضيف ما زال فاتحًا للغرفة.',
  'peer-timeout': 'تعذّر الوصول لجهاز المضيف. بعض الشبكات (مثل شبكات الضيوف أو بيانات الجوال) تمنع الاتصال المباشر بين الأجهزة. جرّبوا شبكة Wi-Fi أخرى.',
  'network': 'لا يوجد اتصال بالإنترنت أو تعذّر الوصول لخادم التعارف.',
  'server-error': 'خادم التعارف لا يستجيب حاليًا. حاول بعد قليل.',
  'socket-error': 'انقطع الاتصال بخادم التعارف.',
  'signal-timeout': 'تعذّر الوصول لخادم التعارف خلال الوقت المحدد. تأكد من الإنترنت.',
  'unavailable-id': 'رمز الغرفة مستخدم حاليًا.',
  'no-webrtc': 'هذا المتصفح لا يدعم الاتصال المباشر بين الأجهزة. استخدم Chrome أو Safari حديثًا.',
  'no-peerjs': 'تعذّر تحميل مكتبة الاتصال.',
  'browser-incompatible': 'هذا المتصفح لا يدعم الاتصال المباشر بين الأجهزة.',
  'dropped': 'انقطع الاتصال بالمضيف — جارٍ إعادة الاتصال…',
  'timeout': 'الاتصال بطيء أو مقطوع — جارٍ إعادة الاتصال…',
  'no-welcome': 'لم يرد المضيف — جارٍ المحاولة…',
};

// جلسة المضيف — المصدر الوحيد للحقيقة. لا يثق بأي بيانات قادمة من اللاعبين.
// مستقلة عن طريقة النقل (WebRTC أو محلي أو اختبار).
import { createRng, randomSeed } from '../core/rng.js';
import {
  PROTOCOL_VERSION, MAX_ROOM_PLAYERS, MAX_MSG_BYTES,
  sanitizeName, sanitizeEmoji, randomToken,
} from './protocol.js';
const DBG = typeof location !== 'undefined' && /[?&]debug/.test(location.search);
const dbg = (...a) => { if (DBG) console.log('[samra]', ...a); };

// نرسل آخر رسالة ثم نغلق بعد مهلة قصيرة حتى لا تضيع الرسالة
function closeSoon(conn, ms = 400) {
  setTimeout(() => { try { conn.close(); } catch {} }, ms);
}

export class HostSession {
  constructor({ engines, code, gameId, now = () => Date.now(), onSave = null, restored = null }) {
    this.engines = engines;
    this.now = now;
    this.onSave = onSave;
    this.conns = new Map(); // playerId -> conn
    this.listeners = new Set();
    if (restored) {
      this.room = restored;
      for (const p of this.room.players) p.connected = false;
      this.rng = createRng(this.room.rngState);
    } else {
      const seed = randomSeed();
      this.rng = createRng(seed);
      this.room = {
        v: PROTOCOL_VERSION, code, gameId,
        status: 'lobby', options: {}, players: [], hostId: null,
        game: null, lastSeq: {}, matchNo: 0, rngState: seed, nextId: 1,
      };
    }
    this.timer = null;
  }

  // ---------- الاتصالات ----------
  attach(conn) {
    let playerId = null;
    conn.onMessage(raw => {
      let msg = raw;
      try {
        if (typeof raw === 'string') {
          if (raw.length > MAX_MSG_BYTES) return;
          msg = JSON.parse(raw);
        } else if (JSON.stringify(raw).length > MAX_MSG_BYTES) return;
      } catch { return; }
      if (!msg || typeof msg.t !== 'string') return;
      conn._seen = this.now();
      if (msg.t === 'hello') { playerId = this._hello(conn, msg, playerId); return; }
      if (!playerId) return;
      if (this.conns.get(playerId) !== conn && !this._readopt(playerId, conn)) return; // اتصال قديم: لا نرد عليه
      if (msg.t === 'ping') { conn.send({ t: 'pong', c: msg.c, now: this.now() }); return; }
      this._handle(playerId, conn, msg);
    });
    conn.onClose(() => {
      dbg('host: conn closed', playerId, this.conns.get(playerId) === conn ? 'current' : 'stale');
      if (playerId && this.conns.get(playerId) === conn) {
        this.conns.delete(playerId);
        const p = this._player(playerId);
        if (p) {
          p.connected = false;
          this._fx('leave', p.id);
          this._changed();
        }
      }
    });
  }

  // اتصال ما زال حيًّا لكن المضيف اعتبره مغلقًا (مثلًا بعد خطأ عابر): نعيد اعتماده بدل ترك اللاعب «منقطعًا» للأبد
  _readopt(pid, conn) {
    if (this.closed || this.conns.has(pid)) return false; // له اتصال أحدث
    const p = this._player(pid);
    if (!p) return false; // خرج أو أُخرج
    dbg('host: re-adopting live conn for', pid);
    this.conns.set(pid, conn);
    p.connected = true;
    this._fx('join', p.id);
    this._changed();
    return true;
  }

  // فحص الاتصالات الصامتة: اللاعب يرسل نبضة كل ٤ ثوانٍ؛ صمت طويل = جهاز نائم أو شبكة مقطوعة
  checkLiveness(maxSilentMs = 20000, everyMs = 3000) {
    const now = this.now();
    const gap = this._lastLive ? now - this._lastLive : 0;
    this._lastLive = now;
    // إذا كانت صفحة المضيف نفسها متوقفة (خلفية/قفل شاشة) فالصمت منه لا منهم: نمنح مهلة جديدة
    if (gap > everyMs * 3) { for (const c of this.conns.values()) c._seen = now; return; }
    for (const [pid, c] of [...this.conns]) {
      if (c.local || !c._seen || now - c._seen <= maxSilentMs) continue;
      dbg('host: silent conn closed', pid);
      this.conns.delete(pid);
      try { c.close(); } catch {}
      const p = this._player(pid);
      if (p) { p.connected = false; this._fx('leave', p.id); }
      this._changed();
    }
  }
  startLiveness(everyMs = 3000, maxSilentMs = 20000) {
    this.stopLiveness();
    if (typeof setInterval === 'undefined') return;
    this._lastLive = this.now();
    this.liveTimer = setInterval(() => this.checkLiveness(maxSilentMs, everyMs), everyMs);
  }
  stopLiveness() { if (this.liveTimer) clearInterval(this.liveTimer); this.liveTimer = null; }

  _hello(conn, msg, current) {
    if (msg.v !== PROTOCOL_VERSION) { conn.send({ t: 'reject', reason: 'version' }); return current; }
    const r = this.room;
    if (typeof msg.token === 'string' && (r.banned || []).includes(msg.token)) { conn.send({ t: 'reject', reason: 'kicked' }); closeSoon(conn); return current; }
    let p = typeof msg.token === 'string' ? r.players.find(x => x.token === msg.token) : null;
    // نفس الاتصال أرسل hello مرة أخرى، أو نفس الجهاز أعاد المحاولة قبل وصول الترحيب: نفس المقعد
    if (!p && current) p = this._player(current) || null;
    const cid = typeof msg.cid === 'string' && msg.cid.length <= 64 ? msg.cid : null;
    if (!p && cid) p = r.players.find(x => x.cid === cid) || null;
    if (p) {
      // إعادة اتصال: نفس اللاعب ونفس المقعد — لا يُنشأ لاعب جديد
      const old = this.conns.get(p.id);
      if (old && old !== conn) { dbg('host: replaced conn for', p.id); try { old.send({ t: 'closed', reason: 'replaced' }); } catch {} closeSoon(old); }
    } else {
      if (r.status !== 'lobby') { conn.send({ t: 'reject', reason: 'in-progress' }); return current; }
      if (r.players.length >= MAX_ROOM_PLAYERS) { conn.send({ t: 'reject', reason: 'full' }); return current; }
      p = {
        id: 'u' + (r.nextId++), token: randomToken(),
        name: sanitizeName(msg.name) || 'لاعب', emoji: sanitizeEmoji(msg.emoji),
        ready: false, connected: true, isHost: !!msg.asHost && !r.hostId && conn.local === true, cid,
      };
      if (p.isHost) r.hostId = p.id;
      r.players.push(p);
    }
    p.connected = true;
    this.conns.set(p.id, conn);
    conn.send({ t: 'welcome', id: p.id, token: p.token, lastSeq: r.lastSeq[p.id] || 0, code: r.code });
    this._fx('join', p.id);
    this._changed();
    return p.id;
  }

  _handle(pid, conn, msg) {
    const r = this.room;
    const p = this._player(pid);
    if (!p) return;
    const reply = (ok, error) => { if (msg.seq != null) conn.send({ t: 'ack', seq: msg.seq, ok, error }); };

    // منع تكرار نفس الطلب (إعادة الإرسال بعد انقطاع)
    if (msg.seq != null) {
      if (!Number.isInteger(msg.seq) || msg.seq <= (r.lastSeq[pid] || 0)) { conn.send({ t: 'ack', seq: msg.seq, ok: true, dup: true }); return; }
      r.lastSeq[pid] = msg.seq;
    }

    switch (msg.t) {
      case 'profile': {
        if (r.status !== 'lobby') return reply(false, 'لا يمكن تغيير الملف أثناء اللعب');
        const name = sanitizeName(msg.name);
        if (name) p.name = name;
        p.emoji = sanitizeEmoji(msg.emoji);
        reply(true); return this._changed();
      }
      case 'ready': {
        if (r.status !== 'lobby') return reply(false, 'اللعبة بدأت');
        p.ready = !!msg.value;
        reply(true); return this._changed();
      }
      case 'leave': {
        reply(true);
        this._removeOrDisconnect(p);
        closeSoon(conn);
        return;
      }
      case 'act': {
        if (r.status !== 'playing' || !r.game) return reply(false, 'لا توجد لعبة جارية');
        const eng = this.engines[r.gameId];
        const res = eng.act(r.game.state, pid, msg.a, { rng: this.rng, now: this.now(), isHost: p.isHost });
        reply(res.ok, res.error);
        if (res.ok) this._changed();
        return;
      }
      case 'host': {
        if (!p.isHost) return reply(false, 'هذا الإجراء للمضيف فقط');
        const res = this._hostCmd(msg);
        reply(res.ok, res.error);
        if (res.ok) this._changed();
        return;
      }
    }
  }

  _hostCmd(msg) {
    const r = this.room;
    switch (msg.cmd) {
      case 'setOptions': {
        if (r.status !== 'lobby') return { ok: false, error: 'اللعبة بدأت' };
        if (!msg.options || typeof msg.options !== 'object') return { ok: false, error: 'إعدادات غير صالحة' };
        const eng = this.engines[r.gameId];
        r.options = eng.normalizeOptions ? eng.normalizeOptions(msg.options, r.players.length) : {};
        return { ok: true };
      }
      case 'kick': {
        if (r.status !== 'lobby') return { ok: false, error: 'لا يمكن الطرد أثناء اللعب' };
        const t = this._player(msg.target);
        if (!t || t.isHost) return { ok: false, error: 'لاعب غير صالح' };
        const c = this.conns.get(t.id);
        if (c) { try { c.send({ t: 'closed', reason: 'kicked' }); } catch {} closeSoon(c); }
        (r.banned ||= []).push(t.token);
        this._removeOrDisconnect(t, true);
        return { ok: true };
      }
      case 'start': return this._start();
      case 'rematch': {
        if (r.status !== 'playing') return { ok: false, error: 'لا توجد لعبة' };
        return this._start(true);
      }
      case 'toLobby': {
        r.status = 'lobby';
        r.game = null;
        for (const p of r.players) p.ready = p.isHost;
        // اللاعبون الذين غادروا نهائيًا يُزالون عند العودة للغرفة
        r.players = r.players.filter(p => p.connected || p.isHost);
        return { ok: true };
      }
      case 'close': {
        for (const [, c] of this.conns) { try { c.send({ t: 'closed', reason: 'ended' }); } catch {} }
        this.closed = true;
        this.stopTimer();
        return { ok: true };
      }
      default: return { ok: false, error: 'أمر غير معروف' };
    }
  }

  startCheck() {
    const r = this.room;
    const eng = this.engines[r.gameId];
    const n = r.players.length;
    if (!eng) return { ok: false, error: 'اللعبة غير متاحة' };
    if (n < eng.meta.minPlayers) return { ok: false, error: `تحتاج ${eng.meta.minPlayers} لاعبين على الأقل` };
    if (n > eng.meta.maxPlayers) return { ok: false, error: `الحد الأقصى ${eng.meta.maxPlayers} لاعبين` };
    if (r.players.some(p => !p.connected)) return { ok: false, error: 'بعض اللاعبين غير متصلين' };
    if (r.players.some(p => !p.isHost && !p.ready)) return { ok: false, error: 'بانتظار جاهزية جميع اللاعبين' };
    return { ok: true };
  }

  _start(rematch = false) {
    const r = this.room;
    if (!rematch && r.status !== 'lobby') return { ok: false, error: 'اللعبة بدأت' };
    if (rematch) {
      const eng = this.engines[r.gameId];
      if (r.players.length < eng.meta.minPlayers) return { ok: false, error: 'عدد اللاعبين لا يكفي' };
    } else {
      const c = this.startCheck();
      if (!c.ok) return c;
    }
    const eng = this.engines[r.gameId];
    const order = this.rng.shuffle(r.players);
    const state = eng.setup(order.map(p => ({ id: p.id, isHost: p.isHost })), r.options, this.rng);
    r.game = { state };
    r.status = 'playing';
    r.matchNo++;
    this.startTimer();
    return { ok: true };
  }

  _removeOrDisconnect(p, force = false) {
    const r = this.room;
    this.conns.delete(p.id);
    if (r.status === 'lobby' || force) {
      r.players = r.players.filter(x => x.id !== p.id);
    } else {
      p.connected = false;
    }
    this._fx('leave', p.id);
    this._changed();
  }

  // ---------- المؤقت ----------
  startTimer() {
    this.stopTimer();
    if (typeof setInterval === 'undefined') return;
    this.timer = setInterval(() => this.tick(), 500);
  }
  stopTimer() { if (this.timer) clearInterval(this.timer); this.timer = null; }
  tick() {
    const r = this.room;
    if (r.status !== 'playing' || !r.game) return;
    const eng = this.engines[r.gameId];
    if (eng.tick && eng.tick(r.game.state, this.now(), this.rng)) this._changed();
  }

  // ---------- البث ----------
  _player(id) { return this.room.players.find(p => p.id === id); }

  _fx(kind, who) {
    // أحداث الغرفة (دخول/خروج) للمؤثرات فقط
    this.roomFxSeq = (this.roomFxSeq || 0) + 1;
    this.lastRoomFx = { id: this.roomFxSeq, kind, who };
  }

  publicRoom() {
    const r = this.room;
    return {
      code: r.code, gameId: r.gameId, status: r.status, options: r.options,
      hostId: r.hostId, matchNo: r.matchNo,
      players: r.players.map(p => ({ id: p.id, name: p.name, emoji: p.emoji, ready: p.ready, connected: p.connected, isHost: p.isHost })),
      roomFx: this.lastRoomFx || null,
      canStart: r.status === 'lobby' ? this.startCheck() : null,
    };
  }

  // كل لاعب يستلم نسخة مفصّلة له فقط — لا تُرسل أسرار الآخرين ثم تُخفى بالواجهة
  viewFor(pid) {
    const r = this.room;
    let game = null, summary = null;
    if (r.status === 'playing' && r.game) {
      const eng = this.engines[r.gameId];
      game = eng.view(r.game.state, pid);
      if (game.phase === 'over' && eng.summary) summary = eng.summary(r.game.state);
    }
    return { t: 'state', now: this.now(), you: pid, room: this.publicRoom(), game, summary };
  }

  _changed() {
    this.room.rngState = this.rng.state();
    for (const [pid, c] of this.conns) {
      try { c.send(this.viewFor(pid)); } catch {}
    }
    for (const fn of this.listeners) fn(this.room);
    if (this.onSave) this.onSave(this.room);
  }

  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  serialize() { this.room.rngState = this.rng.state(); return JSON.parse(JSON.stringify(this.room)); }
}

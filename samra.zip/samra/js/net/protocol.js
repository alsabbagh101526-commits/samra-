// بروتوكول الرسائل بين المضيف واللاعبين + التحقق من المدخلات
export const PROTOCOL_VERSION = 1;
export const MAX_ROOM_PLAYERS = 16;
export const MAX_MSG_BYTES = 4096;

export const AVATARS = [
  '😎', '🤠', '🧐', '🤓', '😏', '🥸', '🤡', '👻', '👽', '🤖', '🎃', '😺',
  '🦊', '🐺', '🦁', '🐯', '🐻', '🐼', '🐨', '🐸', '🐵', '🦉', '🦅', '🐪',
  '🐎', '🦄', '🐙', '🦈', '🐢', '🦂', '🌙', '⭐', '🔥', '⚡', '🍉', '🌶️',
  '☕', '🎲', '🃏', '🎯', '👑', '💎', '🗝️', '🛡️', '⚓', '🎩', '🕶️', '🧿',
];

export function sanitizeName(raw) {
  if (typeof raw !== 'string') return '';
  // إزالة محارف التحكم وعلامات الاتجاه التي قد تكسر عرض الواجهة
  const clean = raw.replace(/[\u0000-\u001f\u007f\u200e\u200f\u202a-\u202e\u2066-\u2069<>]/g, '').replace(/\s+/g, ' ').trim();
  return Array.from(clean).slice(0, 18).join('');
}

export function sanitizeEmoji(raw) {
  return AVATARS.includes(raw) ? raw : AVATARS[0];
}

export function randomCode() {
  const n = typeof crypto !== 'undefined' && crypto.getRandomValues
    ? crypto.getRandomValues(new Uint32Array(1))[0]
    : Math.floor(Math.random() * 2 ** 32);
  return String(100000 + (n % 900000));
}

export function randomToken() {
  const a = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) crypto.getRandomValues(a);
  else for (let i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
  return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
}

export function peerIdFor(code) {
  return 'samra-arab-games-v1-' + code;
}

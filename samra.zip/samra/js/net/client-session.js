// جلسة اللاعب — ترسل طلبات فقط، ولا تغيّر حالة اللعبة محليًا أبدًا.
import { PROTOCOL_VERSION } from './protocol.js';
const DBG = typeof location !== 'undefined' && /[?&]debug/.test(location.search);

const RETRY_STEPS = [800, 1500, 2500, 4000, 6000, 8000];
const GIVE_UP_MS = 90000;

export class ClientSession {
  constructor({ transport, code, store, profile, asHost = false, now = () => Date.now(), welcomeTimeoutMs = 8000 }) {
    this.transport = transport;
    this.welcomeTimeoutMs = welcomeTimeoutMs;
    this.code = code;
    this.store = store;
    this.profile = profile;
    this.asHost = asHost;
    this.now = now;
    this.key = 'samra.session.' + code;
    const saved = store.get(this.key) || {};
    this.token = saved.token || null;
    this.seq = saved.seq || 0;
    // معرّف ثابت لهذا الجهاز في هذه الغرفة: يمنع إنشاء مقعد ثانٍ إن ضاع الترحيب وأعدنا المحاولة
    this.cid = saved.cid || (Math.random().toString(36).slice(2) + Date.now().toString(36));
    if (!saved.cid) store.set(this.key, { ...saved, cid: this.cid });
    this.status = 'idle';
    this.handlers = {};
    this.lastState = null;
    this.clockOffset = 0;
    this.pending = new Map();
    this.conn = null;
    this.closedByUser = false;
    this.retry = 0;
    this.lostSince = null;
  }

  on(ev, fn) { (this.handlers[ev] ||= new Set()).add(fn); return () => this.handlers[ev].delete(fn); }
  emit(ev, data) { for (const fn of this.handlers[ev] || []) { try { fn(data); } catch (e) { console.error(e); } } }

  setStatus(s, detail) { if (DBG && s !== this.status) console.log('[samra] client status', this.status, '->', s, detail || ''); this.status = s; this.emit('status', { status: s, detail }); }

  async start() {
    if (this.starting) return; // لا نفتح اتصالين متوازيين
    if (typeof location !== 'undefined' && /[?&]debug/.test(location.search)) console.log('[samra] client.start', this.code);
    this.starting = true;
    this.closedByUser = false;
    this.setStatus(this.lastState ? 'reconnecting' : 'connecting');
    let conn;
    try {
      conn = await this.transport.connect();
    } catch (e) {
      this.starting = false;
      return this._lost(e?.code || 'connect-failed');
    }
    this.starting = false;
    if (this.closedByUser) { try { conn.close(); } catch {} return; }
    const old = this.conn;
    this.conn = conn;
    if (old && old !== conn) { try { old.close(); } catch {} }
    let welcomed = false;
    conn.onMessage(msg => {
      if (this.conn !== conn) return; // رسائل اتصال قديم
      if (typeof msg === 'string') { try { msg = JSON.parse(msg); } catch { return; } }
      if (!msg || typeof msg.t !== 'string') return;
      this.lastHeard = this.now();
      switch (msg.t) {
        case 'welcome':
          welcomed = true;
          clearTimeout(welcomeTimer);
          this.token = msg.token;
          this.playerId = msg.id;
          this.seq = Math.max(this.seq, msg.lastSeq || 0);
          this._save();
          this.retry = 0; this.lostSince = null;
          this.setStatus('online');
          this._startHeartbeat();
          break;
        case 'state':
          this.clockOffset = msg.now - this.now();
          this.lastState = msg;
          this.emit('state', msg);
          break;
        case 'ack': {
          const p = this.pending.get(msg.seq);
          if (p) { this.pending.delete(msg.seq); p(msg); }
          if (!msg.ok && !msg.dup) this.emit('error', msg.error);
          break;
        }
        case 'pong':
          if (msg.c) this.clockOffset = msg.now - (msg.c + (this.now() - msg.c) / 2);
          break;
        case 'reject':
          this.closedByUser = true;
          this.setStatus('rejected', msg.reason);
          if (msg.reason !== 'in-progress') this.forget();
          break;
        case 'closed':
          this.closedByUser = true;
          this.setStatus('closed', msg.reason);
          if (msg.reason !== 'replaced') this.forget(); // تبويب آخر أخذ المقعد: لا نحذف الرمز المشترك
          break;
      }
    });
    // اتصال فُتح لكن المضيف لم يرحّب: لا ننتظر للأبد (النبضة لا تبدأ إلا بعد الترحيب)
    const welcomeTimer = setTimeout(() => {
      if (welcomed || this.conn !== conn || this.closedByUser) return;
      if (DBG) console.log('[samra] client: no welcome — retrying');
      this.conn = null;
      try { conn.close(); } catch {}
      this._lost('no-welcome');
    }, this.welcomeTimeoutMs);
    conn.onClose(() => {
      clearTimeout(welcomeTimer);
      if (this.conn !== conn) return; // اتصال قديم استُبدل — لا نعيد الاتصال بسببه
      this._stopHeartbeat();
      this.conn = null;
      if (!this.closedByUser) this._lost(welcomed ? 'dropped' : 'no-welcome');
    });
    conn.send({ t: 'hello', v: PROTOCOL_VERSION, token: this.token, cid: this.cid, name: this.profile.name, emoji: this.profile.emoji, asHost: this.asHost });
  }

  _lost(reason) {
    if (this.closedByUser) return;
    if (!this.lostSince) this.lostSince = this.now();
    // كود خاطئ عند أول دخول: لا داعي للانتظار الطويل
    const hopeless = !this.lastState && ['room-not-found', 'no-webrtc', 'no-peerjs', 'browser-incompatible'].includes(reason) && this.retry >= 1;
    if (hopeless || this.now() - this.lostSince > GIVE_UP_MS) {
      this.setStatus('failed', reason);
      return;
    }
    this.setStatus(this.lastState ? 'reconnecting' : 'connecting', reason);
    const wait = RETRY_STEPS[Math.min(this.retry++, RETRY_STEPS.length - 1)];
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.start(), wait);
  }

  // عند عودة التطبيق للواجهة (فتح الجوال): نتحقق فورًا بدل انتظار دورة النبضة
  wake() {
    if (this.closedByUser) return;
    if (this.status === 'online' && this.conn) {
      if (this.now() - this.lastHeard > 6000) {
        const c = this.conn; this.conn = null;
        try { c.close(); } catch {}
        this._stopHeartbeat();
        this._lost('timeout');
      } else { try { this.conn.send({ t: 'ping', c: this.now() }); } catch {} }
    } else if (!this.starting && ['reconnecting', 'connecting', 'failed'].includes(this.status) && !this.conn) this.retryNow();
  }

  retryNow() {
    this.lostSince = null; this.retry = 0;
    clearTimeout(this.retryTimer);
    this.start();
  }

  _startHeartbeat() {
    this._stopHeartbeat();
    this.lastHeard = this.now();
    this.hb = setInterval(() => {
      if (!this.conn) return;
      // اتصال صامت لأكثر من 12 ثانية = مقطوع (مهم على الجوالات)
      if (this.now() - this.lastHeard > 12000) {
        const c = this.conn; this.conn = null;
        try { c.close(); } catch {}
        this._stopHeartbeat();
        this._lost('timeout');
        return;
      }
      try { this.conn.send({ t: 'ping', c: this.now() }); } catch {}
    }, 4000);
  }
  _stopHeartbeat() { if (this.hb) clearInterval(this.hb); this.hb = null; }

  _save() { this.store.set(this.key, { token: this.token, seq: this.seq, cid: this.cid }); }

  forget() { this.store.remove(this.key); }

  _send(msg, force = false) {
    if (!this.conn || (this.status !== 'online' && !force)) {
      this.emit('error', 'لا يوجد اتصال حاليًا — انتظر إعادة الاتصال');
      return Promise.resolve({ ok: false, error: 'offline' });
    }
    msg.seq = ++this.seq;
    this._save();
    return new Promise(res => {
      this.pending.set(msg.seq, res);
      setTimeout(() => { if (this.pending.delete(msg.seq)) res({ ok: false, error: 'timeout' }); }, 10000);
      try { this.conn.send(msg); } catch { this.pending.delete(msg.seq); res({ ok: false, error: 'send' }); }
    });
  }

  act(a) { return this._send({ t: 'act', a }); }
  setReady(value) { return this._send({ t: 'ready', value }); }
  setProfile(p) { this.profile = p; return this._send({ t: 'profile', name: p.name, emoji: p.emoji }); }
  hostCmd(cmd, extra = {}) { return this._send({ t: 'host', cmd, ...extra }); }

  async leave() {
    // نعلن المغادرة أولًا حتى لا تُفسَّر كانقطاع يستدعي إعادة الاتصال
    const conn = this.conn;
    this.closedByUser = true;
    if (conn) {
      try { await Promise.race([this._send({ t: 'leave' }, true), new Promise(r => setTimeout(r, 1500))]); } catch {}
    }
    this.close();
    this.forget();
  }

  close() {
    this.closedByUser = true;
    clearTimeout(this.retryTimer);
    this._stopHeartbeat();
    if (this.conn) { try { this.conn.close(); } catch {} }
    this.conn = null;
  }

  serverNow() { return this.now() + this.clockOffset; }
}

// محرك "هتلر السري" — رئيس ومستشار، تصويت، تشريع سري، صلاحيات تنفيذية
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, nextAliveIdx } from './common.js';

export const meta = { id: 'secret', minPlayers: 5, maxPlayers: 10, defaultOptions: {} };
const FASC = { 5: 1, 6: 1, 7: 2, 8: 2, 9: 3, 10: 3 };
export function powersFor(n) {
  if (n <= 6) return [null, null, 'peek', 'kill', 'kill', null];
  if (n <= 8) return [null, 'investigate', 'special', 'kill', 'kill', null];
  return ['investigate', 'investigate', 'special', 'kill', 'kill', null];
}

export function setup(players, options, rng) {
  const n = players.length;
  const roles = ['hitler'];
  for (let k = 0; k < FASC[n]; k++) roles.push('fascist');
  while (roles.length < n) roles.push('liberal');
  const dealt = rng.shuffle(roles);
  const deck = rng.shuffle([...Array(6).fill('L'), ...Array(11).fill('F')]);
  return {
    game: 'secret', phase: 'reveal',
    players: players.map((p, j) => ({ id: p.id, role: dealt[j], alive: true, ready: false, vote: null, investigated: false })),
    deck, discard: [], lib: 0, fas: 0, tracker: 0,
    president: rng.int(n), rotation: null, chancellor: null, lastGov: { p: null, c: null },
    hand: null, vetoAsked: false, peek: null, investigation: null, lastVote: null, lastPolicy: null, winner: null, reason: null,
    fx: [], fxSeq: 0,
  };
}

const alive = s => s.players.filter(p => p.alive);
const party = r => (r === 'liberal' ? 'liberal' : 'fascist');

function eligibleChancellor(s, j) {
  const p = s.players[j];
  if (!p.alive || j === s.president) return false;
  if (j === s.lastGov.c) return false;
  if (j === s.lastGov.p && alive(s).length > 5) return false;
  return true;
}

function draw(s, n, rng) {
  if (s.deck.length < n) { s.deck = rng.shuffle(s.deck.concat(s.discard)); s.discard = []; }
  return s.deck.splice(0, n);
}

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  if (!me.alive && a.type !== 'ready') return err('خرجت من اللعبة');
  const isPres = i === s.president;
  switch (a.type) {
    case 'ready':
      if (s.phase !== 'reveal') return err('ليست مرحلة الأدوار');
      me.ready = true;
      if (s.players.every(p => p.ready)) { s.phase = 'nominate'; pushFx(s, { kind: 'phase' }); }
      return ok();
    case 'nominate': {
      if (s.phase !== 'nominate' || !isPres) return err('الرئيس فقط يرشح المستشار');
      const t = idxOf(s, a.target);
      if (t < 0 || !eligibleChancellor(s, t)) return err('هذا اللاعب غير مؤهل');
      s.chancellor = t;
      s.phase = 'vote';
      s.players.forEach(p => { p.vote = null; });
      pushFx(s, { kind: 'nominated' });
      return ok();
    }
    case 'vote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (me.vote) return err('صوّتّ بالفعل');
      if (a.value !== 'ja' && a.value !== 'nein') return err('تصويت غير صالح');
      me.vote = a.value;
      pushFx(s, { kind: 'vote' });
      if (alive(s).every(p => p.vote)) resolveVote(s, ctx);
      return ok();
    }
    case 'discard': {
      if (s.phase !== 'presLeg' || !isPres) return err('ليس دورك');
      const k = a.index;
      if (!Number.isInteger(k) || k < 0 || k >= s.hand.length) return err('اختيار غير صالح');
      s.discard.push(s.hand.splice(k, 1)[0]);
      s.phase = 'chanLeg';
      s.vetoAsked = false;
      pushFx(s, { kind: 'pass-policy' });
      return ok();
    }
    case 'enact': {
      if (s.phase !== 'chanLeg' || i !== s.chancellor) return err('ليس دورك');
      const k = a.index;
      if (!Number.isInteger(k) || k < 0 || k >= s.hand.length) return err('اختيار غير صالح');
      const pol = s.hand.splice(k, 1)[0];
      s.discard.push(...s.hand); s.hand = null;
      return enact(s, pol, true, ctx);
    }
    case 'veto': {
      if (s.phase !== 'chanLeg' || i !== s.chancellor) return err('ليس دورك');
      if (s.fas < 5) return err('حق النقض يتاح بعد ٥ قوانين فاشية');
      if (s.vetoAsked) return err('طلبت النقض بالفعل');
      s.vetoAsked = true; s.phase = 'vetoAsk';
      pushFx(s, { kind: 'veto' });
      return ok();
    }
    case 'vetoAnswer': {
      if (s.phase !== 'vetoAsk' || !isPres) return err('ليس دورك');
      if (a.accept) {
        s.discard.push(...s.hand); s.hand = null;
        pushFx(s, { kind: 'vetoed' });
        return failedGovernment(s, ctx);
      }
      s.phase = 'chanLeg';
      return ok();
    }
    case 'peekDone':
      if (s.phase !== 'power' || s.power !== 'peek' || !isPres) return err('ليس دورك');
      s.peek = null;
      return nextPresident(s);
    case 'investigate': {
      if (s.phase !== 'power' || s.power !== 'investigate' || !isPres) return err('ليس دورك');
      const t = idxOf(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive || s.players[t].investigated) return err('اختيار غير صالح');
      s.players[t].investigated = true;
      s.investigation = { by: pid, target: s.players[t].id, party: party(s.players[t].role) };
      pushFx(s, { kind: 'investigated', to: [pid] });
      s.phase = 'invResult';
      return ok();
    }
    case 'invDone':
      if (s.phase !== 'invResult' || !isPres) return err('ليس دورك');
      return nextPresident(s);
    case 'special': {
      if (s.phase !== 'power' || s.power !== 'special' || !isPres) return err('ليس دورك');
      const t = idxOf(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive) return err('اختيار غير صالح');
      s.rotation = s.president;
      setPresident(s, t);
      return ok();
    }
    case 'kill': {
      if (s.phase !== 'power' || s.power !== 'kill' || !isPres) return err('ليس دورك');
      const t = idxOf(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive) return err('اختيار غير صالح');
      s.players[t].alive = false;
      s.lastKill = s.players[t].id;
      pushFx(s, { kind: 'kill' });
      if (s.players[t].role === 'hitler') return end(s, 'liberal', 'أُعدم هتلر');
      return nextPresident(s);
    }
    default: return err('إجراء غير معروف');
  }
}

function resolveVote(s, ctx) {
  const ja = alive(s).filter(p => p.vote === 'ja').length;
  const pass = ja > alive(s).length / 2;
  s.lastVote = { president: s.players[s.president].id, chancellor: s.players[s.chancellor].id, votes: alive(s).map(p => ({ id: p.id, v: p.vote })), pass };
  pushFx(s, { kind: pass ? 'elected' : 'failed' });
  if (!pass) { s.chancellor = null; return failedGovernment(s, ctx); }
  s.lastGov = { p: s.president, c: s.chancellor };
  s.tracker = 0;
  if (s.fas >= 3 && s.players[s.chancellor].role === 'hitler') return end(s, 'fascist', 'انتُخب هتلر مستشارًا');
  s.hand = draw(s, 3, ctx.rng);
  s.phase = 'presLeg';
  return ok();
}

function failedGovernment(s, ctx) {
  s.tracker++;
  if (s.tracker >= 3) {
    const [pol] = draw(s, 1, ctx.rng);
    s.tracker = 0;
    s.lastGov = { p: null, c: null };
    pushFx(s, { kind: 'chaos' });
    return enact(s, pol, false, ctx);
  }
  return nextPresident(s);
}

function enact(s, pol, powers, ctx) {
  s.lastPolicy = pol;
  if (pol === 'L') s.lib++; else s.fas++;
  pushFx(s, { kind: pol === 'L' ? 'policy-l' : 'policy-f' });
  if (s.lib >= 5) return end(s, 'liberal', 'خمسة قوانين ليبرالية');
  if (s.fas >= 6) return end(s, 'fascist', 'ستة قوانين فاشية');
  if (s.deck.length < 3) { s.deck = ctx.rng.shuffle(s.deck.concat(s.discard)); s.discard = []; }
  const power = pol === 'F' && powers ? powersFor(s.players.length)[s.fas - 1] : null;
  if (power) {
    s.power = power; s.phase = 'power';
    if (power === 'peek') s.peek = s.deck.slice(0, 3);
    pushFx(s, { kind: 'power' });
    return ok();
  }
  return nextPresident(s);
}

function setPresident(s, j) {
  s.president = j; s.chancellor = null; s.power = null; s.phase = 'nominate';
  // إن لم يوجد مستشار مؤهل نتجاوز قيود المدة
  if (!s.players.some((_, k) => eligibleChancellor(s, k))) s.lastGov = { p: null, c: null };
}

function nextPresident(s) {
  const base = s.rotation != null ? s.rotation : s.president;
  s.rotation = null;
  setPresident(s, nextAliveIdx(s.players, base));
  return ok();
}

function end(s, w, reason) { s.phase = 'over'; s.winner = w; s.reason = reason; pushFx(s, { kind: 'game-over' }); return ok(); }

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  let knows = null;
  if (me && (me.role === 'fascist' || (me.role === 'hitler' && s.players.length <= 6))) {
    knows = s.players.filter(p => p.id !== pid && p.role !== 'liberal').map(p => ({ id: p.id, role: p.role }));
  }
  return {
    game: 'secret', phase: s.phase, lib: s.lib, fas: s.fas, tracker: s.tracker, deck: s.deck.length,
    powers: powersFor(s.players.length), power: s.power || null,
    president: s.players[s.president].id, chancellor: s.chancellor != null ? s.players[s.chancellor].id : null,
    eligible: s.phase === 'nominate' ? s.players.map((p, j) => (eligibleChancellor(s, j) ? p.id : null)).filter(Boolean) : [],
    players: s.players.map(p => ({ id: p.id, alive: p.alive, investigated: p.investigated, ready: s.phase === 'reveal' ? p.ready : undefined, voted: s.phase === 'vote' ? !!p.vote : undefined, role: over ? p.role : null })),
    lastVote: s.lastVote, lastPolicy: s.lastPolicy, lastKill: s.lastKill || null, winner: s.winner, reason: s.reason,
    me: me ? {
      role: me.role, knows, ready: me.ready, vote: me.vote, alive: me.alive,
      hand: (s.phase === 'presLeg' && i === s.president) || ((s.phase === 'chanLeg' || s.phase === 'vetoAsk') && i === s.chancellor) ? s.hand.slice() : null,
      peek: s.phase === 'power' && s.power === 'peek' && i === s.president ? s.peek.slice() : null,
      investigation: s.phase === 'invResult' && i === s.president ? s.investigation : null,
      canVeto: s.phase === 'chanLeg' && i === s.chancellor && s.fas >= 5 && !s.vetoAsked,
    } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winnerTeam: s.winner, winners: s.players.filter(p => party(p.role) === s.winner).map(p => p.id) }; }

// محرك مونوبولي — لوحة أصلية الأسماء بقواعد الاقتصاد الكلاسيكية
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, nextAliveIdx } from './common.js';

export const meta = { id: 'monopoly', minPlayers: 2, maxPlayers: 8, defaultOptions: { auctions: true, maxRounds: 0 } };
export const normalizeOptions = (o = {}) => ({ auctions: typeof o.auctions === 'boolean' ? o.auctions : true, maxRounds: [0, 15, 25, 40].includes(o.maxRounds) ? o.maxRounds : 0 });
export const optionSchema = () => [
  { key: 'auctions', type: 'switch', label: 'مزاد عند رفض الشراء' },
  { key: 'maxRounds', type: 'select', label: 'حد الجولات (الأغنى يفوز)', options: [[0, 'بلا حد — حتى إفلاس الجميع'], [15, '١٥ جولة'], [25, '٢٥ جولة'], [40, '٤٠ جولة']] },
];

const S = (name, group, price, house, rent) => ({ type: 'street', name, group, price, house, rent });
const R = name => ({ type: 'rail', name, price: 200 });
const U = name => ({ type: 'util', name, price: 150 });
export const BOARD = [
  { type: 'go', name: 'انطلاق' }, S('حي الرمال', 'brown', 60, 50, [2, 10, 30, 90, 160, 250]), { type: 'chest', name: 'صندوق المجتمع' }, S('حي النخيل', 'brown', 60, 50, [4, 20, 60, 180, 320, 450]), { type: 'tax', name: 'ضريبة الدخل', amount: 200 },
  R('محطة الشمال'), S('السوق القديم', 'sky', 100, 50, [6, 30, 90, 270, 400, 550]), { type: 'chance', name: 'فرصة' }, S('شارع الميناء', 'sky', 100, 50, [6, 30, 90, 270, 400, 550]), S('شارع البحر', 'sky', 120, 50, [8, 40, 100, 300, 450, 600]),
  { type: 'jail', name: 'السجن / زيارة' }, S('حي الورود', 'pink', 140, 100, [10, 50, 150, 450, 625, 750]), U('شركة الكهرباء'), S('حي الياسمين', 'pink', 140, 100, [10, 50, 150, 450, 625, 750]), S('حي الزهور', 'pink', 160, 100, [12, 60, 180, 500, 700, 900]),
  R('محطة الشرق'), S('حي الواحة', 'orange', 180, 100, [14, 70, 200, 550, 750, 950]), { type: 'chest', name: 'صندوق المجتمع' }, S('حي القمر', 'orange', 180, 100, [14, 70, 200, 550, 750, 950]), S('حي الشمس', 'orange', 200, 100, [16, 80, 220, 600, 800, 1000]),
  { type: 'parking', name: 'موقف مجاني' }, S('الكورنيش', 'red', 220, 150, [18, 90, 250, 700, 875, 1050]), { type: 'chance', name: 'فرصة' }, S('المرسى', 'red', 220, 150, [18, 90, 250, 700, 875, 1050]), S('الجزيرة', 'red', 240, 150, [20, 100, 300, 750, 925, 1100]),
  R('محطة الجنوب'), S('برج الصقر', 'yellow', 260, 150, [22, 110, 330, 800, 975, 1150]), S('برج الفنار', 'yellow', 260, 150, [22, 110, 330, 800, 975, 1150]), U('شركة المياه'), S('برج النجمة', 'yellow', 280, 150, [24, 120, 360, 850, 1025, 1200]),
  { type: 'gotojail', name: 'اذهب للسجن' }, S('حي اللؤلؤ', 'green', 300, 200, [26, 130, 390, 900, 1100, 1275]), S('حي المرجان', 'green', 300, 200, [26, 130, 390, 900, 1100, 1275]), { type: 'chest', name: 'صندوق المجتمع' }, S('حي الماس', 'green', 320, 200, [28, 150, 450, 1000, 1200, 1400]),
  R('محطة الغرب'), { type: 'chance', name: 'فرصة' }, S('قصر البحيرة', 'navy', 350, 200, [35, 175, 500, 1100, 1300, 1500]), { type: 'tax', name: 'ضريبة الرفاهية', amount: 100 }, S('قصر الواحة الذهبية', 'navy', 400, 200, [50, 200, 600, 1400, 1700, 2000]),
];
export const GROUPS = {};
BOARD.forEach((b, k) => { if (b.type === 'street') (GROUPS[b.group] ||= []).push(k); });
const RAILS = [5, 15, 25, 35], UTILS = [12, 28];
const ownable = k => ['street', 'rail', 'util'].includes(BOARD[k].type);

export const CHANCE = [
  { t: 'تقدم إلى الانطلاق واستلم ٢٠٠', moveTo: 0 }, { t: 'تقدم إلى الجزيرة', moveTo: 24 }, { t: 'تقدم إلى حي الورود', moveTo: 11 },
  { t: 'تقدم لأقرب شركة خدمات؛ إن كانت مملوكة ادفع ١٠ أضعاف رمية جديدة', nearest: 'util' },
  { t: 'تقدم لأقرب محطة وادفع ضعف الإيجار إن كانت مملوكة', nearest: 'rail' }, { t: 'تقدم لأقرب محطة وادفع ضعف الإيجار إن كانت مملوكة', nearest: 'rail' },
  { t: 'البنك يصرف لك أرباحًا ٥٠', cash: 50 }, { t: 'بطاقة الخروج من السجن مجانًا', jailCard: true }, { t: 'ارجع ٣ خانات', back: 3 },
  { t: 'اذهب إلى السجن مباشرة', jail: true }, { t: 'صيانة عامة: ٢٥ لكل بيت و١٠٠ لكل فندق', repairs: [25, 100] }, { t: 'مخالفة سرعة: ادفع ١٥', cash: -15 },
  { t: 'تقدم إلى محطة الشمال', moveTo: 5 }, { t: 'تقدم إلى قصر الواحة الذهبية', moveTo: 39 }, { t: 'انتُخبت رئيسًا للمجلس: ادفع ٥٠ لكل لاعب', each: -50 },
  { t: 'استحق قرض البناء: استلم ١٥٠', cash: 150 },
];
export const CHEST = [
  { t: 'تقدم إلى الانطلاق واستلم ٢٠٠', moveTo: 0 }, { t: 'خطأ بنكي لصالحك: استلم ٢٠٠', cash: 200 }, { t: 'أتعاب الطبيب: ادفع ٥٠', cash: -50 },
  { t: 'بعت أسهمًا: استلم ٥٠', cash: 50 }, { t: 'بطاقة الخروج من السجن مجانًا', jailCard: true }, { t: 'اذهب إلى السجن مباشرة', jail: true },
  { t: 'صندوق العطلة: استلم ١٠٠', cash: 100 }, { t: 'استرداد ضريبة: استلم ٢٠', cash: 20 }, { t: 'يوم ميلادك: استلم ١٠ من كل لاعب', each: 10 },
  { t: 'تأمين على الحياة: استلم ١٠٠', cash: 100 }, { t: 'رسوم المستشفى: ادفع ١٠٠', cash: -100 }, { t: 'رسوم المدرسة: ادفع ٥٠', cash: -50 },
  { t: 'أتعاب استشارة: استلم ٢٥', cash: 25 }, { t: 'إصلاح الشوارع: ٤٠ لكل بيت و١١٥ لكل فندق', repairs: [40, 115] }, { t: 'جائزة مسابقة: استلم ١٠', cash: 10 },
  { t: 'ورثت: استلم ١٠٠', cash: 100 },
];

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const props = {};
  BOARD.forEach((b, k) => { if (ownable(k)) props[k] = { owner: null, houses: 0, mortgaged: false }; });
  return {
    game: 'monopoly', o, phase: 'roll',
    players: players.map(p => ({ id: p.id, cash: 1500, pos: 0, jail: false, jailTurns: 0, jailCards: 0, bankrupt: false })),
    props, housesLeft: 32, hotelsLeft: 12,
    chance: rng.shuffle(CHANCE.map((_, k) => k)), chest: rng.shuffle(CHEST.map((_, k) => k)),
    turn: rng.int(players.length), doubles: 0, dice: null, rolledDouble: false, round: 1, startTurn: null,
    debt: null, auction: null, trade: null, lastCard: null, log: [], winner: null, fx: [], fxSeq: 0,
  };
}

const P = (s, k) => s.props[k];
const ownerIdx = (s, k) => (P(s, k).owner == null ? -1 : idxOf(s, P(s, k).owner));
const groupOwned = (s, g, pid) => GROUPS[g].every(k => P(s, k).owner === pid);
function log(s, t) { s.log.push(t); if (s.log.length > 14) s.log.shift(); }
const active = s => s.players.filter(p => !p.bankrupt);

export function rentOf(s, k, diceTotal, mult = 1) {
  const b = BOARD[k], pr = P(s, k);
  if (pr.owner == null || pr.mortgaged) return 0;
  if (b.type === 'street') {
    if (pr.houses > 0) return b.rent[pr.houses];
    return b.rent[0] * (groupOwned(s, b.group, pr.owner) ? 2 : 1);
  }
  if (b.type === 'rail') {
    const n = RAILS.filter(r => P(s, r).owner === pr.owner).length;
    return 25 * 2 ** (n - 1) * mult;
  }
  const n = UTILS.filter(u => P(s, u).owner === pr.owner).length;
  return diceTotal * (mult === 10 ? 10 : n === 2 ? 10 : 4);
}

export function netWorth(s, j) {
  const p = s.players[j];
  let w = p.cash;
  for (const [k, pr] of Object.entries(s.props)) if (pr.owner === p.id) {
    const b = BOARD[k];
    w += pr.mortgaged ? b.price / 2 : b.price;
    if (b.type === 'street') w += pr.houses * b.house;
  }
  return w;
}

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  if (me.bankrupt) return err('أفلست وخرجت من اللعبة');
  const myTurn = i === s.turn;

  // ---- الصفقات: متاحة لأي لاعب حين لا توجد صفقة معلقة ----
  if (a.type === 'proposeTrade') return proposeTrade(s, i, a);
  if (a.type === 'answerTrade') {
    const t = s.trade;
    if (!t || t.to !== pid) return err('لا توجد صفقة موجهة لك');
    if (!a.accept) { s.trade = null; log(s, 'رُفضت صفقة'); pushFx(s, { kind: 'trade-no' }); return ok(); }
    return execTrade(s);
  }
  if (a.type === 'cancelTrade') {
    if (!s.trade || s.trade.from !== pid) return err('لا توجد صفقة لك');
    s.trade = null; return ok();
  }

  // ---- المزاد ----
  if (s.phase === 'auction') {
    const au = s.auction;
    if (s.players[au.order[au.at]].id !== pid) return err('ليس دورك في المزاد');
    if (a.type === 'bid') {
      if (!Number.isInteger(a.amount) || a.amount <= au.high || a.amount > me.cash) return err('مزايدة غير صالحة');
      if (au.bidder === i) return err('أنت صاحب أعلى مزايدة');
      au.high = a.amount; au.bidder = i;
      pushFx(s, { kind: 'bid' });
    } else if (a.type === 'passBid') {
      au.order.splice(au.at, 1); au.at--;
    } else return err('مزايدة أو انسحاب فقط');
    if (au.order.length === 0 || (au.order.length === 1 && au.bidder === au.order[0])) return closeAuction(s);
    au.at = (au.at + 1) % au.order.length;
    return ok();
  }

  // ---- الديون: البيع والرهن ثم السداد أو الإفلاس ----
  if (s.phase === 'debt') {
    if (s.debt.from !== i) return err('بانتظار تسوية دين لاعب آخر');
    if (a.type === 'mortgage' || a.type === 'sellHouse') return manage(s, i, a);
    if (a.type === 'payDebt') {
      if (me.cash < s.debt.amount) return err('الرصيد لا يكفي — ارهن أو بع');
      const d = s.debt; s.debt = null;
      transfer(s, i, d.to, d.amount);
      s.phase = d.resume;
      if (d.moveAfter != null) return move(s, i, d.moveAfter, ctx);
      return ok();
    }
    if (a.type === 'bankrupt') return bankrupt(s, i, s.debt.to, ctx);
    return err('سدّد الدين أو أعلن الإفلاس');
  }

  if (['build', 'sellHouse', 'mortgage', 'unmortgage'].includes(a.type)) {
    if (!myTurn || !['roll', 'end'].includes(s.phase)) return err('الإدارة متاحة في دورك فقط');
    return manage(s, i, a);
  }

  if (!myTurn) return err('ليس دورك');
  switch (a.type) {
    case 'payJail': {
      if (s.phase !== 'roll' || !me.jail) return err('لست في السجن');
      if (me.cash < 50) return err('لا تملك ٥٠');
      me.cash -= 50; me.jail = false; me.jailTurns = 0; log(s, 'دفع كفالة ٥٠');
      return ok();
    }
    case 'useCard': {
      if (s.phase !== 'roll' || !me.jail || me.jailCards < 1) return err('لا يمكن');
      me.jailCards--; me.jail = false; me.jailTurns = 0; log(s, 'استخدم بطاقة الخروج');
      returnJailCard(s);
      return ok();
    }
    case 'roll': {
      if (s.phase !== 'roll') return err('لا يمكن الرمي الآن');
      const d1 = 1 + ctx.rng.int(6), d2 = 1 + ctx.rng.int(6);
      s.dice = [d1, d2];
      const dbl = d1 === d2;
      pushFx(s, { kind: 'dice' });
      if (me.jail) {
        if (dbl) { me.jail = false; me.jailTurns = 0; s.rolledDouble = false; log(s, 'خرج من السجن بزوج'); return move(s, i, d1 + d2, ctx); }
        me.jailTurns++;
        if (me.jailTurns >= 3) {
          me.jail = false; me.jailTurns = 0; s.rolledDouble = false;
          log(s, 'دفع ٥٠ بعد ثلاث محاولات');
          return charge(s, i, -1, 50, 'move:' + (d1 + d2), ctx);
        }
        s.phase = 'end'; s.rolledDouble = false;
        return ok();
      }
      if (dbl) { s.doubles++; if (s.doubles >= 3) { s.doubles = 0; s.rolledDouble = false; return toJail(s, i); } }
      s.rolledDouble = dbl;
      return move(s, i, d1 + d2, ctx);
    }
    case 'buy': {
      if (s.phase !== 'buy') return err('لا يوجد ما تشتريه');
      const k = me.pos, b = BOARD[k];
      if (me.cash < b.price) return err('الرصيد لا يكفي');
      me.cash -= b.price; P(s, k).owner = pid;
      log(s, 'اشترى ' + b.name); pushFx(s, { kind: 'buy' });
      s.phase = 'end';
      return ok();
    }
    case 'decline': {
      if (s.phase !== 'buy') return err('لا يوجد ما ترفضه');
      if (!s.o.auctions) { s.phase = 'end'; return ok(); }
      const order = [];
      for (let k = 0; k < s.players.length; k++) { const j = (i + k) % s.players.length; if (!s.players[j].bankrupt) order.push(j); }
      s.auction = { sq: me.pos, high: 0, bidder: null, order, at: 0 };
      s.phase = 'auction';
      pushFx(s, { kind: 'phase' });
      return ok();
    }
    case 'endTurn': {
      if (s.phase !== 'end') return err('أكمل دورك أولًا');
      if (s.rolledDouble && !me.jail) { s.phase = 'roll'; s.rolledDouble = false; return ok(); }
      return nextTurn(s);
    }
    default: return err('إجراء غير معروف');
  }
}

function nextTurn(s) {
  s.doubles = 0; s.rolledDouble = false; s.dice = null;
  const prev = s.turn;
  s.turn = nextAliveIdx(s.players, s.turn, p => !p.bankrupt);
  if (s.turn <= prev) s.round++;
  if (s.o.maxRounds && s.round > s.o.maxRounds) return finishByWorth(s);
  s.phase = 'roll';
  return ok();
}

function toJail(s, i) {
  const p = s.players[i];
  p.pos = 10; p.jail = true; p.jailTurns = 0;
  s.rolledDouble = false;
  log(s, 'ذهب للسجن'); pushFx(s, { kind: 'jail' });
  s.phase = 'end';
  return ok();
}

function move(s, i, steps, ctx) {
  const p = s.players[i];
  const np = (p.pos + steps) % 40;
  if (np < p.pos) { p.cash += 200; log(s, 'مرّ بالانطلاق +٢٠٠'); pushFx(s, { kind: 'go' }); }
  p.pos = np;
  return land(s, i, ctx);
}

function moveTo(s, i, k, ctx, mult = 1) {
  const p = s.players[i];
  if (k < p.pos) { p.cash += 200; pushFx(s, { kind: 'go' }); }
  p.pos = k;
  return land(s, i, ctx, mult);
}

function land(s, i, ctx, mult = 1) {
  const p = s.players[i], k = p.pos, b = BOARD[k];
  s.phase = 'end';
  if (ownable(k)) {
    const pr = P(s, k);
    if (pr.owner == null) { s.phase = 'buy'; return ok(); }
    if (pr.owner === p.id || pr.mortgaged) return ok();
    const total = s.dice ? s.dice[0] + s.dice[1] : 7;
    let rent;
    if (mult === 10) { const d = 2 + ctx.rng.int(6) + ctx.rng.int(6); rent = d * 10; }
    else rent = rentOf(s, k, total, mult);
    log(s, `إيجار ${rent} لـ${b.name}`); pushFx(s, { kind: 'rent' });
    return charge(s, i, ownerIdx(s, k), rent, 'end', ctx);
  }
  if (b.type === 'tax') return charge(s, i, -1, b.amount, 'end', ctx);
  if (b.type === 'gotojail') return toJail(s, i);
  if (b.type === 'chance' || b.type === 'chest') return drawCard(s, i, b.type, ctx);
  return ok();
}

function drawCard(s, i, kind, ctx) {
  const pile = kind === 'chance' ? s.chance : s.chest;
  const list = kind === 'chance' ? CHANCE : CHEST;
  const ci = pile.shift();
  const c = list[ci];
  if (!c.jailCard) pile.push(ci); // بطاقة الخروج من السجن تبقى مع اللاعب حتى يستخدمها
  s.lastCard = { kind, text: c.t, who: s.players[i].id };
  pushFx(s, { kind: 'card' });
  const p = s.players[i];
  if (c.moveTo != null) return moveTo(s, i, c.moveTo, ctx);
  if (c.nearest) {
    const list2 = c.nearest === 'rail' ? RAILS : UTILS;
    const k = list2.find(x => x > p.pos) ?? list2[0];
    return moveTo(s, i, k, ctx, c.nearest === 'rail' ? 2 : 10);
  }
  if (c.back) { p.pos = (p.pos + 40 - c.back) % 40; return land(s, i, ctx); }
  if (c.jail) return toJail(s, i);
  if (c.jailCard) { p.jailCards++; return ok(); }
  if (c.cash > 0) { p.cash += c.cash; return ok(); }
  if (c.cash < 0) return charge(s, i, -1, -c.cash, 'end', ctx);
  if (c.repairs) {
    let total = 0;
    for (const pr of Object.values(s.props)) if (pr.owner === p.id) total += pr.houses === 5 ? c.repairs[1] : pr.houses * c.repairs[0];
    return total ? charge(s, i, -1, total, 'end', ctx) : ok();
  }
  if (c.each) {
    const others = s.players.map((x, j) => j).filter(j => j !== i && !s.players[j].bankrupt);
    if (c.each > 0) { for (const j of others) { const amt = Math.min(c.each, s.players[j].cash); s.players[j].cash -= amt; p.cash += amt; } return ok(); }
    const need = -c.each * others.length;
    if (p.cash >= need) { for (const j of others) { p.cash -= -c.each; s.players[j].cash += -c.each; } return ok(); }
    // لا يكفي الرصيد: نحوّل المبلغ كدين للبنك ثم يُوزّع (تبسيط)
    return charge(s, i, -1, need, 'end', ctx);
  }
  return ok();
}

// دفع مبلغ؛ إن لم يكفِ الرصيد ينتقل اللاعب لمرحلة الدين
function charge(s, i, to, amount, resume, ctx) {
  const p = s.players[i];
  if (p.cash >= amount) {
    transfer(s, i, to, amount);
    s.phase = resume.startsWith('move:') ? 'end' : resume;
    if (resume.startsWith('move:')) return move(s, i, Number(resume.slice(5)), ctx);
    return ok();
  }
  s.debt = { from: i, to, amount, resume: resume.startsWith('move:') ? 'end' : resume, moveAfter: resume.startsWith('move:') ? Number(resume.slice(5)) : null };
  s.phase = 'debt';
  pushFx(s, { kind: 'debt' });
  return ok();
}

function transfer(s, from, to, amount) {
  s.players[from].cash -= amount;
  if (to >= 0) s.players[to].cash += amount;
}

// فحص صلاحية إجراءات الإدارة دون تعديل الحالة — يستخدمه التنفيذ والعرض معًا
function manageErr(s, i, a) {
  const p = s.players[i];
  const k = a.sq;
  if (!Number.isInteger(k) || !ownable(k) || P(s, k).owner !== p.id) return 'ليست ملكك';
  const b = BOARD[k], pr = P(s, k);
  if (a.type === 'build') {
    if (b.type !== 'street') return 'لا يمكن البناء هنا';
    if (!groupOwned(s, b.group, p.id)) return 'تحتاج كل المجموعة اللونية';
    if (GROUPS[b.group].some(x => P(s, x).mortgaged)) return 'فك رهن المجموعة أولًا';
    if (pr.houses >= 5) return 'عليها فندق';
    const min = Math.min(...GROUPS[b.group].map(x => P(s, x).houses));
    if (pr.houses > min) return 'ابنِ بالتساوي على المجموعة';
    if (p.cash < b.house) return 'الرصيد لا يكفي';
    if (pr.houses === 4 && s.hotelsLeft < 1) return 'نفدت الفنادق';
    if (pr.houses < 4 && s.housesLeft < 1) return 'نفدت البيوت';
    return null;
  }
  if (a.type === 'sellHouse') {
    if (b.type !== 'street' || pr.houses === 0) return 'لا توجد مبانٍ';
    const max = Math.max(...GROUPS[b.group].map(x => P(s, x).houses));
    if (pr.houses < max) return 'بِع بالتساوي';
    if (pr.houses === 5 && s.housesLeft < 4) return 'لا توجد بيوت كافية في البنك لتفكيك الفندق';
    return null;
  }
  if (a.type === 'mortgage') {
    if (pr.mortgaged) return 'مرهونة بالفعل';
    if (b.type === 'street' && GROUPS[b.group].some(x => P(s, x).houses > 0)) return 'بِع مباني المجموعة أولًا';
    return null;
  }
  if (a.type === 'unmortgage') {
    if (!pr.mortgaged) return 'غير مرهونة';
    if (p.cash < Math.ceil(b.price / 2 * 1.1)) return 'الرصيد لا يكفي';
    return null;
  }
  return 'إجراء غير معروف';
}

function manage(s, i, a) {
  const e = manageErr(s, i, a);
  if (e) return err(e);
  const p = s.players[i], b = BOARD[a.sq], pr = P(s, a.sq);
  if (a.type === 'build') {
    if (pr.houses === 4) { s.hotelsLeft--; s.housesLeft += 4; } else s.housesLeft--;
    pr.houses++; p.cash -= b.house;
    pushFx(s, { kind: 'build' });
    return ok();
  }
  if (a.type === 'sellHouse') {
    if (pr.houses === 5) { s.housesLeft -= 4; s.hotelsLeft++; } else s.housesLeft++;
    pr.houses--; p.cash += b.house / 2;
    return ok();
  }
  if (a.type === 'mortgage') {
    pr.mortgaged = true; p.cash += b.price / 2;
    pushFx(s, { kind: 'mortgage' });
    return ok();
  }
  pr.mortgaged = false; p.cash -= Math.ceil(b.price / 2 * 1.1);
  return ok();
}

// الإجراءات المسموحة الآن لهذا اللاعب على أملاكه (للعرض فقط؛ التنفيذ يعيد الفحص)
function allowedManage(s, i) {
  if (i < 0) return {};
  const inDebt = s.phase === 'debt' && s.debt && s.debt.from === i;
  const myTurnManage = s.turn === i && ['roll', 'end'].includes(s.phase);
  if (!inDebt && !myTurnManage) return {};
  const types = inDebt ? ['sellHouse', 'mortgage'] : ['build', 'sellHouse', 'mortgage', 'unmortgage'];
  const out = {};
  for (const k of Object.keys(s.props).map(Number)) {
    if (P(s, k).owner !== s.players[i].id) continue;
    const ok2 = types.filter(t => !manageErr(s, i, { type: t, sq: k }));
    if (ok2.length) out[k] = ok2;
  }
  return out;
}

// إعادة بطاقة الخروج من السجن إلى كومتها الأصلية
function returnJailCard(s) {
  const ch = CHANCE.findIndex(c => c.jailCard), cs = CHEST.findIndex(c => c.jailCard);
  if (!s.chance.includes(ch)) s.chance.push(ch);
  else if (!s.chest.includes(cs)) s.chest.push(cs);
}

function closeAuction(s) {
  const au = s.auction;
  if (au.bidder != null) {
    const w = s.players[au.bidder];
    w.cash -= au.high; P(s, au.sq).owner = w.id;
    log(s, `فاز بالمزاد بـ${au.high}`); pushFx(s, { kind: 'buy' });
  }
  s.auction = null;
  s.phase = 'end';
  return ok();
}

function bankrupt(s, i, to, ctx) {
  const p = s.players[i];
  const cred = to >= 0 ? s.players[to] : null;
  for (const [k, pr] of Object.entries(s.props)) if (pr.owner === p.id) {
    const b = BOARD[k];
    if (pr.houses) {
      const cash = pr.houses * b.house / 2;
      if (pr.houses === 5) s.hotelsLeft++; else s.housesLeft += pr.houses;
      pr.houses = 0;
      if (cred) cred.cash += cash;
    }
    if (cred) pr.owner = cred.id;
    else { pr.owner = null; pr.mortgaged = false; }
  }
  if (cred) { cred.cash += Math.max(0, p.cash); cred.jailCards += p.jailCards; }
  else for (let k = 0; k < p.jailCards; k++) returnJailCard(s);
  p.cash = 0; p.jailCards = 0; p.bankrupt = true;
  s.debt = null;
  if (s.trade && (s.trade.from === p.id || s.trade.to === p.id)) s.trade = null;
  log(s, 'أعلن الإفلاس'); pushFx(s, { kind: 'bankrupt' });
  const left = active(s);
  if (left.length === 1) { s.phase = 'over'; s.winner = [left[0].id]; pushFx(s, { kind: 'game-over' }); return ok(); }
  if (s.turn === i) return nextTurn(s);
  s.phase = 'end';
  return ok();
}

function finishByWorth(s) {
  const ws = s.players.map((p, j) => ({ id: p.id, w: p.bankrupt ? -1 : netWorth(s, j) }));
  const best = Math.max(...ws.map(x => x.w));
  s.winner = ws.filter(x => x.w === best).map(x => x.id);
  s.phase = 'over';
  pushFx(s, { kind: 'game-over' });
  return ok();
}

function validSide(s, j, side) {
  const p = s.players[j];
  if (!side || typeof side !== 'object') return 'عرض غير صالح';
  const cash = side.cash || 0, props = side.props || [], cards = side.cards || 0;
  if (!Number.isInteger(cash) || cash < 0 || cash > p.cash) return 'المبلغ غير متاح';
  if (!Array.isArray(props) || props.some(k => !ownable(k) || P(s, k).owner !== p.id)) return 'عقار غير مملوك';
  if (props.some(k => BOARD[k].type === 'street' && GROUPS[BOARD[k].group].some(x => P(s, x).houses > 0))) return 'بِع المباني قبل تداول المجموعة';
  if (!Number.isInteger(cards) || cards < 0 || cards > p.jailCards) return 'بطاقات غير متاحة';
  return null;
}

function proposeTrade(s, i, a) {
  if (s.trade) return err('توجد صفقة معلقة');
  if (s.phase === 'auction' || s.phase === 'debt') return err('لا صفقات أثناء المزاد أو الدين');
  const j = idxOf(s, a.to);
  if (j < 0 || j === i || s.players[j].bankrupt) return err('اختر لاعبًا');
  const e1 = validSide(s, i, a.give), e2 = validSide(s, j, a.get);
  if (e1 || e2) return err(e1 || e2);
  const norm = x => ({ cash: x.cash || 0, props: [...new Set(x.props || [])], cards: x.cards || 0 });
  s.trade = { from: s.players[i].id, to: a.to, give: norm(a.give), get: norm(a.get) };
  pushFx(s, { kind: 'trade' });
  return ok();
}

function execTrade(s) {
  const t = s.trade;
  const i = idxOf(s, t.from), j = idxOf(s, t.to);
  const e1 = validSide(s, i, t.give), e2 = validSide(s, j, t.get);
  if (e1 || e2) { s.trade = null; return err('تغيّرت الأملاك — أُلغيت الصفقة'); }
  const A = s.players[i], B = s.players[j];
  A.cash += t.get.cash - t.give.cash; B.cash += t.give.cash - t.get.cash;
  t.give.props.forEach(k => { P(s, k).owner = B.id; });
  t.get.props.forEach(k => { P(s, k).owner = A.id; });
  A.jailCards += t.get.cards - t.give.cards; B.jailCards += t.give.cards - t.get.cards;
  s.trade = null;
  log(s, 'تمت صفقة'); pushFx(s, { kind: 'trade-yes' });
  return ok();
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  return {
    game: 'monopoly', phase: s.phase, turn: s.players[s.turn].id, dice: s.dice, round: s.round, maxRounds: s.o.maxRounds,
    rolledDouble: s.rolledDouble,
    players: s.players.map((p, j) => ({ id: p.id, cash: p.cash, pos: p.pos, jail: p.jail, jailTurns: p.jailTurns, jailCards: p.jailCards, bankrupt: p.bankrupt, worth: netWorth(s, j) })),
    props: s.props, housesLeft: s.housesLeft, hotelsLeft: s.hotelsLeft,
    debt: s.debt ? { from: s.players[s.debt.from].id, to: s.debt.to >= 0 ? s.players[s.debt.to].id : null, amount: s.debt.amount } : null,
    auction: s.auction ? { sq: s.auction.sq, high: s.auction.high, bidder: s.auction.bidder != null ? s.players[s.auction.bidder].id : null, at: s.players[s.auction.order[s.auction.at]]?.id, order: s.auction.order.map(j => s.players[j].id) } : null,
    trade: s.trade, lastCard: s.lastCard, log: s.log.slice(), winner: s.winner,
    me: i >= 0 ? { id: pid, can: allowedManage(s, i) } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winners: s.winner || [] }; }

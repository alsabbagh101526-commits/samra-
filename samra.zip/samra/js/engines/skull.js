// محرك لعبة الجمجمة (Skull) — منطق خالص، لا واجهة ولا شبكة ولا صوت
// القواعد: لكل لاعب 4 أقراص (3 ورود + جمجمة). من يكسب تحديين يفوز، أو آخر لاعب متبقٍ.
import { pushFx, viewFx } from './fx.js';

export const meta = { id: 'skull', minPlayers: 3, maxPlayers: 6, defaultOptions: {} };

const ROSE = 'rose', SKULL = 'skull';

export function setup(players, options, rng) {
  const s = {
    game: 'skull',
    phase: 'setup',
    round: 1,
    players: players.map(p => ({
      id: p.id, alive: true, wins: 0,
      total: { rose: 3, skull: 1 },
      stack: [],
      revealedCount: 0,
    })),
    starter: rng.int(players.length),
    turn: null,
    bid: null,
    passed: [],
    challenger: null,
    revealed: [],
    ownDone: false,
    result: null,
    lostPrivate: null,
    winner: null,
    fx: [], fxSeq: 0,
  };
  pushFx(s, { kind: 'round-start' });
  return s;
}

const idx = (s, pid) => s.players.findIndex(p => p.id === pid);
const discCount = p => p.total.rose + p.total.skull;
const handOf = p => {
  const r = p.stack.filter(d => d === ROSE).length;
  const k = p.stack.length - r;
  return { rose: p.total.rose - r, skull: p.total.skull - k };
};
const onTable = s => s.players.reduce((n, p) => n + p.stack.length, 0);
const aliveCount = s => s.players.filter(p => p.alive).length;

function nextAlive(s, from, pred = () => true) {
  const n = s.players.length;
  for (let k = 1; k <= n; k++) {
    const i = (from + k) % n;
    if (s.players[i].alive && pred(i)) return i;
  }
  return -1;
}

export function act(s, pid, a, ctx) {
  const i = idx(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  const me = s.players[i];
  if (s.phase === 'over') return err('انتهت اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');

  switch (a.type) {
    case 'place': {
      if (!me.alive) return err('خرجت من اللعبة');
      if (a.disc !== ROSE && a.disc !== SKULL) return err('قرص غير صالح');
      const h = handOf(me);
      if (h[a.disc] <= 0) return err('لا تملك هذا القرص في يدك');
      if (s.phase === 'setup') {
        if (me.stack.length > 0) return err('وضعت قرصك الأول بالفعل');
        me.stack.push(a.disc);
        pushFx(s, { kind: 'place', who: pid });
        if (s.players.every(p => !p.alive || p.stack.length > 0)) {
          s.phase = 'turn';
          s.turn = s.starter;
        }
        return ok();
      }
      if (s.phase === 'turn') {
        if (s.turn !== i) return err('ليس دورك');
        me.stack.push(a.disc);
        pushFx(s, { kind: 'place', who: pid });
        s.turn = nextAlive(s, i);
        return ok();
      }
      return err('لا يمكن وضع قرص الآن');
    }
    case 'bid': {
      const amt = a.amount;
      const max = onTable(s);
      if (!Number.isInteger(amt) || amt < 1 || amt > max) return err('رقم التحدي غير صالح');
      if (s.phase === 'turn') {
        if (s.turn !== i) return err('ليس دورك');
        s.bid = { amount: amt, by: i };
        s.passed = [];
        s.phase = 'bidding';
        pushFx(s, { kind: 'bid', who: pid, amount: amt });
        return afterBid(s, i);
      }
      if (s.phase === 'bidding') {
        if (s.turn !== i) return err('ليس دورك');
        if (amt <= s.bid.amount) return err('يجب أن ترفع الرقم');
        s.bid = { amount: amt, by: i };
        pushFx(s, { kind: 'bid', who: pid, amount: amt });
        return afterBid(s, i);
      }
      return err('لا يمكن التحدي الآن');
    }
    case 'pass': {
      if (s.phase !== 'bidding') return err('لا يمكن التمرير الآن');
      if (s.turn !== i) return err('ليس دورك');
      s.passed.push(i);
      pushFx(s, { kind: 'pass', who: pid });
      const remaining = s.players.map((p, j) => j).filter(j => s.players[j].alive && !s.passed.includes(j));
      if (remaining.length === 1) return startReveal(s, s.bid.by);
      s.turn = nextAlive(s, i, j => !s.passed.includes(j));
      return ok();
    }
    case 'revealOwn': {
      if (s.phase !== 'reveal' || s.challenger !== i) return err('ليس دورك للكشف');
      if (s.ownDone) return err('كشفت أقراصك بالفعل');
      // يكشف أقراصه من الأعلى إلى الأسفل ويتوقف عند الجمجمة
      for (let k = me.stack.length - 1; k >= 0; k--) {
        const d = me.stack[k];
        me.revealedCount++;
        s.revealed.push({ owner: pid, disc: d });
        pushFx(s, { kind: d === SKULL ? 'flip-skull' : 'flip-rose', who: pid, owner: pid });
        if (d === SKULL) return failChallenge(s, i, ctx);
        if (rosesFound(s) >= s.bid.amount) return succeed(s, i);
      }
      s.ownDone = true;
      return ok();
    }
    case 'flip': {
      if (s.phase !== 'reveal' || s.challenger !== i) return err('ليس دورك للكشف');
      if (!s.ownDone) return err('اكشف أقراصك أولًا');
      const t = idx(s, a.target);
      if (t < 0 || t === i) return err('اختيار غير صالح');
      const tp = s.players[t];
      if (tp.revealedCount >= tp.stack.length) return err('لا توجد أقراص مخفية لدى هذا اللاعب');
      const d = tp.stack[tp.stack.length - 1 - tp.revealedCount];
      tp.revealedCount++;
      s.revealed.push({ owner: tp.id, disc: d });
      pushFx(s, { kind: d === SKULL ? 'flip-skull' : 'flip-rose', who: pid, owner: tp.id });
      if (d === SKULL) return failChallenge(s, i, ctx, t);
      if (rosesFound(s) >= s.bid.amount) return succeed(s, i);
      return ok();
    }
    case 'discard': {
      if (s.phase !== 'discard' || s.challenger !== i) return err('ليس دورك');
      if (a.disc !== ROSE && a.disc !== SKULL) return err('قرص غير صالح');
      if (me.total[a.disc] <= 0) return err('لا تملك هذا النوع');
      me.total[a.disc]--;
      s.lostPrivate = { to: pid, disc: a.disc };
      return afterLoss(s, i, i);
    }
    case 'next': {
      if (s.phase !== 'roundEnd') return err('الجولة لم تنتهِ');
      const isStarter = s.players[s.starter]?.id === pid;
      if (!isStarter && !ctx.isHost) return err('ينتظر بدء الجولة من اللاعب التالي أو المضيف');
      newRound(s);
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

function afterBid(s, i) {
  if (s.bid.amount === onTable(s)) return startReveal(s, i);
  const next = nextAlive(s, i, j => !s.passed.includes(j));
  if (next === i || next < 0) return startReveal(s, i);
  s.turn = next;
  return ok();
}

function startReveal(s, ci) {
  s.phase = 'reveal';
  s.challenger = ci;
  s.turn = ci;
  s.ownDone = s.players[ci].stack.length === 0;
  pushFx(s, { kind: 'challenge', who: s.players[ci].id, amount: s.bid.amount });
  return ok();
}

const rosesFound = s => s.revealed.filter(r => r.disc === ROSE).length;

function succeed(s, ci) {
  const c = s.players[ci];
  c.wins++;
  s.result = { type: 'success', challenger: c.id, amount: s.bid.amount };
  pushFx(s, { kind: 'point', who: c.id });
  if (c.wins >= 2) return finish(s, ci);
  s.starter = ci;
  s.phase = 'roundEnd';
  return ok();
}

function failChallenge(s, ci, ctx, ownerIdx = ci) {
  const c = s.players[ci];
  s.result = { type: 'fail', challenger: c.id, skullOwner: s.players[ownerIdx].id, amount: s.bid.amount };
  if (ownerIdx === ci) {
    // جمجمته هو: يختار بنفسه القرص الذي يخسره
    s.phase = 'discard';
    s.turn = ci;
    return ok();
  }
  // جمجمة لاعب آخر: يخسر قرصًا عشوائيًا لا يعرفه غيره
  const pool = [];
  for (let k = 0; k < c.total.rose; k++) pool.push(ROSE);
  for (let k = 0; k < c.total.skull; k++) pool.push(SKULL);
  const lost = pool[ctx.rng.int(pool.length)];
  c.total[lost]--;
  s.lostPrivate = { to: c.id, disc: lost };
  return afterLoss(s, ci, ownerIdx);
}

function afterLoss(s, ci, ownerIdx) {
  const c = s.players[ci];
  pushFx(s, { kind: 'lose-disc', who: c.id });
  if (discCount(c) === 0) {
    c.alive = false;
    s.result.eliminated = c.id;
    pushFx(s, { kind: 'eliminated', who: c.id });
    if (aliveCount(s) === 1) return finish(s, s.players.findIndex(p => p.alive));
    // يبدأ صاحب الجمجمة؛ وإن كانت جمجمته هو فاللاعب الحي التالي (تحتاج تحققًا)
    s.starter = ownerIdx !== ci ? ownerIdx : nextAlive(s, ci);
  } else {
    s.starter = ci;
  }
  s.phase = 'roundEnd';
  return ok();
}

function finish(s, wi) {
  s.phase = 'over';
  s.winner = s.players[wi].id;
  s.turn = null;
  pushFx(s, { kind: 'game-over', who: s.winner });
  return ok();
}

function newRound(s) {
  s.round++;
  for (const p of s.players) { p.stack = []; p.revealedCount = 0; }
  s.phase = 'setup';
  s.turn = null;
  s.bid = null;
  s.passed = [];
  s.challenger = null;
  s.revealed = [];
  s.ownDone = false;
  s.result = null;
  s.lostPrivate = null;
  pushFx(s, { kind: 'round-start' });
}

export function view(s, pid) {
  const i = idx(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  return {
    game: 'skull',
    phase: s.phase,
    round: s.round,
    onTable: onTable(s),
    bid: s.bid ? { amount: s.bid.amount, by: s.players[s.bid.by].id } : null,
    turn: s.turn == null ? null : s.players[s.turn].id,
    starter: s.players[s.starter]?.id ?? null,
    challenger: s.challenger == null ? null : s.players[s.challenger].id,
    ownDone: s.ownDone,
    rosesFound: rosesFound(s),
    result: s.result,
    winner: s.winner,
    players: s.players.map(p => ({
      id: p.id, alive: p.alive, wins: p.wins,
      discs: discCount(p),
      stackCount: p.stack.length,
      // الأقراص المكشوفة فقط — من أعلى الكومة
      revealed: p.stack.slice(p.stack.length - p.revealedCount).reverse(),
      passed: s.passed.includes(s.players.indexOf(p)),
      // في نهاية اللعبة تُكشف المجموعات المتبقية
      ...(over ? { total: { ...p.total } } : {}),
    })),
    me: me ? {
      total: { ...me.total },
      hand: handOf(me),
      stack: me.stack.slice(),
      lost: s.lostPrivate && s.lostPrivate.to === pid ? s.lostPrivate.disc : null,
    } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) {
  return {
    winner: s.winner,
    ranking: s.players
      .map(p => ({ id: p.id, wins: p.wins, alive: p.alive, discs: discCount(p) }))
      .sort((a, b) => (b.id === s.winner) - (a.id === s.winner) || b.wins - a.wins || b.discs - a.discs),
  };
}

const ok = () => ({ ok: true });
const err = e => ({ ok: false, error: e });

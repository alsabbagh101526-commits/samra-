// محرك "شريف: جمارك نوتنغهام" — سوق، تعبئة الحقيبة، إعلان، رشوة، تفتيش، ثم حساب الثروة
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf } from './common.js';

export const meta = { id: 'shareef', minPlayers: 3, maxPlayers: 5, defaultOptions: {} };
export const GOODS = {
  apple: { name: 'تفاح', value: 2, penalty: 2, legal: true },
  cheese: { name: 'جبن', value: 3, penalty: 2, legal: true },
  bread: { name: 'خبز', value: 3, penalty: 2, legal: true },
  chicken: { name: 'دجاج', value: 4, penalty: 2, legal: true },
  pepper: { name: 'فلفل', value: 6, penalty: 4, legal: false },
  mead: { name: 'شراب العسل', value: 7, penalty: 4, legal: false },
  silk: { name: 'حرير', value: 8, penalty: 4, legal: false },
  crossbow: { name: 'قوس', value: 9, penalty: 4, legal: false },
};
const DECK = { apple: 48, cheese: 36, bread: 36, chicken: 24, pepper: 22, mead: 21, silk: 12, crossbow: 5 };
export const BONUS = { apple: [20, 10], cheese: [15, 10], bread: [15, 10], chicken: [10, 5] };
const LEGAL = ['apple', 'cheese', 'bread', 'chicken'];

export function setup(players, options, rng) {
  let deck = [];
  for (const [g, n] of Object.entries(DECK)) for (let k = 0; k < n; k++) deck.push(g);
  deck = rng.shuffle(deck);
  const ps = players.map(p => ({ id: p.id, gold: 50, hand: deck.splice(0, 6), stand: [], bag: null, declare: null, offer: 0, done: false }));
  const times = ps.length === 3 ? 3 : 2;
  const s = { game: 'shareef', phase: 'market', players: ps, deck, discard: [], sheriff: 0, turnsTotal: ps.length * times, turnNo: 1, queue: [], current: null, lastInspect: null, scores: null, fx: [], fxSeq: 0 };
  startTurn(s);
  return s;
}

function startTurn(s) {
  s.phase = 'market';
  s.players.forEach((p, j) => { p.done = j === s.sheriff; p.bag = null; p.declare = null; p.offer = 0; });
  s.lastInspect = null;
  pushFx(s, { kind: 'round-start' });
}

function drawTo(s, p, rng) {
  while (p.hand.length < 6) {
    if (!s.deck.length) { if (!s.discard.length) break; s.deck = rng.shuffle(s.discard); s.discard = []; }
    p.hand.push(s.deck.pop());
  }
}

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  const isSheriff = i === s.sheriff;
  switch (a.type) {
    case 'market': {
      if (s.phase !== 'market' || isSheriff) return err('ليس دورك في السوق');
      if (me.done) return err('أنهيت السوق');
      const ks = Array.isArray(a.discard) ? [...new Set(a.discard)] : [];
      if (ks.length > 5 || ks.some(k => !Number.isInteger(k) || k < 0 || k >= me.hand.length)) return err('اختر حتى ٥ بطاقات');
      const kept = me.hand.filter((_, k) => !ks.includes(k));
      s.discard.push(...me.hand.filter((_, k) => ks.includes(k)));
      me.hand = kept;
      drawTo(s, me, ctx.rng);
      me.done = true;
      if (s.players.every(p => p.done)) { s.phase = 'load'; s.players.forEach((p, j) => { p.done = j === s.sheriff; }); pushFx(s, { kind: 'phase' }); }
      return ok();
    }
    case 'load': {
      if (s.phase !== 'load' || isSheriff) return err('ليس دورك');
      if (me.done) return err('عبّأت حقيبتك');
      const ks = Array.isArray(a.cards) ? [...new Set(a.cards)] : [];
      if (ks.length < 1 || ks.length > 5 || ks.some(k => !Number.isInteger(k) || k < 0 || k >= me.hand.length)) return err('الحقيبة من ١ إلى ٥ بطاقات');
      if (!LEGAL.includes(a.declare)) return err('أعلن نوعًا قانونيًا واحدًا');
      me.bag = ks.map(k => me.hand[k]);
      me.hand = me.hand.filter((_, k) => !ks.includes(k));
      me.declare = { good: a.declare, count: ks.length };
      me.done = true;
      pushFx(s, { kind: 'bag' });
      if (s.players.every(p => p.done)) {
        s.phase = 'inspect';
        s.queue = s.players.map((_, j) => j).filter(j => j !== s.sheriff);
        s.current = s.queue.shift();
        pushFx(s, { kind: 'phase' });
      }
      return ok();
    }
    case 'offer': {
      if (s.phase !== 'inspect' || i !== s.current) return err('ليس دورك');
      const g = a.gold;
      if (!Number.isInteger(g) || g < 0 || g > me.gold) return err('مبلغ غير صالح');
      me.offer = g;
      pushFx(s, { kind: 'offer' });
      return ok();
    }
    case 'pass': {
      if (s.phase !== 'inspect' || !isSheriff) return err('الشريف فقط');
      const m = s.players[s.current];
      const bribe = Math.min(m.offer, m.gold);
      m.gold -= bribe; me.gold += bribe;
      m.stand.push(...m.bag);
      s.lastInspect = { merchant: m.id, inspected: false, bribe, declare: m.declare };
      pushFx(s, { kind: 'pass' });
      return nextMerchant(s, ctx);
    }
    case 'inspect': {
      if (s.phase !== 'inspect' || !isSheriff) return err('الشريف فقط');
      const m = s.players[s.current];
      const honest = m.bag.every(c => c === m.declare.good);
      let paid = 0;
      const confiscated = [];
      if (honest) {
        paid = m.bag.reduce((t, c) => t + GOODS[c].penalty, 0);
        const pay = Math.min(paid, me.gold);
        me.gold -= pay; m.gold += pay; paid = pay;
        m.stand.push(...m.bag);
      } else {
        for (const c of m.bag) {
          if (c === m.declare.good) m.stand.push(c);
          else { confiscated.push(c); paid += GOODS[c].penalty; }
        }
        const pay = Math.min(paid, m.gold);
        m.gold -= pay; me.gold += pay; paid = pay;
        s.discard.push(...confiscated);
      }
      s.lastInspect = { merchant: m.id, inspected: true, honest, paid, bag: m.bag.slice(), confiscated, declare: m.declare };
      pushFx(s, { kind: honest ? 'honest' : 'caught' });
      return nextMerchant(s, ctx);
    }
    case 'next': {
      if (s.phase !== 'turnEnd') return err('ليس الآن');
      if (!isSheriff && !ctx.isHost) return err('الشريف ينهي الدور');
      if (s.turnNo >= s.turnsTotal) return finish(s);
      s.turnNo++;
      s.sheriff = (s.sheriff + 1) % s.players.length;
      startTurn(s);
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

function nextMerchant(s, ctx) {
  const m = s.players[s.current];
  m.bag = null; m.offer = 0;
  if (s.queue.length) { s.current = s.queue.shift(); return ok(); }
  s.current = null;
  s.players.forEach(p => drawTo(s, p, ctx.rng));
  s.phase = 'turnEnd';
  return ok();
}

export function score(s) {
  const res = s.players.map(p => ({ id: p.id, gold: p.gold, goods: p.stand.reduce((t, c) => t + GOODS[c].value, 0), bonus: 0, counts: Object.fromEntries(Object.keys(GOODS).map(g => [g, p.stand.filter(c => c === g).length])) }));
  for (const g of LEGAL) {
    const [kingB, queenB] = BONUS[g];
    const counts = res.map(r => r.counts[g]);
    const max = Math.max(...counts);
    if (max === 0) continue;
    const kings = res.filter(r => r.counts[g] === max);
    if (kings.length > 1) { const share = Math.floor((kingB + queenB) / kings.length); kings.forEach(r => { r.bonus += share; }); continue; }
    kings[0].bonus += kingB;
    const rest = counts.filter(c => c < max);
    const second = rest.length ? Math.max(...rest) : 0;
    if (second === 0) continue;
    const queens = res.filter(r => r.counts[g] === second);
    const share = Math.floor(queenB / queens.length);
    queens.forEach(r => { r.bonus += share; });
  }
  res.forEach(r => { r.total = r.gold + r.goods + r.bonus; });
  return res;
}

function finish(s) {
  s.scores = score(s);
  const best = Math.max(...s.scores.map(r => r.total));
  s.winner = s.scores.filter(r => r.total === best).map(r => r.id);
  s.phase = 'over';
  pushFx(s, { kind: 'game-over' });
  return ok();
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  return {
    game: 'shareef', phase: s.phase, sheriff: s.players[s.sheriff].id, turnNo: s.turnNo, turnsTotal: s.turnsTotal, deck: s.deck.length,
    current: s.current != null ? s.players[s.current].id : null,
    players: s.players.map(p => ({
      id: p.id, gold: p.gold, done: p.done, handCount: p.hand.length,
      bagCount: p.bag ? p.bag.length : 0, declare: p.declare, offer: s.phase === 'inspect' ? p.offer : 0,
      // البضائع الممنوعة توضع مقلوبة في البسطة: عددها فقط ظاهر للآخرين
      stand: Object.fromEntries(Object.keys(GOODS).filter(g => GOODS[g].legal || p.id === pid || s.phase === 'over').map(g => [g, p.stand.filter(c => c === g).length])),
      hidden: p.id === pid || s.phase === 'over' ? 0 : p.stand.filter(c => !GOODS[c].legal).length,
    })),
    lastInspect: s.lastInspect, scores: s.scores, winner: s.winner || null,
    me: me ? { hand: me.hand.slice(), bag: me.bag ? me.bag.slice() : null, gold: me.gold } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winners: s.winner || [] }; }

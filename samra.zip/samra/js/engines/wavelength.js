// محرك "الطول الموجي" — فريقان، الوسيط يرى الهدف ويعطي تلميحًا، الفريق يحرك المؤشر
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, splitTeams, clampInt } from './common.js';
import { SPECTRA } from '../data/wavelength-cards.js';

export const meta = { id: 'wavelength', minPlayers: 4, maxPlayers: 16, defaultOptions: { target: 10 } };
export const normalizeOptions = (o = {}) => ({ target: [7, 10, 15].includes(o.target) ? o.target : 10 });
export const optionSchema = () => [{ key: 'target', type: 'select', label: 'نقاط الفوز', options: [[7, '٧'], [10, '١٠'], [15, '١٥']] }];

// المسافة من الهدف (0..100) → نقاط
export function points(dist) { return dist <= 4 ? 4 : dist <= 11 ? 3 : dist <= 18 ? 2 : 0; }

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const { A, B } = splitTeams(players.map(p => p.id), rng);
  const s = { game: 'wavelength', o, teams: { A, B }, score: { A: 0, B: 0 }, active: rng.pick(['A', 'B']), psychicIdx: { A: 0, B: 0 }, deck: rng.shuffle(SPECTRA.map((_, k) => k)), round: 0, players: players.map(p => ({ id: p.id })), winner: null, fx: [], fxSeq: 0 };
  newRound(s, rng);
  return s;
}

const teamOf = (s, pid) => (s.teams.A.includes(pid) ? 'A' : s.teams.B.includes(pid) ? 'B' : null);
const other = t => (t === 'A' ? 'B' : 'A');

function newRound(s, rng) {
  s.round++;
  if (!s.deck.length) s.deck = rng.shuffle(SPECTRA.map((_, k) => k));
  s.card = s.deck.pop();
  s.targetPos = 5 + rng.int(91);
  const team = s.teams[s.active];
  s.psychic = team[s.psychicIdx[s.active] % team.length];
  s.psychicIdx[s.active]++;
  s.clue = null; s.dial = 50; s.side = null; s.result = null;
  s.phase = 'clue';
  pushFx(s, { kind: 'round-start' });
}

export function act(s, pid, a, ctx) {
  if (idxOf(s, pid) < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const t = teamOf(s, pid);
  switch (a.type) {
    case 'clue': {
      if (s.phase !== 'clue' || pid !== s.psychic) return err('الوسيط فقط يعطي التلميح');
      const c = typeof a.text === 'string' ? Array.from(a.text.replace(/[\u0000-\u001f<>]/g, '').trim()).slice(0, 40).join('') : '';
      s.clue = c || '(تلميح شفهي)';
      s.phase = 'dial';
      pushFx(s, { kind: 'clue' });
      return ok();
    }
    case 'dial': {
      if (s.phase !== 'dial' || t !== s.active || pid === s.psychic) return err('فريق الوسيط يحرك المؤشر');
      s.dial = clampInt(a.value, 0, 100, s.dial);
      s.dialBy = pid;
      return ok();
    }
    case 'lock':
      if (s.phase !== 'dial' || t !== s.active || pid === s.psychic) return err('غير مسموح');
      if (Number.isInteger(a.value)) s.dial = clampInt(a.value, 0, 100, s.dial);
      s.phase = 'side'; pushFx(s, { kind: 'lock' }); return ok();
    case 'side': {
      if (s.phase !== 'side' || t !== other(s.active)) return err('الفريق الآخر يختار');
      if (a.value !== 'left' && a.value !== 'right') return err('اختيار غير صالح');
      s.side = a.value;
      // يسار/يمين بالنسبة للمؤشر على المقياس (0 = طرف اليمين، 100 = طرف اليسار)
      const pts = points(Math.abs(s.dial - s.targetPos));
      const actual = s.targetPos > s.dial ? 'left' : s.targetPos < s.dial ? 'right' : null;
      const sidePt = actual && actual === s.side ? 1 : 0;
      s.score[s.active] += pts;
      s.score[other(s.active)] += sidePt;
      s.result = { pts, sidePt, actual };
      s.phase = 'reveal';
      pushFx(s, { kind: pts === 4 ? 'bullseye' : pts ? 'score' : 'miss' });
      const w = ['A', 'B'].filter(x => s.score[x] >= s.o.target);
      if (w.length) { s.winner = w.length === 2 ? (s.score.A >= s.score.B ? (s.score.A === s.score.B ? 'tie' : 'A') : 'B') : w[0]; s.phase = 'over'; pushFx(s, { kind: 'game-over' }); }
      return ok();
    }
    case 'next':
      if (s.phase !== 'reveal') return err('ليست نهاية الجولة');
      if (!ctx.isHost && pid !== s.psychic) return err('الوسيط أو المضيف ينتقل للجولة التالية');
      s.active = other(s.active);
      newRound(s, ctx.rng);
      return ok();
    default: return err('إجراء غير معروف');
  }
}

export function view(s, pid) {
  const reveal = s.phase === 'reveal' || s.phase === 'over';
  return {
    game: 'wavelength', phase: s.phase, round: s.round, teams: s.teams, score: s.score, active: s.active, target: s.o.target,
    myTeam: teamOf(s, pid), psychic: s.psychic, card: SPECTRA[s.card], clue: s.clue, dial: s.dial, side: s.side,
    targetPos: reveal || pid === s.psychic ? s.targetPos : null,
    result: reveal ? s.result : null, winner: s.winner,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winnerTeam: s.winner, winners: s.winner === 'tie' ? [] : s.teams[s.winner] || [] }; }

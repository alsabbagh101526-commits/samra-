// سجل محركات الألعاب — كل لعبة لها محرك مستقل
import * as skull from './skull.js';
import * as bara from './bara.js';
import * as mafia from './mafia.js';
import * as avalon from './avalon.js';
import * as werewolf from './werewolf.js';
import * as coup from './coup.js';
import * as secret from './secret.js';
import * as kittens from './kittens.js';
import * as wavelength from './wavelength.js';
import * as herd from './herd.js';
import * as letters from './letters.js';
import * as familyfeud from './familyfeud.js';
import * as deception from './deception.js';
import * as shareef from './shareef.js';
import * as monopoly from './monopoly.js';

export const ENGINES = { skull, bara, mafia, avalon, werewolf, coup, secret, kittens, wavelength, herd, letters, familyfeud, deception, shareef, monopoly };

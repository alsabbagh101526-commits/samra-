// محرك "فاميلي فيود" — المضيف مقدم البرنامج ويحكم على الإجابات، واللاعبون فريقان
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, splitTeams } from './common.js';
import { FEUD_QUESTIONS } from '../data/feud-questions.js';

export const meta = { id: 'familyfeud', minPlayers: 3, maxPlayers: 16, defaultOptions: { rounds: 5 } };
export const normalizeOptions = (o = {}) => ({ rounds: [3, 5, 7].includes(o.rounds) ? o.rounds : 5 });
export const optionSchema = () => [{ key: 'rounds', type: 'select', label: 'عدد الجولات', options: [[3, '٣'], [5, '٥'], [7, '٧']] }];

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const host = players.find(p => p.isHost) || players[0];
  const { A, B } = splitTeams(players.filter(p => p.id !== host.id).map(p => p.id), rng);
  const s = { game: 'familyfeud', o, host: host.id, teams: { A, B }, score: { A: 0, B: 0 }, rot: { A: 0, B: 0 }, deck: rng.shuffle(FEUD_QUESTIONS.map((_, k) => k)), round: 0, players: players.map(p => ({ id: p.id })), winner: null, fx: [], fxSeq: 0 };
  newRound(s);
  return s;
}

const other = t => (t === 'A' ? 'B' : 'A');
const teamOf = (s, pid) => (s.teams.A.includes(pid) ? 'A' : s.teams.B.includes(pid) ? 'B' : null);
const pick = (s, t) => s.teams[t][s.rot[t]++ % s.teams[t].length];

function newRound(s) {
  s.round++;
  s.q = s.deck[(s.round - 1) % s.deck.length];
  s.revealed = FEUD_QUESTIONS[s.q].a.map(() => false);
  s.bank = 0; s.strikes = 0; s.control = null;
  s.face = { A: pick(s, 'A'), B: pick(s, 'B'), buzz: null, first: null, firstIdx: null };
  s.answerer = null; s.result = null;
  s.phase = 'faceoff';
  pushFx(s, { kind: 'round-start' });
}

function revealIdx(s, k) {
  if (s.revealed[k]) return false;
  s.revealed[k] = true;
  s.bank += FEUD_QUESTIONS[s.q].a[k][1];
  pushFx(s, { kind: 'reveal' });
  return true;
}

function nextAnswerer(s) { s.answerer = pick(s, s.control); }

export function act(s, pid, a, ctx) {
  if (idxOf(s, pid) < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const isMod = pid === s.host;
  const ans = FEUD_QUESTIONS[s.q].a;
  switch (a.type) {
    case 'buzz': {
      if (s.phase !== 'faceoff' || s.face.buzz) return err('ليس وقت الجرس');
      if (pid !== s.face.A && pid !== s.face.B) return err('المواجهة بين لاعبين فقط');
      if (s.face.first && s.face.first === teamOf(s, pid)) return err('دور الفريق الآخر');
      s.face.buzz = teamOf(s, pid);
      pushFx(s, { kind: 'buzz' });
      return ok();
    }
    case 'judge': {
      if (!isMod) return err('المقدم فقط يحكم');
      const k = a.index; // -1 = خطأ
      if (!(Number.isInteger(k) && k >= -1 && k < ans.length)) return err('اختيار غير صالح');
      if (k >= 0 && s.revealed[k]) return err('هذه الإجابة مكشوفة');
      if (s.phase === 'faceoff') {
        const f = s.face;
        if (!f.buzz) return err('لم يضغط أحد الجرس');
        const t = f.buzz;
        if (k >= 0) revealIdx(s, k); else { pushFx(s, { kind: 'strike' }); }
        if (!f.first) {
          // أول إجابة في المواجهة: الأعلى يحسم فورًا، وإلا يجاوب الآخر
          if (k === 0) return winFace(s, t);
          f.first = t; f.firstIdx = k; f.buzz = other(t);
          return ok();
        }
        // الإجابة الثانية: الأعلى ترتيبًا يكسب
        const firstK = f.firstIdx;
        if (k >= 0 && (firstK < 0 || k < firstK)) return winFace(s, t);
        if (firstK >= 0) return winFace(s, f.first);
        // كلاهما خطأ: مواجهة جديدة بنفس السؤال
        s.face = { A: pick(s, 'A'), B: pick(s, 'B'), buzz: null, first: null, firstIdx: null };
        return ok();
      }
      if (s.phase === 'play') {
        if (k >= 0) {
          revealIdx(s, k);
          if (s.revealed.every(Boolean)) return award(s, s.control);
          nextAnswerer(s);
          return ok();
        }
        s.strikes++;
        pushFx(s, { kind: 'strike' });
        if (s.strikes >= 3) { s.phase = 'steal'; pushFx(s, { kind: 'phase' }); return ok(); }
        nextAnswerer(s);
        return ok();
      }
      if (s.phase === 'steal') {
        if (k >= 0) { revealIdx(s, k); return award(s, other(s.control), true); }
        pushFx(s, { kind: 'strike' });
        return award(s, s.control);
      }
      return err('لا يوجد ما يُحكم عليه');
    }
    case 'choose': {
      if (s.phase !== 'choose') return err('ليس وقت الاختيار');
      if (teamOf(s, pid) !== s.faceWinner && !isMod) return err('الفريق الفائز بالمواجهة يختار');
      if (a.value !== 'play' && a.value !== 'pass') return err('اختيار غير صالح');
      s.control = a.value === 'play' ? s.faceWinner : other(s.faceWinner);
      s.phase = 'play';
      nextAnswerer(s);
      pushFx(s, { kind: 'phase' });
      return ok();
    }
    case 'revealAll':
      if (!isMod || s.phase !== 'roundEnd') return err('للمقدم فقط');
      s.revealed = s.revealed.map(() => true);
      return ok();
    case 'next': {
      if (!isMod || s.phase !== 'roundEnd') return err('للمقدم فقط');
      if (s.round >= s.o.rounds) {
        s.phase = 'over';
        s.winner = s.score.A === s.score.B ? 'tie' : s.score.A > s.score.B ? 'A' : 'B';
        pushFx(s, { kind: 'game-over' });
        return ok();
      }
      newRound(s);
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

function winFace(s, t) {
  s.faceWinner = t;
  if (s.revealed.every(Boolean)) return award(s, t);
  s.phase = 'choose';
  pushFx(s, { kind: 'phase' });
  return ok();
}

function award(s, t, stolen = false) {
  s.score[t] += s.bank;
  s.result = { team: t, points: s.bank, stolen };
  s.phase = 'roundEnd';
  pushFx(s, { kind: 'award' });
  return ok();
}

export function view(s, pid) {
  const isMod = pid === s.host;
  const ans = FEUD_QUESTIONS[s.q].a;
  const end = s.phase === 'roundEnd' || s.phase === 'over';
  return {
    game: 'familyfeud', phase: s.phase, round: s.round, rounds: s.o.rounds, host: s.host, isMod, teams: s.teams, score: s.score,
    question: FEUD_QUESTIONS[s.q].q,
    // الإجابات المخفية لا تُرسل إلا للمقدم
    answers: ans.map(([t, p], k) => (isMod || s.revealed[k] || (end && s.revealed[k]) ? { text: t, pts: p, shown: s.revealed[k] } : { text: null, pts: null, shown: false })),
    bank: s.bank, strikes: s.strikes, control: s.control, face: s.face, faceWinner: s.faceWinner || null,
    answerer: s.answerer, result: s.result, myTeam: teamOf(s, pid), winner: s.winner,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winnerTeam: s.winner, winners: s.teams[s.winner] || [] }; }

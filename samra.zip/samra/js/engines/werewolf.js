// محرك المستذئب — ذئاب، عرّافة، ساحرة بجرعتين، صياد يطلق رصاصته عند موته
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, bool, clampInt } from './common.js';

export const meta = { id: 'werewolf', minPlayers: 6, maxPlayers: 18, defaultOptions: { wolves: 'auto', seer: true, witch: true, hunter: true, revealOnDeath: true, discussionSec: 180 } };

export const autoWolves = n => (n <= 8 ? 2 : n <= 12 ? 3 : 4);

export function normalizeOptions(o = {}, n = 6) {
  const d = meta.defaultOptions;
  const maxW = Math.max(1, Math.floor((n - 1) / 3));
  return {
    wolves: Number.isInteger(o.wolves) && o.wolves >= 1 && o.wolves <= maxW ? o.wolves : 'auto',
    seer: bool(o.seer, d.seer), witch: bool(o.witch, d.witch), hunter: bool(o.hunter, d.hunter),
    revealOnDeath: bool(o.revealOnDeath, d.revealOnDeath),
    discussionSec: [0, 60, 120, 180, 300].includes(o.discussionSec) ? o.discussionSec : d.discussionSec,
  };
}

export const optionSchema = n => [
  { key: 'wolves', type: 'select', label: 'عدد الذئاب', options: [['auto', `تلقائي (${autoWolves(Math.max(6, n))})`], ...Array.from({ length: Math.max(1, Math.floor((Math.max(n, 6) - 1) / 3)) }, (_, k) => [k + 1, String(k + 1)])] },
  { key: 'discussionSec', type: 'select', label: 'مدة النقاش', options: [[0, 'بدون مؤقت'], [60, 'دقيقة'], [120, 'دقيقتان'], [180, '٣ دقائق'], [300, '٥ دقائق']] },
  { key: 'seer', type: 'switch', label: 'العرّافة' },
  { key: 'witch', type: 'switch', label: 'الساحرة' },
  { key: 'hunter', type: 'switch', label: 'الصياد' },
  { key: 'revealOnDeath', type: 'switch', label: 'كشف دور من يموت' },
];

export function setup(players, options, rng) {
  const n = players.length;
  const o = normalizeOptions(options, n);
  const w = o.wolves === 'auto' ? autoWolves(n) : o.wolves;
  const roles = [];
  for (let k = 0; k < w; k++) roles.push('wolf');
  if (o.seer) roles.push('seer');
  if (o.witch) roles.push('witch');
  if (o.hunter) roles.push('hunter');
  while (roles.length < n) roles.push('villager');
  const dealt = rng.shuffle(roles);
  return {
    game: 'werewolf', o, phase: 'roles', night: 0, day: 0,
    players: players.map((p, j) => ({ id: p.id, role: dealt[j], alive: true, ready: false, done: false, vote: null })),
    wolfPicks: {}, wolfTarget: null, seerPick: null, seen: [], potions: { heal: true, poison: true },
    witchHeal: false, witchPoison: null, witchDone: false,
    deaths: [], hunterQueue: [], afterHunter: null, lastVote: null, deadline: null, winner: null,
    fx: [], fxSeq: 0,
  };
}

const alive = s => s.players.filter(p => p.alive);
const wolvesAlive = s => s.players.filter(p => p.alive && p.role === 'wolf');

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  const tgt = () => idxOf(s, a.target);
  switch (a.type) {
    case 'ready':
      if (s.phase !== 'roles') return err('ليست مرحلة الأدوار');
      me.ready = true;
      if (s.players.every(p => p.ready)) startNight(s);
      return ok();
    case 'wolfPick': {
      if (s.phase !== 'night' || !me.alive || me.role !== 'wolf') return err('غير مسموح');
      if (s.wolfTarget != null) return err('اتفقت الذئاب على الضحية');
      const t = tgt();
      if (t < 0 || !s.players[t].alive || s.players[t].role === 'wolf') return err('هدف غير صالح');
      s.wolfPicks[pid] = t;
      const ws = wolvesAlive(s);
      if (ws.every(w => s.wolfPicks[w.id] === t)) {
        s.wolfTarget = t;
        ws.forEach(w => { w.done = true; });
        pushFx(s, { kind: 'locked', to: ws.map(w => w.id) });
        const witch = s.players.find(p => p.alive && p.role === 'witch');
        if (witch) pushFx(s, { kind: 'witch-wake', to: [witch.id] });
      }
      return afterNight(s, ctx);
    }
    case 'see': {
      if (s.phase !== 'night' || !me.alive || me.role !== 'seer') return err('غير مسموح');
      if (s.seerPick != null) return err('استخدمت رؤيتك الليلة');
      const t = tgt();
      if (t < 0 || t === i || !s.players[t].alive) return err('اختيار غير صالح');
      s.seerPick = t;
      s.seen.push({ night: s.night, target: s.players[t].id, wolf: s.players[t].role === 'wolf' });
      me.done = true;
      pushFx(s, { kind: 'seen', to: [pid] });
      return afterNight(s, ctx);
    }
    case 'witch': {
      if (s.phase !== 'night' || !me.alive || me.role !== 'witch') return err('غير مسموح');
      if (s.wolfTarget == null) return err('انتظر حتى تختار الذئاب');
      if (s.witchDone) return err('أنهيت دورك الليلة');
      const heal = !!a.heal, poison = a.poison || null;
      if (heal && !s.potions.heal) return err('استخدمت جرعة الشفاء');
      if (poison) {
        if (!s.potions.poison) return err('استخدمت جرعة السم');
        const t = idxOf(s, poison);
        if (t < 0 || !s.players[t].alive || t === i) return err('هدف السم غير صالح');
      }
      if (heal) { s.potions.heal = false; s.witchHeal = true; }
      if (poison) { s.potions.poison = false; s.witchPoison = idxOf(s, poison); }
      s.witchDone = true;
      me.done = true;
      return afterNight(s, ctx);
    }
    case 'sleep': {
      if (s.phase !== 'night' || !me.alive) return err('غير مسموح');
      if (me.role === 'villager' || me.role === 'hunter') { me.done = true; return afterNight(s, ctx); }
      return err('لديك إجراء ليلي');
    }
    case 'shoot': {
      if (s.phase !== 'hunter' || s.hunterQueue[0] !== i) return err('ليس دورك');
      const t = a.target === 'none' ? -1 : tgt();
      if (a.target !== 'none' && (t < 0 || !s.players[t].alive)) return err('هدف غير صالح');
      s.hunterQueue.shift();
      if (t >= 0) { kill(s, t, 'hunter'); pushFx(s, { kind: 'shot' }); }
      s.lastShot = { by: pid, target: t >= 0 ? s.players[t].id : null };
      return continueAfterDeaths(s, ctx);
    }
    case 'startVote':
      if (s.phase !== 'day') return err('ليس النهار');
      if (!ctx.isHost) return err('المضيف يبدأ التصويت');
      toVote(s); return ok();
    case 'vote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (!me.alive) return err('الأموات لا يصوّتون');
      if (me.vote != null) return err('صوّتّ بالفعل');
      if (a.target === 'skip') me.vote = 'skip';
      else { const t = tgt(); if (t < 0 || t === i || !s.players[t].alive) return err('اختيار غير صالح'); me.vote = t; }
      pushFx(s, { kind: 'vote' });
      if (alive(s).every(p => p.vote != null)) resolveVote(s, ctx);
      return ok();
    }
    case 'closeVote':
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (!ctx.isHost) return err('للمضيف فقط');
      resolveVote(s, ctx); return ok();
    default: return err('إجراء غير معروف');
  }
}

function startNight(s) {
  s.night++; s.phase = 'night'; s.deadline = null;
  s.wolfPicks = {}; s.wolfTarget = null; s.seerPick = null; s.witchHeal = false; s.witchPoison = null; s.witchDone = false;
  s.players.forEach(p => { p.done = !p.alive; p.vote = null; });
  // الساحرة بلا جرعات تُعتبر منتهية
  const w = s.players.find(p => p.alive && p.role === 'witch');
  if (w && !s.potions.heal && !s.potions.poison) { w.done = true; s.witchDone = true; }
  pushFx(s, { kind: 'night' });
}

function afterNight(s, ctx) {
  if (!alive(s).every(p => p.done)) return ok();
  s.deaths = [];
  if (s.wolfTarget != null && !s.witchHeal) kill(s, s.wolfTarget, 'wolves');
  if (s.witchPoison != null && s.players[s.witchPoison].alive) kill(s, s.witchPoison, 'poison');
  s.day++;
  s.dawn = { night: s.night, deaths: s.deaths.slice() };
  s.lastVote = null; s.lastShot = null;
  pushFx(s, { kind: s.deaths.length ? 'dawn-death' : 'dawn-safe' });
  s.after = 'day';
  return continueAfterDeaths(s, ctx);
}

function kill(s, t, cause) {
  const p = s.players[t];
  if (!p.alive) return;
  p.alive = false;
  s.deaths.push({ id: p.id, cause });
  if (p.role === 'hunter') s.hunterQueue.push(t);
}

function continueAfterDeaths(s, ctx) {
  if (checkWin(s)) return ok();
  if (s.hunterQueue.length) { s.phase = 'hunter'; pushFx(s, { kind: 'hunter' }); return ok(); }
  if (s.after === 'day') {
    s.phase = 'day';
    s.deadline = s.o.discussionSec > 0 ? ctx.now + s.o.discussionSec * 1000 : null;
  } else startNight(s);
  return ok();
}

function toVote(s) { s.phase = 'vote'; s.deadline = null; s.players.forEach(p => { p.vote = null; }); pushFx(s, { kind: 'phase' }); }

function resolveVote(s, ctx) {
  const counts = new Map();
  alive(s).forEach(p => { if (p.vote != null) counts.set(p.vote, (counts.get(p.vote) || 0) + 1); });
  let max = 0, top = [];
  for (const [k, c] of counts) { if (c > max) { max = c; top = [k]; } else if (c === max) top.push(k); }
  s.deaths = [];
  const votes = alive(s).map(p => ({ from: p.id, to: p.vote == null ? null : p.vote === 'skip' ? 'skip' : s.players[p.vote].id }));
  let elim = null;
  if (top.length === 1 && top[0] !== 'skip' && max > 0) { elim = top[0]; kill(s, elim, 'vote'); }
  s.lastVote = { day: s.day, votes, eliminated: elim == null ? null : s.players[elim].id };
  pushFx(s, { kind: elim == null ? 'no-elim' : 'eliminated' });
  s.after = 'night';
  continueAfterDeaths(s, ctx);
}

function checkWin(s) {
  const w = wolvesAlive(s).length;
  const others = alive(s).length - w;
  if (w === 0) s.winner = 'village';
  else if (w >= others) s.winner = 'wolves';
  if (s.winner) { s.phase = 'over'; s.deadline = null; s.hunterQueue = []; pushFx(s, { kind: 'game-over' }); return true; }
  return false;
}

export function tick(s, now) {
  if (s.phase === 'day' && s.deadline && now >= s.deadline) { toVote(s); return true; }
  return false;
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  const v = {
    game: 'werewolf', phase: s.phase, night: s.night, day: s.day, deadline: s.deadline, winner: s.winner,
    players: s.players.map(p => ({ id: p.id, alive: p.alive, ready: s.phase === 'roles' ? p.ready : undefined, voted: s.phase === 'vote' ? p.vote != null : undefined, role: over || (!p.alive && s.o.revealOnDeath) ? p.role : null })),
    nightDone: s.phase === 'night' ? alive(s).filter(p => p.done).length : null,
    nightTotal: s.phase === 'night' ? alive(s).length : null,
    dawn: s.dawn || null, lastVote: s.lastVote, lastShot: s.lastShot || null,
    hunter: s.phase === 'hunter' ? s.players[s.hunterQueue[0]].id : null,
    me: null, fx: viewFx(s, pid),
  };
  if (me) {
    const m = { role: me.role, alive: me.alive, ready: me.ready, done: me.done, vote: me.vote == null ? null : me.vote === 'skip' ? 'skip' : s.players[me.vote].id };
    if (me.role === 'wolf') {
      m.pack = s.players.filter(p => p.role === 'wolf').map(p => ({ id: p.id, alive: p.alive }));
      if (s.phase === 'night') { m.picks = Object.fromEntries(Object.entries(s.wolfPicks).map(([k, t]) => [k, s.players[t].id])); m.locked = s.wolfTarget == null ? null : s.players[s.wolfTarget].id; }
    }
    if (me.role === 'seer') m.seen = s.seen.slice();
    if (me.role === 'witch') {
      m.potions = { ...s.potions };
      if (s.phase === 'night') m.victim = s.wolfTarget == null ? null : s.players[s.wolfTarget].id;
    }
    v.me = m;
  }
  return v;
}

export function summary(s) {
  return { winnerTeam: s.winner, winners: s.players.filter(p => (p.role === 'wolf') === (s.winner === 'wolves')).map(p => p.id) };
}

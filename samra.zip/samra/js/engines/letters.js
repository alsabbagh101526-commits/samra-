// محرك "تحدي الحروف" — شبكة سداسية ٥×٥، فريق يربط من الأعلى للأسفل وفريق من اليمين لليسار
// المضيف هو المقدم والحَكَم: يختار الخلية ويحكم على الإجابة.
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, splitTeams } from './common.js';

export const meta = { id: 'letters', minPlayers: 3, maxPlayers: 16, defaultOptions: { boards: 1 } };
export const normalizeOptions = (o = {}) => ({ boards: [1, 2].includes(o.boards) ? o.boards : 1 });
export const optionSchema = () => [{ key: 'boards', type: 'select', label: 'طول المباراة', options: [[1, 'لوحة واحدة'], [2, 'الأفضل من ٣ لوحات']] }];

export const LETTERS = 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي'.split('');
export const CATEGORIES = ['اسم ولد', 'اسم بنت', 'حيوان', 'نبات أو فاكهة أو خضار', 'جماد', 'دولة', 'مدينة', 'أكلة', 'مهنة', 'شيء في البيت'];
export const N = 5;

// تجاور الشبكة السداسية (صفوف مزاحة: الصفوف الفردية مزاحة)
export function neighbors(r, c) {
  const odd = r % 2 === 1;
  const d = odd ? [[0, -1], [0, 1], [-1, 0], [-1, 1], [1, 0], [1, 1]] : [[0, -1], [0, 1], [-1, -1], [-1, 0], [1, -1], [1, 0]];
  return d.map(([dr, dc]) => [r + dr, c + dc]).filter(([a, b]) => a >= 0 && a < N && b >= 0 && b < N);
}

// البرتقالي (A) يربط الصف الأول بالأخير، والأخضر (B) يربط العمود الأول بالأخير
export function connected(owner, team) {
  const seen = new Set();
  const q = [];
  for (let k = 0; k < N; k++) {
    const [r, c] = team === 'A' ? [0, k] : [k, 0];
    if (owner[r * N + c] === team) { q.push([r, c]); seen.add(r * N + c); }
  }
  while (q.length) {
    const [r, c] = q.shift();
    if ((team === 'A' && r === N - 1) || (team === 'B' && c === N - 1)) return true;
    for (const [a, b] of neighbors(r, c)) {
      const k = a * N + b;
      if (!seen.has(k) && owner[k] === team) { seen.add(k); q.push([a, b]); }
    }
  }
  return false;
}

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const host = players.find(p => p.isHost) || players[0];
  const rest = players.filter(p => p.id !== host.id).map(p => p.id);
  const { A, B } = splitTeams(rest, rng);
  const s = { game: 'letters', o, host: host.id, teams: { A, B }, wins: { A: 0, B: 0 }, board: 0, players: players.map(p => ({ id: p.id })), winner: null, fx: [], fxSeq: 0 };
  newBoard(s, rng);
  return s;
}

function newBoard(s, rng) {
  s.board++;
  s.letters = rng.shuffle(LETTERS).slice(0, N * N);
  s.owner = Array(N * N).fill(null);
  s.cell = null; s.prompt = null; s.buzz = null; s.locked = []; s.boardWinner = null;
  s.phase = 'pick';
  s.picker = null;
  pushFx(s, { kind: 'round-start' });
}

const teamOf = (s, pid) => (s.teams.A.includes(pid) ? 'A' : s.teams.B.includes(pid) ? 'B' : null);

export function act(s, pid, a, ctx) {
  if (idxOf(s, pid) < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const isMod = pid === s.host;
  const t = teamOf(s, pid);
  switch (a.type) {
    case 'pick': {
      if (s.phase !== 'pick') return err('ليست مرحلة اختيار الحرف');
      if (!isMod && !(s.picker && t === s.picker)) return err('المقدم أو الفريق صاحب الدور يختار الحرف');
      const k = a.cell;
      if (!Number.isInteger(k) || k < 0 || k >= N * N || s.owner[k]) return err('خلية غير متاحة');
      s.cell = k;
      s.prompt = ctx.rng.pick(CATEGORIES);
      s.buzz = null; s.locked = [];
      s.phase = 'buzz';
      pushFx(s, { kind: 'pick' });
      return ok();
    }
    case 'buzz': {
      if (s.phase !== 'buzz') return err('ليس وقت الجرس');
      if (!t) return err('المقدم لا يضغط الجرس');
      if (s.buzz) return err('سبقك أحدهم');
      if (s.locked.includes(t)) return err('فريقك أخطأ في هذا الحرف');
      s.buzz = { id: pid, team: t };
      pushFx(s, { kind: 'buzz', who: pid });
      return ok();
    }
    case 'judge': {
      if (!isMod) return err('المقدم فقط يحكم');
      if (s.phase !== 'buzz' || !s.buzz) return err('لا توجد إجابة للحكم عليها');
      if (a.correct) {
        s.owner[s.cell] = s.buzz.team;
        pushFx(s, { kind: 'correct', team: s.buzz.team });
        s.picker = s.buzz.team;
        if (connected(s.owner, s.buzz.team)) {
          s.wins[s.buzz.team]++;
          s.boardWinner = s.buzz.team;
          pushFx(s, { kind: 'board-win' });
          if (s.wins[s.buzz.team] >= s.o.boards) { s.winner = s.buzz.team; s.phase = 'over'; pushFx(s, { kind: 'game-over' }); return ok(); }
          s.phase = 'boardEnd';
          return ok();
        }
        s.phase = 'pick'; s.cell = null; s.buzz = null;
        return ok();
      }
      s.locked.push(s.buzz.team);
      s.buzz = null;
      pushFx(s, { kind: 'wrong' });
      if (s.locked.length >= 2) { s.phase = 'pick'; s.cell = null; s.locked = []; }
      return ok();
    }
    case 'skip':
      if (!isMod || s.phase !== 'buzz') return err('للمقدم فقط');
      s.phase = 'pick'; s.cell = null; s.buzz = null; s.locked = [];
      return ok();
    case 'reprompt':
      if (!isMod || s.phase !== 'buzz') return err('للمقدم فقط');
      s.prompt = ctx.rng.pick(CATEGORIES.filter(c => c !== s.prompt));
      return ok();
    case 'nextBoard':
      if (!isMod || s.phase !== 'boardEnd') return err('للمقدم فقط');
      newBoard(s, ctx.rng); return ok();
    default: return err('إجراء غير معروف');
  }
}

export function view(s, pid) {
  return {
    game: 'letters', phase: s.phase, board: s.board, boards: s.o.boards, host: s.host, teams: s.teams, wins: s.wins,
    letters: s.letters, owner: s.owner, cell: s.cell, prompt: s.prompt, buzz: s.buzz, locked: s.locked,
    picker: s.picker, myTeam: teamOf(s, pid), boardWinner: s.boardWinner, winner: s.winner,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winnerTeam: s.winner, winners: s.teams[s.winner] || [] }; }

// محرك الانقلاب (Coup) — إعلان، تحدٍّ، صدّ، تحدٍّ للصد، ثم التنفيذ
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, nextAliveIdx } from './common.js';

export const meta = { id: 'coup', minPlayers: 2, maxPlayers: 6, defaultOptions: {} };
export const CARDS = ['duke', 'assassin', 'captain', 'ambassador', 'contessa'];
const CLAIM = { tax: 'duke', assassinate: 'assassin', steal: 'captain', exchange: 'ambassador' };
const BLOCKERS = { foreign_aid: ['duke'], assassinate: ['contessa'], steal: ['captain', 'ambassador'] };
const TARGETED = ['coup', 'assassinate', 'steal'];

export function setup(players, options, rng) {
  let deck = rng.shuffle(CARDS.flatMap(c => [c, c, c]));
  const ps = players.map(p => {
    const cards = [{ c: deck.pop(), dead: false }, { c: deck.pop(), dead: false }];
    return { id: p.id, coins: 2, cards, alive: true };
  });
  return { game: 'coup', phase: 'action', players: ps, deck, turn: rng.int(ps.length), pend: null, loseQ: [], next: null, exchange: null, log: [], winner: null, fx: [], fxSeq: 0 };
}

const live = p => p.cards.filter(c => !c.dead);
const has = (p, card) => live(p).some(c => c.c === card);

function log(s, text) { s.log.push(text); if (s.log.length > 12) s.log.shift(); }

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  if (!me.alive && a.type !== 'noop') return err('خرجت من اللعبة');

  if (a.type === 'lose') {
    if (s.phase !== 'lose' || s.loseQ[0] !== i) return err('ليس مطلوبًا منك كشف بطاقة');
    const k = a.index;
    if (!Number.isInteger(k) || !me.cards[k] || me.cards[k].dead) return err('اختر بطاقة حية');
    me.cards[k].dead = true;
    s.loseQ.shift();
    afterLoseOne(s, i);
    return drainLose(s, ctx);
  }

  if (a.type === 'keep') {
    if (s.phase !== 'exchange' || s.pend.actor !== i) return err('ليس دورك');
    const pool = s.exchange;
    const need = live(me).length;
    const keep = Array.isArray(a.indices) ? [...new Set(a.indices)] : [];
    if (keep.length !== need || keep.some(k => !Number.isInteger(k) || k < 0 || k >= pool.length)) return err(`اختر ${need} بطاقة للاحتفاظ بها`);
    const kept = keep.map(k => pool[k]);
    const back = pool.filter((_, k) => !keep.includes(k));
    let n = 0;
    me.cards.forEach(c => { if (!c.dead) c.c = kept[n++]; });
    s.deck = ctx.rng.shuffle(s.deck.concat(back));
    s.exchange = null;
    log(s, 'بدّل بطاقاته');
    return endTurn(s);
  }

  if (s.phase === 'action') {
    if (i !== s.turn) return err('ليس دورك');
    const kind = a.type;
    const valid = ['income', 'foreign_aid', 'coup', 'tax', 'assassinate', 'steal', 'exchange'];
    if (!valid.includes(kind)) return err('إجراء غير معروف');
    if (me.coins >= 10 && kind !== 'coup') return err('معك ١٠ عملات أو أكثر: الانقلاب إجباري');
    let t = -1;
    if (TARGETED.includes(kind)) {
      t = idxOf(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive) return err('اختر هدفًا صالحًا');
    }
    if (kind === 'coup' && me.coins < 7) return err('الانقلاب يحتاج ٧ عملات');
    if (kind === 'assassinate' && me.coins < 3) return err('الاغتيال يحتاج ٣ عملات');
    if (kind === 'income') { me.coins += 1; log(s, 'دخل +١'); pushFx(s, { kind: 'coin', who: pid }); return endTurn(s); }
    if (kind === 'coup') {
      me.coins -= 7;
      pushFx(s, { kind: 'coup', who: pid });
      log(s, 'انقلاب');
      s.pend = { kind, actor: i, target: t, claim: null, stage: 'resolve' };
      s.loseQ.push(t);
      s.next = 'endTurn';
      return drainLose(s, ctx);
    }
    if (kind === 'assassinate') me.coins -= 3; // تُدفع عند الإعلان (تحتاج تحققًا عند نجاح التحدي)
    s.pend = { kind, actor: i, target: t, claim: CLAIM[kind] || null, stage: null, responded: [], blocker: null, blockCard: null };
    pushFx(s, { kind: 'declare', who: pid, action: kind });
    return s.pend.claim ? openStage(s, 'chal', ctx) : openStage(s, 'block', ctx);
  }

  if (s.phase === 'respond') {
    const p = s.pend;
    if (!stageResponders(s).includes(i)) return err('لا ينتظر منك رد الآن');
    if (p.responded.includes(i)) return err('رددت بالفعل');
    if (a.type === 'allow') {
      p.responded.push(i);
      if (stageResponders(s).every(j => p.responded.includes(j))) return stageComplete(s, ctx);
      return ok();
    }
    if (a.type === 'challenge') {
      if (p.stage === 'chal') return challenge(s, p.actor, p.claim, i, 'actionTrue', 'actionFalse', ctx);
      if (p.stage === 'chalBlock') return challenge(s, p.blocker, p.blockCard, i, 'blockTrue', 'blockFalse', ctx);
      return err('لا يمكن التحدي الآن');
    }
    if (a.type === 'block') {
      if (p.stage !== 'block') return err('لا يمكن الصد الآن');
      if (!(BLOCKERS[p.kind] || []).includes(a.card)) return err('هذه البطاقة لا تصد هذا الإجراء');
      p.blocker = i; p.blockCard = a.card;
      pushFx(s, { kind: 'block', who: pid });
      log(s, 'صدّ');
      return openStage(s, 'chalBlock', ctx);
    }
    return err('إجراء غير معروف');
  }
  return err('لا يمكن الآن');
}

function stageResponders(s) {
  const p = s.pend;
  const aliveIdx = s.players.map((x, j) => j).filter(j => s.players[j].alive);
  if (p.stage === 'chal') return aliveIdx.filter(j => j !== p.actor);
  if (p.stage === 'block') return p.kind === 'foreign_aid' ? aliveIdx.filter(j => j !== p.actor) : (s.players[p.target]?.alive ? [p.target] : []);
  if (p.stage === 'chalBlock') return aliveIdx.filter(j => j !== p.blocker);
  return [];
}

function openStage(s, stage, ctx) {
  s.pend.stage = stage;
  s.pend.responded = [];
  s.phase = 'respond';
  if (stageResponders(s).length === 0) return stageComplete(s, ctx);
  return ok();
}

function stageComplete(s, ctx) {
  const p = s.pend;
  if (p.stage === 'chal') {
    if (BLOCKERS[p.kind] && s.players[p.target]?.alive !== false) return openStage(s, 'block', ctx);
    return resolve(s, ctx);
  }
  if (p.stage === 'block') return resolve(s, ctx);
  if (p.stage === 'chalBlock') { log(s, 'نجح الصد'); pushFx(s, { kind: 'blocked' }); return endTurn(s); }
  return ok();
}

// التحدي: من يملك البطاقة يكشفها ويبدّلها، والخاسر يفقد نفوذًا
function challenge(s, claimant, card, challenger, onTrue, onFalse, ctx) {
  const c = s.players[claimant];
  pushFx(s, { kind: 'challenge', who: s.players[challenger].id });
  if (has(c, card)) {
    const slot = c.cards.find(x => !x.dead && x.c === card);
    s.deck.push(slot.c);
    s.deck = ctx.rng.shuffle(s.deck);
    slot.c = s.deck.pop();
    s.lastChallenge = { claimant: c.id, challenger: s.players[challenger].id, card, truthful: true };
    log(s, 'فشل التحدي');
    s.loseQ.push(challenger);
    s.next = onTrue;
  } else {
    s.lastChallenge = { claimant: c.id, challenger: s.players[challenger].id, card, truthful: false };
    log(s, 'نجح التحدي — كان يخادع');
    s.loseQ.push(claimant);
    s.next = onFalse;
  }
  pushFx(s, { kind: s.lastChallenge.truthful ? 'challenge-fail' : 'challenge-win' });
  return drainLose(s, ctx);
}

function afterLoseOne(s, j) {
  const p = s.players[j];
  pushFx(s, { kind: 'lose', who: p.id });
  if (live(p).length === 0) { p.alive = false; pushFx(s, { kind: 'out', who: p.id }); }
}

function drainLose(s, ctx) {
  while (s.loseQ.length) {
    const j = s.loseQ[0];
    const p = s.players[j];
    const lv = live(p);
    if (!p.alive || lv.length === 0) { s.loseQ.shift(); continue; }
    if (lv.length === 1) { lv[0].dead = true; s.loseQ.shift(); afterLoseOne(s, j); continue; }
    s.phase = 'lose';
    return ok();
  }
  if (checkWin(s)) return ok();
  const nx = s.next; s.next = null;
  const p = s.pend;
  switch (nx) {
    case 'endTurn': return endTurn(s);
    case 'actionTrue':
      if (!s.players[p.actor].alive) return endTurn(s);
      if (BLOCKERS[p.kind] && (p.kind === 'foreign_aid' || s.players[p.target]?.alive)) return openStage(s, 'block', ctx);
      return resolve(s, ctx);
    case 'actionFalse': return endTurn(s);
    case 'blockTrue': log(s, 'نجح الصد'); pushFx(s, { kind: 'blocked' }); return endTurn(s);
    case 'blockFalse': return resolve(s, ctx);
  }
  return ok();
}

function resolve(s, ctx) {
  const p = s.pend;
  const actor = s.players[p.actor];
  if (!actor.alive) return endTurn(s);
  const tg = p.target >= 0 ? s.players[p.target] : null;
  switch (p.kind) {
    case 'foreign_aid': actor.coins += 2; log(s, 'مساعدة خارجية +٢'); pushFx(s, { kind: 'coin', who: actor.id }); return endTurn(s);
    case 'tax': actor.coins += 3; log(s, 'ضريبة +٣'); pushFx(s, { kind: 'coin', who: actor.id }); return endTurn(s);
    case 'steal': {
      if (!tg.alive) return endTurn(s);
      const n = Math.min(2, tg.coins); tg.coins -= n; actor.coins += n;
      log(s, `سرقة ${n}`); pushFx(s, { kind: 'coin', who: actor.id });
      return endTurn(s);
    }
    case 'assassinate': {
      if (!tg.alive) return endTurn(s);
      log(s, 'اغتيال'); pushFx(s, { kind: 'assassinate' });
      s.loseQ.push(p.target); s.next = 'endTurn';
      return drainLose(s, ctx);
    }
    case 'exchange': {
      const drawn = [s.deck.pop(), s.deck.pop()].filter(Boolean);
      s.exchange = live(actor).map(c => c.c).concat(drawn);
      s.phase = 'exchange';
      return ok();
    }
  }
  return endTurn(s);
}

function endTurn(s) {
  if (checkWin(s)) return ok();
  s.pend = null; s.exchange = null; s.next = null;
  s.turn = nextAliveIdx(s.players, s.turn);
  s.phase = 'action';
  return ok();
}

function checkWin(s) {
  const al = s.players.filter(p => p.alive);
  if (al.length === 1) {
    s.phase = 'over'; s.winner = al[0].id; s.pend = null; s.loseQ = [];
    pushFx(s, { kind: 'game-over', who: s.winner });
    return true;
  }
  return false;
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const p = s.pend;
  const over = s.phase === 'over';
  return {
    game: 'coup', phase: s.phase, turn: s.players[s.turn]?.id, deck: s.deck.length, winner: s.winner,
    players: s.players.map(x => ({ id: x.id, coins: x.coins, alive: x.alive, cards: x.cards.map(c => (c.dead || over ? { c: c.c, dead: c.dead } : { c: null, dead: false })) })),
    pend: p ? {
      kind: p.kind, actor: s.players[p.actor].id, target: p.target >= 0 ? s.players[p.target].id : null, claim: p.claim,
      stage: p.stage, blocker: p.blocker != null ? s.players[p.blocker].id : null, blockCard: p.blockCard,
      waiting: s.phase === 'respond' ? stageResponders(s).filter(j => !p.responded.includes(j)).map(j => s.players[j].id) : [],
    } : null,
    loser: s.phase === 'lose' ? s.players[s.loseQ[0]].id : null,
    lastChallenge: s.lastChallenge || null,
    log: s.log.slice(),
    me: me ? {
      cards: me.cards.map(c => ({ c: c.c, dead: c.dead })), coins: me.coins,
      exchange: s.phase === 'exchange' && p && p.actor === i ? s.exchange.slice() : null,
      canRespond: s.phase === 'respond' && stageResponders(s).includes(i) && !p.responded.includes(i),
    } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winners: [s.winner] }; }

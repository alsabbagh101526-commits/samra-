// أدوات مشتركة للمحركات
export const ok = () => ({ ok: true });
export const err = e => ({ ok: false, error: e });
export const idxOf = (s, pid) => s.players.findIndex(p => p.id === pid);
export const clampInt = (v, lo, hi, def) => (Number.isInteger(v) && v >= lo && v <= hi ? v : def);
export const bool = (v, def) => (typeof v === 'boolean' ? v : def);
// تقسيم متوازن عشوائي إلى فريقين
export function splitTeams(ids, rng) {
  const sh = rng.shuffle(ids);
  const A = [], B = [];
  sh.forEach((id, k) => (k % 2 ? B : A).push(id));
  return { A, B };
}
export function nextAliveIdx(players, from, pred = p => p.alive) {
  const n = players.length;
  for (let k = 1; k <= n; k++) { const i = (from + k) % n; if (pred(players[i], i)) return i; }
  return -1;
}

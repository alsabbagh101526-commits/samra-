// محرك "القطط المتفجرة" — العب ما شئت ثم اسحب. نافذة "لا!" بعد كل بطاقة فعل.
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, nextAliveIdx } from './common.js';

export const meta = { id: 'kittens', minPlayers: 2, maxPlayers: 5, defaultOptions: { nopeSec: 4 } };
export const CATS = ['cat1', 'cat2', 'cat3', 'cat4', 'cat5'];
export const ACTIONS = ['attack', 'skip', 'favor', 'shuffle', 'future'];
const COUNTS = { attack: 4, skip: 4, favor: 4, shuffle: 4, future: 5, nope: 5, cat1: 4, cat2: 4, cat3: 4, cat4: 4, cat5: 4 };

export const normalizeOptions = (o = {}) => ({ nopeSec: [3, 4, 6].includes(o.nopeSec) ? o.nopeSec : 4 });
export const optionSchema = () => [{ key: 'nopeSec', type: 'select', label: 'مهلة بطاقة «لا!»', options: [[3, '٣ ثوانٍ'], [4, '٤ ثوانٍ'], [6, '٦ ثوانٍ']] }];

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const n = players.length;
  let deck = [];
  for (const [c, k] of Object.entries(COUNTS)) for (let j = 0; j < k; j++) deck.push(c);
  deck = rng.shuffle(deck);
  const ps = players.map(p => ({ id: p.id, alive: true, hand: ['defuse', ...deck.splice(0, 7)] }));
  const extraDefuse = n <= 3 ? 2 : 6 - n;
  for (let k = 0; k < extraDefuse; k++) deck.push('defuse');
  for (let k = 0; k < n - 1; k++) deck.push('bomb');
  deck = rng.shuffle(deck);
  return { game: 'kittens', o, phase: 'play', players: ps, deck, discard: [], turn: rng.int(n), turnsLeft: 1, pending: null, favor: null, defuse: null, future: null, last: null, winner: null, fx: [], fxSeq: 0 };
}

const cur = s => s.players[s.turn];

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  if (!me.alive) return err('خرجت من اللعبة');

  if (a.type === 'nope') {
    if (s.phase !== 'nope' || !s.pending) return err('لا يوجد ما تقول له «لا!»');
    const k = me.hand.indexOf('nope');
    if (k < 0) return err('لا تملك بطاقة «لا!»');
    me.hand.splice(k, 1); s.discard.push('nope');
    s.pending.nopes++;
    s.pending.lastNope = pid;
    s.deadline = ctx.now + s.o.nopeSec * 1000;
    pushFx(s, { kind: 'nope', who: pid });
    return ok();
  }

  if (a.type === 'give') {
    if (s.phase !== 'favor' || s.favor.from !== i) return err('ليس دورك');
    const k = a.index;
    if (!Number.isInteger(k) || k < 0 || k >= me.hand.length) return err('اختر بطاقة');
    const card = me.hand.splice(k, 1)[0];
    s.players[s.favor.to].hand.push(card);
    s.privateGot = { to: s.players[s.favor.to].id, card };
    pushFx(s, { kind: 'steal' });
    s.favor = null; s.phase = 'play';
    return ok();
  }

  if (a.type === 'insert') {
    if (s.phase !== 'defuse' || i !== s.turn) return err('ليس دورك');
    const pos = a.position;
    if (!Number.isInteger(pos) || pos < 0 || pos > s.deck.length) return err('موضع غير صالح');
    s.deck.splice(pos, 0, 'bomb'); // الموضع 0 = أعلى الكومة
    s.phase = 'play';
    pushFx(s, { kind: 'defused' });
    return endOneTurn(s);
  }

  if (a.type === 'pickDiscard') {
    if (s.phase !== 'pickDiscard' || i !== s.turn) return err('ليس دورك');
    const k = s.discard.lastIndexOf(a.card);
    if (k < 0 || a.card === 'bomb') return err('غير موجودة في كومة المهملات');
    s.discard.splice(k, 1); me.hand.push(a.card);
    s.phase = 'play';
    return ok();
  }

  if (s.phase !== 'play') return err('انتظر');
  if (i !== s.turn) return err('ليس دورك');

  if (a.type === 'draw') {
    s.future = null;
    if (!s.deck.length) return err('الكومة فارغة');
    const c = s.deck.shift();
    if (c === 'bomb') {
      pushFx(s, { kind: 'bomb', who: pid });
      const d = me.hand.indexOf('defuse');
      if (d >= 0) {
        me.hand.splice(d, 1); s.discard.push('defuse');
        s.phase = 'defuse';
        return ok();
      }
      me.alive = false;
      s.discard.push(...me.hand, 'bomb'); me.hand = [];
      pushFx(s, { kind: 'exploded', who: pid });
      s.last = { type: 'exploded', who: pid };
      if (checkWin(s)) return ok();
      s.turnsLeft = 1;
      s.turn = nextAliveIdx(s.players, s.turn);
      return ok();
    }
    me.hand.push(c);
    s.privateGot = { to: pid, card: c };
    pushFx(s, { kind: 'draw', who: pid });
    return endOneTurn(s);
  }

  if (a.type === 'play') {
    const cards = Array.isArray(a.cards) ? a.cards : [a.card];
    if (!cards.length || cards.some(c => typeof c !== 'string')) return err('بطاقات غير صالحة');
    const handCopy = me.hand.slice();
    for (const c of cards) { const k = handCopy.indexOf(c); if (k < 0) return err('لا تملك هذه البطاقات'); handCopy.splice(k, 1); }
    let kind;
    if (cards.length === 1 && ACTIONS.includes(cards[0])) kind = cards[0];
    else if (cards.length === 2 && cards[0] === cards[1] && cards[0] !== 'defuse' && cards[0] !== 'nope') kind = 'pair';
    else if (cards.length === 3 && cards.every(c => c === cards[0]) && cards[0] !== 'defuse') kind = 'triple';
    else if (cards.length === 5 && new Set(cards).size === 5) kind = 'five';
    else return err('هذه المجموعة غير صالحة');
    let t = -1;
    if (['favor', 'pair', 'triple'].includes(kind)) {
      t = idxOf(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive) return err('اختر لاعبًا');
      if (s.players[t].hand.length === 0) return err('هذا اللاعب بلا بطاقات');
    }
    if (kind === 'triple' && typeof a.named !== 'string') return err('سمِّ البطاقة التي تريدها');
    if (kind === 'five' && !s.discard.some(c => c !== 'bomb')) return err('كومة المهملات فارغة');
    me.hand = handCopy;
    s.discard.push(...cards);
    s.pending = { kind, actor: i, target: t, named: a.named || null, nopes: 0, cards };
    s.phase = 'nope';
    s.deadline = ctx.now + s.o.nopeSec * 1000;
    pushFx(s, { kind: 'played', who: pid, card: kind });
    return ok();
  }
  return err('إجراء غير معروف');
}

export function tick(s, now, rng) {
  if (s.phase === 'nope' && s.deadline && now >= s.deadline) { resolvePending(s, rng); return true; }
  return false;
}

function resolvePending(s, rng) {
  const p = s.pending;
  s.pending = null; s.deadline = null; s.phase = 'play';
  const actor = s.players[p.actor];
  if (p.nopes % 2 === 1) { s.last = { type: 'noped', kind: p.kind }; pushFx(s, { kind: 'noped' }); return; }
  s.last = { type: 'played', kind: p.kind, who: actor.id, target: p.target >= 0 ? s.players[p.target].id : null };
  switch (p.kind) {
    case 'skip': endOneTurn(s); break;
    case 'attack': {
      s.turn = nextAliveIdx(s.players, s.turn);
      s.turnsLeft = 2; s.future = null;
      pushFx(s, { kind: 'attack' });
      break;
    }
    case 'shuffle':
      for (let k = s.deck.length - 1; k > 0; k--) { const j = rng.int(k + 1); [s.deck[k], s.deck[j]] = [s.deck[j], s.deck[k]]; }
      s.future = null; pushFx(s, { kind: 'shuffle' }); break;
    case 'future': s.future = { to: actor.id, cards: s.deck.slice(0, 3) }; pushFx(s, { kind: 'future', to: [actor.id] }); break;
    case 'favor': {
      const tg = s.players[p.target];
      if (!tg.alive || !tg.hand.length) break;
      s.favor = { from: p.target, to: p.actor }; s.phase = 'favor';
      break;
    }
    case 'pair': {
      const tg = s.players[p.target];
      if (!tg.hand.length) break;
      const k = rng.int(tg.hand.length);
      const card = tg.hand.splice(k, 1)[0];
      actor.hand.push(card);
      s.privateGot = { to: actor.id, card };
      pushFx(s, { kind: 'steal' });
      break;
    }
    case 'triple': {
      const tg = s.players[p.target];
      const k = tg.hand.indexOf(p.named);
      if (k >= 0) { actor.hand.push(tg.hand.splice(k, 1)[0]); s.last.got = true; pushFx(s, { kind: 'steal' }); }
      else { s.last.got = false; pushFx(s, { kind: 'miss' }); }
      break;
    }
    case 'five': s.phase = 'pickDiscard'; break;
  }
}

function endOneTurn(s) {
  s.future = null;
  s.turnsLeft--;
  if (s.turnsLeft <= 0) { s.turn = nextAliveIdx(s.players, s.turn); s.turnsLeft = 1; }
  return ok();
}

function checkWin(s) {
  const al = s.players.filter(p => p.alive);
  if (al.length === 1) { s.phase = 'over'; s.winner = al[0].id; pushFx(s, { kind: 'game-over', who: s.winner }); return true; }
  return false;
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  return {
    game: 'kittens', phase: s.phase, turn: cur(s).id, turnsLeft: s.turnsLeft, deck: s.deck.length,
    discardTop: s.discard.slice(-1)[0] || null, discardSet: s.phase === 'pickDiscard' && i === s.turn ? [...new Set(s.discard.filter(c => c !== 'bomb'))] : null,
    deadline: s.phase === 'nope' ? s.deadline : null,
    pending: s.pending ? { kind: s.pending.kind, actor: s.players[s.pending.actor].id, target: s.pending.target >= 0 ? s.players[s.pending.target].id : null, named: s.pending.named, nopes: s.pending.nopes, cards: s.pending.cards } : null,
    favorFrom: s.phase === 'favor' ? s.players[s.favor.from].id : null, favorTo: s.phase === 'favor' ? s.players[s.favor.to].id : null,
    players: s.players.map(p => ({ id: p.id, alive: p.alive, count: p.hand.length })),
    last: s.last, winner: s.winner,
    me: me ? {
      hand: me.hand.slice(), alive: me.alive,
      future: s.future && s.future.to === pid ? s.future.cards.slice() : null,
      got: s.privateGot && s.privateGot.to === pid ? s.privateGot.card : null,
    } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winners: [s.winner] }; }

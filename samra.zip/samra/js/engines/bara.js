// محرك "برا السالفة" — الجميع يعرف الكلمة إلا لاعبًا واحدًا يعرف التصنيف فقط
// نظام النقاط قابل للتهيئة لأن النسخ الشعبية تختلف (مُدرج في قائمة "تحتاج تحققًا")
import { pushFx, viewFx } from './fx.js';
import { BARA_CATEGORIES } from '../data/bara-words.js';

export const meta = {
  id: 'bara', minPlayers: 3, maxPlayers: 16,
  defaultOptions: {
    categoryId: 'random', rounds: 5, guessOptions: 8,
    score: { voteRight: 1, outsiderEscape: 2, outsiderGuess: 1 },
  },
};

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const s = {
    game: 'bara', o,
    phase: 'reveal', round: 0,
    players: players.map(p => ({ id: p.id, score: 0, seen: false, vote: null })),
    used: {},
    fx: [], fxSeq: 0,
  };
  startRound(s, rng);
  return s;
}

export function normalizeOptions(opt = {}) {
  const d = meta.defaultOptions;
  const rounds = clampInt(opt.rounds, 1, 20, d.rounds);
  const guessOptions = clampInt(opt.guessOptions, 4, 12, d.guessOptions);
  const categoryId = opt.categoryId === 'random' || BARA_CATEGORIES.some(c => c.id === opt.categoryId) ? opt.categoryId : 'random';
  const sc = opt.score || {};
  return {
    categoryId, rounds, guessOptions,
    score: {
      voteRight: clampInt(sc.voteRight, 0, 10, d.score.voteRight),
      outsiderEscape: clampInt(sc.outsiderEscape, 0, 10, d.score.outsiderEscape),
      outsiderGuess: clampInt(sc.outsiderGuess, 0, 10, d.score.outsiderGuess),
    },
  };
}

function clampInt(v, lo, hi, def) {
  return Number.isInteger(v) && v >= lo && v <= hi ? v : def;
}

function startRound(s, rng) {
  s.round++;
  const cat = s.o.categoryId === 'random' ? rng.pick(BARA_CATEGORIES) : BARA_CATEGORIES.find(c => c.id === s.o.categoryId);
  const used = s.used[cat.id] || (s.used[cat.id] = []);
  let pool = cat.words.filter(w => !used.includes(w));
  if (pool.length === 0) { s.used[cat.id] = []; pool = cat.words.slice(); }
  const word = rng.pick(pool);
  s.used[cat.id].push(word);
  const n = s.players.length;
  const order = rng.shuffle([...Array(n).keys()]);
  s.categoryId = cat.id;
  s.word = word;
  s.outsider = rng.int(n);
  s.pairs = order.map((a, k) => [a, order[(k + 1) % n]]);
  s.pairIndex = 0;
  const others = rng.shuffle(cat.words.filter(w => w !== word)).slice(0, s.o.guessOptions - 1);
  s.options = rng.shuffle([word, ...others]);
  s.guess = null;
  s.caught = null;
  s.tally = null;
  s.roundScores = null;
  s.phase = 'reveal';
  for (const p of s.players) { p.seen = false; p.vote = null; }
  pushFx(s, { kind: 'round-start' });
}

const idx = (s, pid) => s.players.findIndex(p => p.id === pid);

export function act(s, pid, a, ctx) {
  const i = idx(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  const me = s.players[i];
  switch (a.type) {
    case 'seen': {
      if (s.phase !== 'reveal') return err('ليست مرحلة كشف البطاقات');
      if (me.seen) return ok();
      me.seen = true;
      if (s.players.every(p => p.seen)) toQuestions(s);
      return ok();
    }
    case 'doneAsking': {
      if (s.phase !== 'questions') return err('ليست مرحلة الأسئلة');
      const [asker] = s.pairs[s.pairIndex];
      if (asker !== i && !ctx.isHost) return err('ليس دورك في السؤال');
      if (a.pairIndex !== s.pairIndex) return ok(); // ضغطة مكررة على سؤال انتهى
      s.pairIndex++;
      pushFx(s, { kind: 'tick' });
      if (s.pairIndex >= s.pairs.length) toVote(s);
      return ok();
    }
    case 'advance': {
      if (!ctx.isHost) return err('هذا الإجراء للمضيف فقط');
      if (s.phase === 'reveal') { toQuestions(s); return ok(); }
      if (s.phase === 'questions') { toVote(s); return ok(); }
      if (s.phase === 'vote') {
        if (!s.players.some(p => p.vote != null)) return err('لا توجد أصوات بعد');
        tally(s); return ok();
      }
      return err('لا يمكن التقدم الآن');
    }
    case 'vote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (me.vote != null) return err('صوّتّ بالفعل');
      const t = idx(s, a.target);
      if (t < 0 || t === i) return err('اختيار غير صالح');
      me.vote = t;
      pushFx(s, { kind: 'vote', who: pid });
      if (s.players.every(p => p.vote != null)) tally(s);
      return ok();
    }
    case 'guess': {
      if (s.phase !== 'guess') return err('ليست مرحلة التخمين');
      if (i !== s.outsider) return err('التخمين للاعب برا السالفة فقط');
      if (!s.options.includes(a.word)) return err('اختيار غير صالح');
      s.guess = a.word;
      score(s);
      return ok();
    }
    case 'next': {
      if (s.phase !== 'result') return err('الجولة لم تنتهِ');
      if (!ctx.isHost) return err('المضيف يبدأ الجولة التالية');
      if (s.round >= s.o.rounds) {
        s.phase = 'over';
        pushFx(s, { kind: 'game-over' });
        return ok();
      }
      startRound(s, ctx.rng);
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

function toQuestions(s) {
  s.phase = 'questions';
  s.pairIndex = 0;
  pushFx(s, { kind: 'phase' });
}

function toVote(s) {
  s.phase = 'vote';
  pushFx(s, { kind: 'phase' });
}

function tally(s) {
  const counts = new Array(s.players.length).fill(0);
  for (const p of s.players) if (p.vote != null) counts[p.vote]++;
  const max = Math.max(...counts);
  const top = counts.map((c, j) => j).filter(j => counts[j] === max);
  // يُمسك فقط إذا كان صاحب أعلى الأصوات منفردًا
  s.caught = top.length === 1 && top[0] === s.outsider;
  s.tally = counts;
  s.phase = 'guess';
  pushFx(s, { kind: s.caught ? 'caught' : 'escaped' });
}

function score(s) {
  const sc = s.o.score;
  const rs = {};
  s.players.forEach((p, j) => { rs[p.id] = 0; });
  s.players.forEach((p, j) => {
    if (j !== s.outsider && p.vote === s.outsider) rs[p.id] += sc.voteRight;
  });
  const out = s.players[s.outsider];
  if (!s.caught) rs[out.id] += sc.outsiderEscape;
  if (s.guess === s.word) rs[out.id] += sc.outsiderGuess;
  for (const p of s.players) p.score += rs[p.id];
  s.roundScores = rs;
  s.phase = 'result';
  pushFx(s, { kind: s.guess === s.word ? 'guess-right' : 'guess-wrong' });
  pushFx(s, { kind: 'score' });
}

export function view(s, pid) {
  const i = idx(s, pid);
  const cat = BARA_CATEGORIES.find(c => c.id === s.categoryId);
  const revealOutsider = ['guess', 'result', 'over'].includes(s.phase);
  const isOutsider = i === s.outsider;
  const showWord = s.phase === 'result' || s.phase === 'over' || (i >= 0 && !isOutsider);
  const pair = s.pairs[s.pairIndex];
  return {
    game: 'bara',
    phase: s.phase, round: s.round, rounds: s.o.rounds,
    category: { id: cat.id, name: cat.name, icon: cat.icon },
    me: i < 0 ? null : {
      role: isOutsider ? 'outsider' : 'insider',
      word: showWord ? s.word : null,
      seen: s.players[i].seen,
      vote: s.players[i].vote == null ? null : s.players[s.players[i].vote].id,
    },
    word: s.phase === 'result' || s.phase === 'over' ? s.word : null,
    pair: s.phase === 'questions' && pair ? { index: s.pairIndex, total: s.pairs.length, asker: s.players[pair[0]].id, answerer: s.players[pair[1]].id } : null,
    players: s.players.map(p => ({ id: p.id, score: p.score, seen: p.seen, voted: p.vote != null })),
    outsider: revealOutsider ? s.players[s.outsider].id : null,
    caught: revealOutsider ? s.caught : null,
    votes: revealOutsider ? s.players.map(p => ({ from: p.id, to: p.vote == null ? null : s.players[p.vote].id })) : null,
    options: s.phase === 'guess' && isOutsider ? s.options.slice() : null,
    guess: s.phase === 'result' || s.phase === 'over' ? s.guess : null,
    roundScores: s.roundScores,
    score: s.o.score,
    fx: viewFx(s, pid),
  };
}

export function summary(s) {
  const ranking = s.players.map(p => ({ id: p.id, score: p.score })).sort((a, b) => b.score - a.score);
  const best = ranking[0]?.score ?? 0;
  return { winners: ranking.filter(r => r.score === best).map(r => r.id), ranking };
}

const ok = () => ({ ok: true });
const err = e => ({ ok: false, error: e });

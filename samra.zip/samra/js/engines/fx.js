// سجل الأحداث المرئية/الصوتية — للعرض فقط ولا يؤثر على حالة اللعبة
// كل حدث له رقم تسلسلي؛ الواجهة تشغّل المؤثر مرة واحدة لكل رقم جديد.
const MAX_FX = 40;

export function pushFx(s, ev) {
  s.fxSeq = (s.fxSeq || 0) + 1;
  s.fx.push({ id: s.fxSeq, ...ev });
  if (s.fx.length > MAX_FX) s.fx.splice(0, s.fx.length - MAX_FX);
}

// الحدث الخاص (to) يصل فقط لأصحابه
export function viewFx(s, pid) {
  return s.fx
    .filter(e => !e.to || e.to.includes(pid))
    .map(({ to, ...rest }) => rest);
}

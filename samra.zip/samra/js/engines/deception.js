// محرك "الخداع" — الطبيب الشرعي يعرف الحل ويلمّح بالبلاطات فقط، والقاتل مخفي بين المحققين
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, bool } from './common.js';
import { MEANS, CLUES, CAUSE, LOCATIONS, SCENES } from '../data/deception-cards.js';

export const meta = { id: 'deception', minPlayers: 4, maxPlayers: 12, defaultOptions: { accomplice: true, witness: true, discussionSec: 180 } };
export const normalizeOptions = (o = {}) => ({
  accomplice: bool(o.accomplice, true), witness: bool(o.witness, true),
  discussionSec: [0, 120, 180, 240, 300].includes(o.discussionSec) ? o.discussionSec : 180,
});
export const optionSchema = () => [
  { key: 'accomplice', type: 'switch', label: 'الشريك (٦ لاعبين فأكثر)' },
  { key: 'witness', type: 'switch', label: 'الشاهد (٦ لاعبين فأكثر)' },
  { key: 'discussionSec', type: 'select', label: 'مدة كل جولة نقاش', options: [[0, 'بدون مؤقت'], [120, 'دقيقتان'], [180, '٣ دقائق'], [240, '٤ دقائق'], [300, '٥ دقائق']] },
];

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const n = players.length;
  const roles = ['forensic', 'murderer'];
  if (n >= 6 && o.accomplice) roles.push('accomplice');
  if (n >= 6 && o.witness) roles.push('witness');
  while (roles.length < n) roles.push('investigator');
  const dealt = rng.shuffle(roles);
  const means = rng.shuffle(MEANS.map((_, k) => k));
  const clues = rng.shuffle(CLUES.map((_, k) => k));
  const scenePool = rng.shuffle(SCENES.map((_, k) => k));
  const s = {
    game: 'deception', o, phase: 'roles',
    players: players.map((p, j) => ({ id: p.id, role: dealt[j], ready: false, badge: true, means: dealt[j] === 'forensic' ? [] : means.splice(0, 4), clues: dealt[j] === 'forensic' ? [] : clues.splice(0, 4) })),
    crime: null, location: rng.int(LOCATIONS.length),
    tiles: [{ kind: 'cause', mark: null }, { kind: 'loc', mark: null }, ...scenePool.splice(0, 4).map(k => ({ kind: 'scene', k, mark: null }))],
    scenePool, round: 1, replaced: false, deadline: null, guesses: [], solvedBy: null, winner: null, reason: null, witnessGuess: null,
    fx: [], fxSeq: 0,
  };
  return s;
}

const role = (s, r) => s.players.find(p => p.role === r);

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  const isF = me.role === 'forensic';
  switch (a.type) {
    case 'ready':
      if (s.phase !== 'roles') return err('ليست مرحلة الأدوار');
      me.ready = true;
      if (s.players.every(p => p.ready)) { s.phase = 'crime'; pushFx(s, { kind: 'night' }); }
      return ok();
    case 'commit': {
      if (s.phase !== 'crime' || me.role !== 'murderer') return err('القاتل فقط');
      if (!me.means.includes(a.means) || !me.clues.includes(a.clue)) return err('اختر من بطاقاتك');
      s.crime = { means: a.means, clue: a.clue };
      s.phase = 'scene';
      pushFx(s, { kind: 'committed' });
      return ok();
    }
    case 'mark': {
      if (s.phase !== 'scene' || !isF) return err('الطبيب الشرعي فقط');
      const t = s.tiles[a.tile];
      if (!t || !Number.isInteger(a.option) || a.option < 0 || a.option > 5) return err('اختيار غير صالح');
      if (s.round > 1 && a.tile !== s.newTile) return err('عدّل البلاطة الجديدة فقط');
      t.mark = a.option;
      return ok();
    }
    case 'publish': {
      if (s.phase !== 'scene' || !isF) return err('الطبيب الشرعي فقط');
      if (s.tiles.some(t => t.mark == null)) return err('ضع علامة على كل البلاطات');
      s.phase = 'discuss';
      s.deadline = s.o.discussionSec ? ctx.now + s.o.discussionSec * 1000 : null;
      pushFx(s, { kind: 'phase' });
      return ok();
    }
    case 'solve': {
      if (s.phase !== 'discuss' && s.phase !== 'scene') return err('ليس وقت الاتهام');
      if (isF) return err('الطبيب الشرعي لا يتهم');
      if (!me.badge) return err('استخدمت شارتك');
      const t = idxOf(s, a.target);
      if (t < 0 || t === i || s.players[t].role === 'forensic') return err('اختر متهمًا');
      const tp = s.players[t];
      if (!tp.means.includes(a.means) || !tp.clues.includes(a.clue)) return err('اختر وسيلة ودليلًا من بطاقات المتهم');
      me.badge = false;
      // القاتل وشريكه يستخدمون الشارة للتمويه فقط — اتهامهم لا يُحسب صحيحًا
      const right = tp.role === 'murderer' && a.means === s.crime.means && a.clue === s.crime.clue && !['murderer', 'accomplice'].includes(me.role);
      s.guesses.push({ by: pid, target: tp.id, means: a.means, clue: a.clue, right });
      pushFx(s, { kind: right ? 'solved' : 'wrong-guess' });
      if (right) {
        s.solvedBy = pid;
        if (role(s, 'witness')) { s.phase = 'witnessHunt'; s.deadline = null; return ok(); }
        return end(s, 'good', 'كُشف القاتل والأداة والدليل');
      }
      return ok();
    }
    case 'endRound': {
      if (s.phase !== 'discuss' || (!isF && !ctx.isHost)) return err('الطبيب الشرعي أو المضيف ينهي الجولة');
      return endRound(s, ctx);
    }
    case 'replace': {
      if (s.phase !== 'replace' || !isF) return err('الطبيب الشرعي فقط');
      const k = a.tile;
      if (!Number.isInteger(k) || k < 2 || k >= s.tiles.length) return err('استبدل بلاطة مشهد فقط');
      const nk = s.scenePool.pop();
      s.tiles[k] = { kind: 'scene', k: nk, mark: null };
      s.newTile = k;
      s.phase = 'scene';
      return ok();
    }
    case 'accuseWitness': {
      if (s.phase !== 'witnessHunt' || me.role !== 'murderer') return err('القاتل فقط يحاول كشف الشاهد');
      const t = idxOf(s, a.target);
      if (t < 0) return err('اختيار غير صالح');
      s.witnessGuess = a.target;
      if (s.players[t].role === 'witness') return end(s, 'evil', 'كشف القاتل الشاهد');
      return end(s, 'good', 'نجا الشاهد وكُشف القاتل');
    }
    default: return err('إجراء غير معروف');
  }
}

function endRound(s, ctx) {
  s.deadline = null;
  if (s.round >= 3) return end(s, 'evil', 'انتهت الجولات الثلاث دون كشف القاتل');
  s.round++;
  s.phase = 'replace';
  pushFx(s, { kind: 'phase' });
  return ok();
}

export function tick(s, now, rng) {
  if (s.phase === 'discuss' && s.deadline && now >= s.deadline) { endRound(s); return true; }
  return false;
}

function end(s, w, reason) { s.phase = 'over'; s.winner = w; s.reason = reason; s.deadline = null; pushFx(s, { kind: 'game-over' }); return ok(); }

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  const r = me?.role;
  let knows = null;
  if (r === 'forensic' || r === 'accomplice') knows = { murderer: role(s, 'murderer').id, accomplice: role(s, 'accomplice')?.id || null };
  if (r === 'murderer') knows = { accomplice: role(s, 'accomplice')?.id || null };
  if (r === 'witness') knows = { suspects: [role(s, 'murderer').id, role(s, 'accomplice')?.id].filter(Boolean).sort() };
  const tileView = t => {
    const def = t.kind === 'cause' ? CAUSE : t.kind === 'loc' ? LOCATIONS[s.location] : SCENES[t.k];
    return { title: def.title, options: def.options, mark: t.mark };
  };
  return {
    game: 'deception', phase: s.phase, round: s.round, deadline: s.deadline,
    tiles: s.phase === 'scene' && r !== 'forensic' ? s.tiles.map(t => ({ ...tileView(t), mark: s.round > 1 && t.mark != null && s.tiles.indexOf(t) !== s.newTile ? t.mark : null })) : s.tiles.map(tileView),
    newTile: s.round > 1 ? s.newTile : null,
    players: s.players.map(p => ({ id: p.id, forensic: p.role === 'forensic', badge: p.badge, ready: s.phase === 'roles' ? p.ready : undefined, means: p.means.map(k => MEANS[k]), meansIdx: p.means, clues: p.clues.map(k => CLUES[k]), cluesIdx: p.clues, role: over ? p.role : null })),
    guesses: s.guesses,
    crime: over || r === 'forensic' || r === 'murderer' || r === 'accomplice' ? (s.crime ? { means: MEANS[s.crime.means], clue: CLUES[s.crime.clue] } : null) : null,
    me: me ? { role: r, knows, badge: me.badge, ready: me.ready } : null,
    winner: s.winner, reason: s.reason, witnessGuess: s.witnessGuess, solvedBy: s.solvedBy,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winnerTeam: s.winner, winners: s.players.filter(p => (['murderer', 'accomplice'].includes(p.role)) === (s.winner === 'evil')).map(p => p.id) }; }

// محرك "عقلية القطيع" — الجميع يكتب إجابة، وأكبر مجموعة متفقة تأخذ النقاط
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf } from './common.js';
import { HERD_QUESTIONS } from '../data/herd-questions.js';

export const meta = { id: 'herd', minPlayers: 3, maxPlayers: 16, defaultOptions: { target: 8 } };
export const normalizeOptions = (o = {}) => ({ target: [5, 8, 10].includes(o.target) ? o.target : 8 });
export const optionSchema = () => [{ key: 'target', type: 'select', label: 'نقاط الفوز', options: [[5, '٥'], [8, '٨'], [10, '١٠']] }];

// توحيد الكتابة العربية لمطابقة الإجابات المتشابهة
export function norm(t) {
  return String(t || '').trim().toLowerCase()
    .replace(/[\u064B-\u0652\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/^ال/, '').replace(/\s+ال/g, ' ').replace(/[^\p{L}\p{N}]+/gu, '');
}

export function setup(players, options, rng) {
  const o = normalizeOptions(options);
  const s = { game: 'herd', o, players: players.map(p => ({ id: p.id, score: 0, answer: null })), deck: rng.shuffle(HERD_QUESTIONS.map((_, k) => k)), round: 0, cow: null, winner: null, fx: [], fxSeq: 0 };
  newRound(s, rng);
  return s;
}

function newRound(s, rng) {
  s.round++;
  if (!s.deck.length) s.deck = rng.shuffle(HERD_QUESTIONS.map((_, k) => k));
  s.q = s.deck.pop();
  s.players.forEach(p => { p.answer = null; });
  s.groups = null; s.result = null;
  s.phase = 'answer';
  pushFx(s, { kind: 'round-start' });
}

function group(s) {
  const map = new Map();
  s.players.forEach((p, j) => {
    if (p.answer == null) return;
    const k = norm(p.answer) || '—';
    if (!map.has(k)) map.set(k, { label: p.answer, members: [] });
    map.get(k).members.push(j);
  });
  s.groups = [...map.values()];
  s.phase = 'group';
  pushFx(s, { kind: 'phase' });
}

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  switch (a.type) {
    case 'answer': {
      if (s.phase !== 'answer') return err('ليست مرحلة الإجابة');
      if (me.answer != null) return err('أرسلت إجابتك');
      const t = typeof a.text === 'string' ? Array.from(a.text.replace(/[\u0000-\u001f<>]/g, '').trim()).slice(0, 30).join('') : '';
      if (!t) return err('اكتب إجابة');
      me.answer = t;
      pushFx(s, { kind: 'answered' });
      if (s.players.every(p => p.answer != null)) group(s);
      return ok();
    }
    case 'close':
      if (s.phase !== 'answer' || !ctx.isHost) return err('للمضيف فقط');
      if (!s.players.some(p => p.answer != null)) return err('لا توجد إجابات');
      group(s); return ok();
    case 'merge': {
      if (s.phase !== 'group' || !ctx.isHost) return err('المضيف فقط يدمج الإجابات');
      const { from, into } = a;
      if (!Number.isInteger(from) || !Number.isInteger(into) || from === into || !s.groups[from] || !s.groups[into]) return err('اختيار غير صالح');
      s.groups[into].members.push(...s.groups[from].members);
      s.groups.splice(from, 1);
      return ok();
    }
    case 'confirm': {
      if (s.phase !== 'group' || !ctx.isHost) return err('للمضيف فقط');
      const sizes = s.groups.map(g => g.members.length);
      const max = Math.max(...sizes);
      const top = s.groups.filter(g => g.members.length === max);
      const herd = top.length === 1 && max > 1 ? top[0] : null;
      if (herd) herd.members.forEach(j => { s.players[j].score++; });
      const singles = s.groups.filter(g => g.members.length === 1);
      let cowTo = null;
      if (singles.length === 1 && s.groups.length > 1) { cowTo = s.players[singles[0].members[0]].id; s.cow = cowTo; }
      s.result = { herd: herd ? herd.members.map(j => s.players[j].id) : [], cowTo };
      s.phase = 'result';
      pushFx(s, { kind: herd ? 'herd' : 'no-herd' });
      if (cowTo) pushFx(s, { kind: 'cow' });
      const winners = s.players.filter(p => p.score >= s.o.target && p.id !== s.cow);
      if (winners.length) { s.winner = winners.map(p => p.id); s.phase = 'over'; pushFx(s, { kind: 'game-over' }); }
      return ok();
    }
    case 'next':
      if (s.phase !== 'result' || !ctx.isHost) return err('المضيف ينتقل للسؤال التالي');
      newRound(s, ctx.rng); return ok();
    default: return err('إجراء غير معروف');
  }
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const showAns = s.phase !== 'answer';
  return {
    game: 'herd', phase: s.phase, round: s.round, question: HERD_QUESTIONS[s.q], target: s.o.target, cow: s.cow,
    players: s.players.map(p => ({ id: p.id, score: p.score, answered: p.answer != null, answer: showAns ? p.answer : null })),
    groups: showAns && s.groups ? s.groups.map(g => ({ label: g.label, members: g.members.map(j => s.players[j].id) })) : null,
    result: s.result, winner: s.winner,
    me: i >= 0 ? { answer: s.players[i].answer } : null,
    fx: viewFx(s, pid),
  };
}

export function summary(s) { return { winners: s.winner || [] }; }

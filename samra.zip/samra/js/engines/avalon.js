// محرك أفالون — مهمات، تصويت علني على الفريق، بطاقات مهمة سرية، ومرحلة الاغتيال
import { pushFx, viewFx } from './fx.js';
import { ok, err, idxOf, bool } from './common.js';

export const meta = { id: 'avalon', minPlayers: 5, maxPlayers: 10, defaultOptions: { percival: true, morgana: true, mordred: false, oberon: false } };

export const SIZES = { 5: [2, 3, 2, 3, 3], 6: [2, 3, 4, 3, 4], 7: [2, 3, 3, 4, 4], 8: [3, 4, 4, 5, 5], 9: [3, 4, 4, 5, 5], 10: [3, 4, 4, 5, 5] };
export const EVIL = { 5: 2, 6: 2, 7: 3, 8: 3, 9: 3, 10: 4 };
export const GOOD_ROLES = ['merlin', 'percival', 'servant'];
export const isEvil = r => ['assassin', 'morgana', 'mordred', 'oberon', 'minion'].includes(r);

export function normalizeOptions(o = {}) {
  const d = meta.defaultOptions;
  return { percival: bool(o.percival, d.percival), morgana: bool(o.morgana, d.morgana), mordred: bool(o.mordred, d.mordred), oberon: bool(o.oberon, d.oberon) };
}

export const optionSchema = () => [
  { key: 'percival', type: 'switch', label: 'برسيفال (يعرف ميرلين)' },
  { key: 'morgana', type: 'switch', label: 'مورغانا (تظهر كميرلين لبرسيفال)' },
  { key: 'mordred', type: 'switch', label: 'موردريد (مخفي عن ميرلين)' },
  { key: 'oberon', type: 'switch', label: 'أوبرون (شرير لا يعرف الأشرار)' },
];

export function setup(players, options, rng) {
  const n = players.length;
  const o = normalizeOptions(options);
  const evil = ['assassin'];
  if (o.morgana) evil.push('morgana');
  if (o.mordred) evil.push('mordred');
  if (o.oberon) evil.push('oberon');
  while (evil.length > EVIL[n]) evil.pop();
  while (evil.length < EVIL[n]) evil.push('minion');
  const good = ['merlin'];
  if (o.percival) good.push('percival');
  while (good.length + evil.length < n) good.push('servant');
  const roles = rng.shuffle([...good, ...evil]);
  const s = {
    game: 'avalon', o, phase: 'reveal',
    players: players.map((p, j) => ({ id: p.id, role: roles[j], ready: false, vote: null, card: null })),
    leader: rng.int(n), mission: 0, results: [], rejects: 0,
    team: [], lastVote: null, lastMission: null, winner: null, reason: null, assassinTarget: null,
    fx: [], fxSeq: 0,
  };
  return s;
}

const size = s => SIZES[s.players.length][s.mission];
const failsNeeded = s => (s.mission === 3 && s.players.length >= 7 ? 2 : 1);

export function act(s, pid, a, ctx) {
  const i = idxOf(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];
  switch (a.type) {
    case 'ready':
      if (s.phase !== 'reveal') return err('ليست مرحلة الأدوار');
      me.ready = true;
      if (s.players.every(p => p.ready)) { s.phase = 'propose'; pushFx(s, { kind: 'phase' }); }
      return ok();
    case 'propose': {
      if (s.phase !== 'propose') return err('ليست مرحلة اختيار الفريق');
      if (i !== s.leader) return err('القائد فقط يختار الفريق');
      const t = Array.isArray(a.team) ? [...new Set(a.team)] : [];
      if (t.length !== size(s)) return err(`الفريق يجب أن يكون ${size(s)} لاعبين`);
      if (t.some(id => idxOf(s, id) < 0)) return err('لاعب غير صالح');
      s.team = t;
      s.phase = 'vote';
      s.players.forEach(p => { p.vote = null; });
      pushFx(s, { kind: 'proposed' });
      return ok();
    }
    case 'vote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (me.vote != null) return err('صوّتّ بالفعل');
      if (a.value !== 'yes' && a.value !== 'no') return err('تصويت غير صالح');
      me.vote = a.value;
      pushFx(s, { kind: 'vote' });
      if (s.players.every(p => p.vote != null)) resolveVote(s);
      return ok();
    }
    case 'play': {
      if (s.phase !== 'mission') return err('ليست مرحلة المهمة');
      if (!s.team.includes(pid)) return err('لست في فريق المهمة');
      if (me.card) return err('لعبت بطاقتك بالفعل');
      if (a.card !== 'success' && a.card !== 'fail') return err('بطاقة غير صالحة');
      if (a.card === 'fail' && !isEvil(me.role)) return err('أهل الخير يلعبون «نجاح» دائمًا');
      me.card = a.card;
      if (s.team.every(id => s.players[idxOf(s, id)].card)) resolveMission(s, ctx);
      return ok();
    }
    case 'assassinate': {
      if (s.phase !== 'assassin') return err('ليست مرحلة الاغتيال');
      if (me.role !== 'assassin') return err('القاتل فقط');
      const t = idxOf(s, a.target);
      if (t < 0 || isEvil(s.players[t].role)) return err('اختر لاعبًا من أهل الخير');
      s.assassinTarget = a.target;
      if (s.players[t].role === 'merlin') end(s, 'evil', 'اغتيل ميرلين');
      else end(s, 'good', 'نجا ميرلين من الاغتيال');
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

function resolveVote(s) {
  const yes = s.players.filter(p => p.vote === 'yes').length;
  const approved = yes > s.players.length / 2;
  s.lastVote = { team: s.team.slice(), leader: s.players[s.leader].id, votes: s.players.map(p => ({ id: p.id, v: p.vote })), approved };
  pushFx(s, { kind: approved ? 'approved' : 'rejected' });
  if (approved) {
    s.rejects = 0;
    s.phase = 'mission';
    s.players.forEach(p => { p.card = null; });
    return;
  }
  s.rejects++;
  if (s.rejects >= 5) return end(s, 'evil', 'رُفضت خمسة فرق متتالية');
  s.leader = (s.leader + 1) % s.players.length;
  s.team = [];
  s.phase = 'propose';
}

function resolveMission(s, ctx) {
  const cards = s.team.map(id => s.players[idxOf(s, id)].card);
  const fails = cards.filter(c => c === 'fail').length;
  const success = fails < failsNeeded(s);
  s.results.push(success ? 'success' : 'fail');
  s.lastMission = { n: s.mission + 1, team: s.team.slice(), fails, success, needed: failsNeeded(s) };
  pushFx(s, { kind: success ? 'mission-success' : 'mission-fail' });
  const sc = s.results.filter(r => r === 'success').length;
  const fc = s.results.length - sc;
  s.mission++;
  s.team = [];
  if (fc >= 3) return end(s, 'evil', 'فشلت ثلاث مهمات');
  if (sc >= 3) { s.phase = 'assassin'; pushFx(s, { kind: 'phase' }); return; }
  s.leader = (s.leader + 1) % s.players.length;
  s.phase = 'propose';
}

function end(s, w, reason) {
  s.phase = 'over'; s.winner = w; s.reason = reason;
  pushFx(s, { kind: 'game-over' });
}

export function view(s, pid) {
  const i = idxOf(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  let knows = null;
  if (me) {
    const r = me.role;
    if (r === 'merlin') knows = { label: 'أشرار تعرفهم', ids: s.players.filter(p => isEvil(p.role) && p.role !== 'mordred').map(p => p.id) };
    else if (r === 'percival') knows = { label: 'أحدهما ميرلين والآخر قد يكون مورغانا', ids: s.players.filter(p => p.role === 'merlin' || p.role === 'morgana').map(p => p.id).sort() };
    else if (isEvil(r) && r !== 'oberon') knows = { label: 'شركاؤك في الشر', ids: s.players.filter(p => isEvil(p.role) && p.role !== 'oberon' && p.id !== pid).map(p => p.id) };
    // مرحلة الاغتيال: الأشرار يكشفون أنفسهم ويتشاورون علنًا (القاعدة الرسمية)، بمن فيهم أوبيرون
    if (s.phase === 'assassin' && isEvil(r)) knows = { label: 'فريق الشر (مكشوف للتشاور)', ids: s.players.filter(p => isEvil(p.role) && p.id !== pid).map(p => p.id) };
  }
  return {
    game: 'avalon', phase: s.phase, mission: s.mission, results: s.results.slice(),
    sizes: SIZES[s.players.length], twoFails: s.players.length >= 7,
    leader: s.players[s.leader].id, team: s.team.slice(), size: s.mission < 5 ? size(s) : null,
    rejects: s.rejects, lastVote: s.lastVote, lastMission: s.lastMission,
    players: s.players.map(p => ({
      id: p.id, ready: s.phase === 'reveal' ? p.ready : undefined,
      voted: s.phase === 'vote' ? p.vote != null : undefined,
      played: s.phase === 'mission' && s.team.includes(p.id) ? !!p.card : undefined,
      role: over ? p.role : null,
    })),
    me: me ? { role: me.role, evil: isEvil(me.role), knows, vote: me.vote, card: me.card, ready: me.ready } : null,
    winner: s.winner, reason: s.reason, assassinTarget: s.assassinTarget,
    fx: viewFx(s, pid),
  };
}

export function summary(s) {
  return { winnerTeam: s.winner, winners: s.players.filter(p => (s.winner === 'evil') === isEvil(p.role)).map(p => p.id) };
}

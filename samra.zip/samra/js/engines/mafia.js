// محرك المافيا — التطبيق يقوم بدور الراوي، والمضيف هو الحَكَم الوحيد على الحالة
import { pushFx, viewFx } from './fx.js';

export const meta = {
  id: 'mafia', minPlayers: 5, maxPlayers: 16,
  defaultOptions: {
    mafiaCount: 'auto', doctor: true, detective: true,
    firstNightKill: true, revealOnDeath: true,
    doctorSelf: true, doctorRepeat: false,
    discussionSec: 180,
  },
};

export const ROLES = {
  mafia: { team: 'mafia' },
  detective: { team: 'town' },
  doctor: { team: 'town' },
  civilian: { team: 'town' },
};

export function autoMafia(n) {
  if (n <= 6) return 1;
  if (n <= 9) return 2;
  if (n <= 12) return 3;
  return 4;
}

export function normalizeOptions(opt = {}, n = 5) {
  const d = meta.defaultOptions;
  const maxMafia = Math.max(1, Math.floor((n - 1) / 2));
  const bool = (v, def) => (typeof v === 'boolean' ? v : def);
  let mafiaCount = opt.mafiaCount;
  if (!(Number.isInteger(mafiaCount) && mafiaCount >= 1 && mafiaCount <= maxMafia)) mafiaCount = 'auto';
  const disc = Number.isInteger(opt.discussionSec) && opt.discussionSec >= 0 && opt.discussionSec <= 900 ? opt.discussionSec : d.discussionSec;
  return {
    mafiaCount,
    doctor: bool(opt.doctor, d.doctor),
    detective: bool(opt.detective, d.detective),
    firstNightKill: bool(opt.firstNightKill, d.firstNightKill),
    revealOnDeath: bool(opt.revealOnDeath, d.revealOnDeath),
    doctorSelf: bool(opt.doctorSelf, d.doctorSelf),
    doctorRepeat: bool(opt.doctorRepeat, d.doctorRepeat),
    discussionSec: disc,
  };
}

export function setup(players, options, rng) {
  const n = players.length;
  const o = normalizeOptions(options, n);
  const m = o.mafiaCount === 'auto' ? autoMafia(n) : o.mafiaCount;
  const roles = [];
  for (let k = 0; k < m; k++) roles.push('mafia');
  if (o.detective) roles.push('detective');
  if (o.doctor) roles.push('doctor');
  while (roles.length < n) roles.push('civilian');
  const dealt = rng.shuffle(roles);
  const s = {
    game: 'mafia', o,
    phase: 'roles', day: 0, night: 0,
    players: players.map((p, j) => ({ id: p.id, role: dealt[j], alive: true, ready: false, done: false, vote: null })),
    mafiaPicks: {}, mafiaTarget: null, doctorPick: null, detectivePick: null,
    lastDoctorTarget: null, investigations: [],
    lastNight: null, lastVote: null, deadline: null, winner: null,
    fx: [], fxSeq: 0,
  };
  return s;
}

const idx = (s, pid) => s.players.findIndex(p => p.id === pid);
const alive = s => s.players.filter(p => p.alive);
const aliveMafia = s => s.players.filter(p => p.alive && p.role === 'mafia');

export function act(s, pid, a, ctx) {
  const i = idx(s, pid);
  if (i < 0) return err('لست ضمن هذه اللعبة');
  if (!a || typeof a.type !== 'string') return err('إجراء غير صالح');
  if (s.phase === 'over') return err('انتهت اللعبة');
  const me = s.players[i];

  switch (a.type) {
    case 'ready': {
      if (s.phase !== 'roles') return err('ليست مرحلة الأدوار');
      me.ready = true;
      if (s.players.every(p => p.ready)) startNight(s);
      return ok();
    }
    case 'mafiaPick': {
      if (s.phase !== 'night') return err('ليس الليل');
      if (!me.alive || me.role !== 'mafia') return err('غير مسموح');
      if (!killAllowed(s)) return err('لا يوجد قتل في الليلة الأولى حسب الإعدادات');
      if (s.mafiaTarget != null) return err('اتفقت المافيا على الهدف');
      const t = idx(s, a.target);
      if (t < 0 || !s.players[t].alive || s.players[t].role === 'mafia') return err('هدف غير صالح');
      s.mafiaPicks[pid] = t;
      const am = aliveMafia(s);
      const picks = am.map(p => s.mafiaPicks[p.id]);
      if (picks.every(x => x === t)) {
        s.mafiaTarget = t;
        for (const p of am) p.done = true;
        pushFx(s, { kind: 'locked', to: am.map(p => p.id) });
      }
      return afterNightAction(s, ctx);
    }
    case 'protect': {
      if (s.phase !== 'night') return err('ليس الليل');
      if (!me.alive || me.role !== 'doctor') return err('غير مسموح');
      if (s.doctorPick != null) return err('اخترت بالفعل');
      const t = idx(s, a.target);
      if (t < 0 || !s.players[t].alive) return err('اختيار غير صالح');
      if (t === i && !s.o.doctorSelf) return err('لا يمكنك حماية نفسك حسب الإعدادات');
      if (t === s.lastDoctorTarget && !s.o.doctorRepeat) return err('لا يمكنك حماية نفس الشخص ليلتين متتاليتين');
      s.doctorPick = t;
      me.done = true;
      return afterNightAction(s, ctx);
    }
    case 'investigate': {
      if (s.phase !== 'night') return err('ليس الليل');
      if (!me.alive || me.role !== 'detective') return err('غير مسموح');
      if (s.detectivePick != null) return err('حققت بالفعل هذه الليلة');
      const t = idx(s, a.target);
      if (t < 0 || t === i || !s.players[t].alive) return err('اختيار غير صالح');
      s.detectivePick = t;
      s.investigations.push({ night: s.night, target: s.players[t].id, isMafia: s.players[t].role === 'mafia' });
      pushFx(s, { kind: 'investigated', to: [pid] });
      me.done = true;
      return afterNightAction(s, ctx);
    }
    case 'sleep': {
      if (s.phase !== 'night') return err('ليس الليل');
      if (!me.alive) return err('غير مسموح');
      // المواطن (أو المافيا في ليلة بلا قتل) يؤكد أنه نائم — لا أثر له على النتيجة
      if (me.role === 'civilian' || (me.role === 'mafia' && !killAllowed(s))) {
        me.done = true;
        return afterNightAction(s, ctx);
      }
      return err('لديك إجراء ليلي يجب تنفيذه');
    }
    case 'startVote': {
      if (s.phase !== 'day') return err('ليس النهار');
      if (!ctx.isHost) return err('المضيف يبدأ التصويت');
      toVote(s);
      return ok();
    }
    case 'vote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (!me.alive) return err('اللاعب الخارج لا يصوّت');
      if (me.vote != null) return err('صوّتّ بالفعل');
      if (a.target === 'skip') me.vote = 'skip';
      else {
        const t = idx(s, a.target);
        if (t < 0 || !s.players[t].alive || t === i) return err('اختيار غير صالح');
        me.vote = t;
      }
      pushFx(s, { kind: 'vote', who: pid });
      if (alive(s).every(p => p.vote != null)) resolveVote(s, ctx);
      return ok();
    }
    case 'closeVote': {
      if (s.phase !== 'vote') return err('ليست مرحلة التصويت');
      if (!ctx.isHost) return err('للمضيف فقط');
      resolveVote(s, ctx);
      return ok();
    }
    default: return err('إجراء غير معروف');
  }
}

const killAllowed = s => s.o.firstNightKill || s.night > 1;

function startNight(s) {
  s.night++;
  s.phase = 'night';
  s.deadline = null;
  s.mafiaPicks = {}; s.mafiaTarget = null; s.doctorPick = null; s.detectivePick = null;
  for (const p of s.players) { p.done = !p.alive; p.vote = null; }
  pushFx(s, { kind: 'night' });
}

function nightComplete(s) {
  return alive(s).every(p => p.done);
}

function afterNightAction(s, ctx) {
  if (!nightComplete(s)) return ok();
  let killed = null;
  if (killAllowed(s) && s.mafiaTarget != null && s.mafiaTarget !== s.doctorPick) {
    killed = s.mafiaTarget;
    s.players[killed].alive = false;
  }
  s.lastDoctorTarget = s.doctorPick;
  s.lastNight = { night: s.night, killed: killed == null ? null : s.players[killed].id };
  s.day++;
  s.phase = 'day';
  s.lastVote = null;
  pushFx(s, { kind: killed == null ? 'dawn-safe' : 'dawn-death' });
  if (checkWin(s)) return ok();
  s.deadline = s.o.discussionSec > 0 ? ctx.now + s.o.discussionSec * 1000 : null;
  return ok();
}

function toVote(s) {
  s.phase = 'vote';
  s.deadline = null;
  for (const p of s.players) p.vote = null;
  pushFx(s, { kind: 'phase' });
}

function resolveVote(s, ctx) {
  const counts = new Map();
  for (const p of alive(s)) if (p.vote != null) counts.set(p.vote, (counts.get(p.vote) || 0) + 1);
  let max = 0, top = [];
  for (const [k, c] of counts) { if (c > max) { max = c; top = [k]; } else if (c === max) top.push(k); }
  let eliminated = null;
  if (top.length === 1 && top[0] !== 'skip' && max > 0) {
    eliminated = top[0];
    s.players[eliminated].alive = false;
  }
  s.lastVote = {
    day: s.day,
    votes: alive(s).concat(eliminated != null ? [s.players[eliminated]] : [])
      .filter((p, j, arr) => arr.indexOf(p) === j)
      .map(p => ({ from: p.id, to: p.vote == null ? null : p.vote === 'skip' ? 'skip' : s.players[p.vote].id })),
    eliminated: eliminated == null ? null : s.players[eliminated].id,
  };
  pushFx(s, { kind: eliminated == null ? 'no-elim' : 'eliminated' });
  if (checkWin(s)) return;
  startNight(s);
}

function checkWin(s) {
  const m = aliveMafia(s).length;
  const t = alive(s).length - m;
  if (m === 0) s.winner = 'town';
  else if (m >= t) s.winner = 'mafia';
  if (s.winner) {
    s.phase = 'over';
    s.deadline = null;
    pushFx(s, { kind: 'game-over' });
    return true;
  }
  return false;
}

// المؤقت يديره المضيف فقط
export function tick(s, now) {
  if (s.phase === 'day' && s.deadline && now >= s.deadline) {
    toVote(s);
    return true;
  }
  return false;
}

export function view(s, pid) {
  const i = idx(s, pid);
  const me = i >= 0 ? s.players[i] : null;
  const over = s.phase === 'over';
  const showRole = p => over || (!p.alive && s.o.revealOnDeath);
  const v = {
    game: 'mafia', phase: s.phase, day: s.day, night: s.night,
    deadline: s.deadline, winner: s.winner,
    options: { revealOnDeath: s.o.revealOnDeath, doctorSelf: s.o.doctorSelf, doctorRepeat: s.o.doctorRepeat, killTonight: killAllowed(s) },
    players: s.players.map(p => ({
      id: p.id, alive: p.alive,
      ready: s.phase === 'roles' ? p.ready : undefined,
      voted: s.phase === 'vote' ? p.vote != null : undefined,
      role: showRole(p) ? p.role : null,
    })),
    nightDone: s.phase === 'night' ? alive(s).filter(p => p.done).length : null,
    nightTotal: s.phase === 'night' ? alive(s).length : null,
    lastNight: s.lastNight,
    lastVote: s.lastVote,
    counts: { mafia: s.players.filter(p => p.role === 'mafia').length, total: s.players.length },
    me: null,
    fx: viewFx(s, pid),
  };
  if (me) {
    const m = {
      role: me.role, alive: me.alive, ready: me.ready, done: me.done,
      vote: me.vote == null ? null : me.vote === 'skip' ? 'skip' : s.players[me.vote].id,
    };
    if (me.role === 'mafia') {
      m.team = s.players.filter(p => p.role === 'mafia').map(p => ({ id: p.id, alive: p.alive }));
      if (s.phase === 'night') {
        m.picks = Object.fromEntries(Object.entries(s.mafiaPicks).map(([k, t]) => [k, s.players[t].id]));
        m.locked = s.mafiaTarget == null ? null : s.players[s.mafiaTarget].id;
      }
    }
    if (me.role === 'detective') m.investigations = s.investigations.slice();
    if (me.role === 'doctor') {
      m.protected = s.phase === 'night' && s.doctorPick != null ? s.players[s.doctorPick].id : null;
      m.lastProtected = s.lastDoctorTarget == null ? null : s.players[s.lastDoctorTarget].id;
    }
    v.me = m;
  }
  return v;
}

export function summary(s) {
  return {
    winnerTeam: s.winner,
    winners: s.players.filter(p => ROLES[p.role].team === s.winner).map(p => p.id),
    ranking: s.players.map(p => ({ id: p.id, role: p.role, alive: p.alive })),
  };
}

const ok = () => ({ ok: true });
const err = e => ({ ok: false, error: e });

// نقطة الدخول: الموجّه والصفحات العامة
import { CATALOG, byId } from './games/catalog.js';
import { COVERS } from './ui/art.js';
import { apply as applySettings, profile } from './core/settings.js';
import { unlockAudio, play } from './core/audio.js';
import { esc, ar, avatar, toast, settingsSheet, profileSheet, closeSheet } from './ui/dom.js';
import {
  createRoom, joinRoom, resumeHost, savedHostRoom, forgetHostRoom, lastRoom,
  renderPlay, current, startTimerLoop, editProfile,
} from './ui/play.js';

const app = document.getElementById('app');
applySettings();
startTimerLoop();
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, unlockAudio, { once: true, passive: true }));

function setShell() {
  document.body.dataset.theme = 'shell';
  document.body.classList.remove('is-night');
  document.querySelector('.ambient-layer')?.remove();
  const m = document.querySelector('meta[name=theme-color]'); if (m) m.content = '#231b2e';
}

// ================= الرئيسية =================
function renderHome() {
  setShell();
  const host = savedHostRoom();
  const last = lastRoom();
  const cur = current();
  const p = profile.get();
  app.innerHTML = `<div class="page wide">
    <header class="topbar">
      <div class="title" style="font-size:20px;color:var(--ink-soft)">${p ? `${avatar(p, 'sm')}` : ''}</div>
      ${p ? `<button class="btn ghost small" id="h-prof">${esc(p.name)}</button>` : ''}
      <button class="icon-btn" id="h-set" aria-label="الإعدادات">⚙️</button>
    </header>
    <section class="hero">
      <h1 class="logo">سمرة</h1>
      <p class="tagline">ألعاب الجَمعة من جوالاتكم — غرفة وكود وتبدأ السالفة.</p>
      <form class="join-box" id="join-form" autocomplete="off">
        <label for="code" class="sr">كود الغرفة</label>
        <input id="code" class="input code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="------" aria-label="كود الغرفة من ٦ أرقام">
        <button class="btn" type="submit">انضم</button>
      </form>
      <p class="muted" style="font-size:14px;margin:8px 0 0">أو امسح رمز QR من جوال المضيف بالكاميرا مباشرة.</p>
    </section>
    ${cur && !cur.dead ? `<div class="banner warn"><div class="grow">أنت داخل غرفة <b dir="ltr">${esc(cur.code)}</b></div><a class="btn small" href="#/play">ارجع للغرفة</a></div>` : ''}
    ${!cur && host ? `<div class="banner warn"><div class="grow">غرفتك <b dir="ltr">${esc(host.code)}</b> (${esc(byId(host.room.gameId)?.name || '')}) محفوظة</div><button class="btn small" id="h-resume">استئناف</button><button class="btn ghost small" id="h-drop">حذف</button></div>` : ''}
    ${!cur && !host && last ? `<div class="banner"><div class="grow">آخر غرفة دخلتها: <b dir="ltr">${esc(last.code)}</b></div><button class="btn small" id="h-rejoin">العودة</button></div>` : ''}
    <h2 class="section-title">الألعاب</h2>
    <p class="muted" style="margin:0 0 8px">${CATALOG.every(g => g.status === 'ready') ? `${ar(CATALOG.length)} لعبة جاهزة — اختر لعبة وأنشئ غرفة.` : `${ar(CATALOG.filter(g => g.status === 'ready').length)} ألعاب جاهزة الآن، والبقية في المراحل القادمة.`}</p>
    <div class="library">
      ${CATALOG.map(g => `<button class="game-box" data-game="${g.id}" aria-label="${esc(g.name)}${g.status === 'soon' ? ' — قريبًا' : ''}">
        <div class="cover">${COVERS[g.id] ? COVERS[g.id]() : ''}</div>
        ${g.status === 'soon' ? '<span class="soon">قريبًا</span>' : ''}
        <div class="meta"><p class="gname" style="font-family:${fontFor(g.id)}">${esc(g.name)}</p><span class="gplayers">${esc(g.players.replace(/\d+/g, d => ar(d)))} لاعبين</span></div>
      </button>`).join('')}
    </div>
  </div>`;
  app.querySelector('#h-set').addEventListener('click', settingsSheet);
  app.querySelector('#h-prof')?.addEventListener('click', async () => { await profileSheet({ title: 'تعديل اسمي وصورتي' }); renderHome(); });
  app.querySelector('#join-form').addEventListener('submit', e => {
    e.preventDefault();
    const code = app.querySelector('#code').value.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g, '');
    if (code.length !== 6) { toast('الكود يتكون من ٦ أرقام', 'err'); play('shell', 'error'); return; }
    location.hash = '#/join/' + code;
  });
  app.querySelector('#h-resume')?.addEventListener('click', () => resumeHost());
  app.querySelector('#h-drop')?.addEventListener('click', () => { if (confirm('حذف الغرفة المحفوظة؟ سيخرج منها الجميع.')) { forgetHostRoom(); renderHome(); } });
  app.querySelector('#h-rejoin')?.addEventListener('click', () => joinRoom(last.code));
  app.querySelectorAll('[data-game]').forEach(b => b.addEventListener('click', () => { play('shell', 'tap'); location.hash = '#/g/' + b.dataset.game; }));
}

function fontFor(id) {
  return { mafia: "'Rakkas'", skull: "'Lalezar'", bara: "'Marhey'", avalon: "'Ruqaa'", werewolf: "'Rakkas'", deception: "'Rakkas'", shareef: "'Ruqaa'", kittens: "'Marhey'", herd: "'Marhey'", secret: "'Readex'", monopoly: "'Readex'" }[id] || "'Lalezar'";
}

// ================= صفحة اللعبة والشرح =================
function renderGame(id) {
  setShell();
  const g = byId(id);
  if (!g) return (location.hash = '#/');
  const cur = current();
  const r = g.rules;
  app.innerHTML = `<div class="page rules">
    <header class="topbar glass"><a class="icon-btn" href="#/" aria-label="رجوع">→</a><div class="title">${esc(g.name)}</div></header>
    <div class="cover-wide">${COVERS[g.id]?.() || ''}</div>
    <h1 class="h1" style="font-family:${fontFor(g.id)}">${esc(g.name)}</h1>
    <p class="soft" style="margin:4px 0">${esc(g.short)}</p>
    <p><span class="badge">${esc(g.players.replace(/\d+/g, d => ar(d)))} لاعبين</span></p>
    ${r ? `
      <h3>الهدف</h3><p>${esc(r.goal)}</p>
      <h3>${g.id === 'skull' ? 'الأقراص' : 'الأدوار'}</h3><ul>${r.roles.map(([n, d]) => `<li><b>${esc(n)}:</b> ${esc(d)}</li>`).join('')}</ul>
      <h3>مراحل اللعب</h3><ol style="padding-inline-start:22px">${r.phases.map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      <h3>النقاط</h3><p>${esc(r.scoring)}</p>
      <h3>الفوز والخسارة</h3><p>${esc(r.win)}</p>
      <h3>نصيحة للمبتدئ</h3><p>${esc(r.beginner)}</p>
      ${r.verify?.length ? `<h3>تحتاج تحققًا</h3><ul>${r.verify.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
      <div class="sticky-cta">${cur && !cur.dead ? `<a class="btn block" href="#/play">ارجع للغرفة</a>` : `<button class="btn block" id="g-create">أنشئ غرفة</button>`}</div>`
    : `<div class="panel" style="margin-top:16px"><p class="h2">قريبًا</p><p class="soft">هذه اللعبة مخطط لها في المراحل القادمة من المنصة، ولن تظهر كلعبة قابلة للعب قبل أن تُبنى قواعدها وتُختبر.</p></div>`}
  </div>`;
  app.querySelector('#g-create')?.addEventListener('click', () => createRoom(g.id));
}

// ================= الانضمام عبر الرابط/QR =================
function renderJoin(code) {
  setShell();
  const cur = current();
  if (cur && cur.code === code && !cur.dead) { location.hash = '#/play'; return; }
  const p = profile.get();
  app.innerHTML = `<div class="page">
    <header class="topbar"><a class="icon-btn" href="#/" aria-label="رجوع">→</a><div class="title">الانضمام لغرفة</div></header>
    <div class="panel code-card" style="margin-top:10px"><p class="soft" style="margin:0">كود الغرفة</p><div class="code-digits">${esc(code)}</div></div>
    <div class="panel" style="margin-top:14px">
      ${p ? `<div class="row">${avatar(p, 'lg')}<div class="grow" style="flex:1"><b style="font-size:20px">${esc(p.name)}</b><br><button class="btn ghost small" id="j-edit" style="margin-top:6px">تغيير الاسم أو الصورة</button></div></div>`
          : `<p class="soft" style="margin:0">اختر اسمك وصورتك قبل الدخول.</p>`}
    </div>
    <div class="sticky-cta"><button class="btn block" id="j-go">${p ? 'ادخل الغرفة' : 'اختر اسمك ثم ادخل'}</button></div>
  </div>`;
  app.querySelector('#j-edit')?.addEventListener('click', async () => { await profileSheet({ title: 'تعديل اسمي وصورتي' }); renderJoin(code); });
  app.querySelector('#j-go').addEventListener('click', () => joinRoom(code));
}

// ================= الموجّه =================
function route() {
  closeSheet();
  const h = location.hash || '#/';
  let m;
  if (h === '#/play') {
    if (!current()) {
      // بعد تحديث الصفحة: نعود تلقائيًا لنفس الغرفة ونفس المقعد
      if (savedHostRoom()) return resumeHost();
      const last = lastRoom();
      if (last && profile.get()) return joinRoom(last.code);
      location.hash = '#/'; return;
    }
    app.innerHTML = '';
    return renderPlay();
  }
  if ((m = h.match(/^#\/join\/(\d{6})$/))) return renderJoin(m[1]);
  if ((m = h.match(/^#\/g\/([a-z]+)$/))) return renderGame(m[1]);
  renderHome();
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', route);
route();

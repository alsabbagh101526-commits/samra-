// يبني نسخة «ملف واحد» من المنصة: dist/index.html يحوي الشيفرة والأنماط والخطوط والمكتبات.
// الاستخدام: npm i esbuild ثم: node tools/build-single.mjs
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = p => readFileSync(join(root, p), 'utf8');

// ١) الشيفرة: كل الوحدات في سكربت واحد
const js = await build({
  entryPoints: [join(root, 'js/app.js')],
  bundle: true, format: 'iife', write: false, charset: 'utf8',
  target: ['es2020'], legalComments: 'none',
  banner: { js: '"use strict";' },
});
const bundle = js.outputFiles[0].text;

// ٢) الأنماط مع الخطوط مضمّنة كبيانات
const fontData = file => 'data:font/woff2;base64,' + readFileSync(join(root, 'fonts', file)).toString('base64');
let css = ['css/base.css', 'css/cards.css', 'css/themes.css'].map(read).join('\n');
css = css.replace(/url\(\s*['"]?\.\.\/fonts\/([^'")]+)['"]?\s*\)/g, (_, f) => `url(${fontData(f)})`);

// داخل <script> لا يجوز ظهور </script أو <!-- كما هي
const safeJs = s => s.replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--');
const safeCss = s => s.replace(/<\/style/gi, '<\\/style');

let html = read('index.html');
const swap = (from, to) => {
  if (!html.includes(from)) throw new Error('لم أجد: ' + from);
  html = html.replace(from, () => to);
};
swap('<link rel="stylesheet" href="css/base.css">', `<style>\n${safeCss(css)}\n</style>`);
swap('  <link rel="stylesheet" href="css/cards.css">\n', '');
swap('  <link rel="stylesheet" href="css/themes.css">\n', '');
swap('<script src="vendor/peerjs.min.js"></script>', `<script>\n${safeJs(read('vendor/peerjs.min.js'))}\n</script>`);
swap('<script src="vendor/qrcode.js"></script>', `<script>\n${safeJs(read('vendor/qrcode.js'))}\n</script>`);
swap('<script type="module" src="js/app.js"></script>', `<script>\n${safeJs(bundle)}\n</script>`);

// تحقق: لا مراجع لملفات خارجية متبقية
const outer = html.replace(/<script>[\s\S]*?<\/script>/g, '').replace(/<style>[\s\S]*?<\/style>/g, '');
const leftovers = outer.match(/(?:src|href)="(?!data:|#|https?:)[^"]+"/g) || (/url\(\.\.\/fonts/.test(css) ? ['fonts in css'] : null);
if (leftovers) throw new Error('مراجع خارجية متبقية: ' + leftovers.join(', '));

mkdirSync(join(root, 'dist'), { recursive: true });
writeFileSync(join(root, 'dist/index.html'), html);
console.log('dist/index.html', (Buffer.byteLength(html) / 1024).toFixed(0) + ' KB');

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HostSession } from '../js/net/host-session.js';
import { ClientSession } from '../js/net/client-session.js';
import { localTransport, createLocalPair } from '../js/net/local-transport.js';
import { ENGINES } from '../js/engines/index.js';
import { PROTOCOL_VERSION } from '../js/net/protocol.js';

const wait = (ms = 5) => new Promise(r => setTimeout(r, ms));
const memStore = () => { const m = new Map(); return { get: k => m.get(k), set: (k, v) => m.set(k, JSON.parse(JSON.stringify(v))), remove: k => m.delete(k) }; };

async function makeRoom(gameId, nClients) {
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId });
  const hostClient = new ClientSession({ transport: localTransport(host, { local: true }), code: '123456', store: memStore(), profile: { name: 'المضيف', emoji: '👑' }, asHost: true });
  await hostClient.start(); await wait();
  const clients = [];
  for (let k = 0; k < nClients; k++) {
    const c = new ClientSession({ transport: localTransport(host, { local: false }), code: '123456', store: memStore(), profile: { name: 'لاعب' + k, emoji: '🦊' } });
    await c.start(); await wait();
    clients.push(c);
  }
  return { host, hostClient, clients, all: [hostClient, ...clients] };
}
const closeAll = r => { r.all.forEach(c => c.close()); r.host.stopTimer(); };

test('الغرفة: انضمام وتعقيم الاسم والإيموجي وصلاحيات المضيف', async () => {
  const r = await makeRoom('mafia', 4);
  const evil = new ClientSession({ transport: localTransport(r.host), code: '123456', store: memStore(), profile: { name: '<b>‮مخترق\u0000</b>' + 'x'.repeat(40), emoji: '💣' }, asHost: true });
  await evil.start(); await wait();
  const p = r.host.room.players.find(x => x.id === evil.playerId);
  assert.ok(!p.name.includes('<') && !p.name.includes('\u202e') && Array.from(p.name).length <= 18);
  assert.notEqual(p.emoji, '💣', 'الإيموجي من القائمة المسموحة فقط');
  assert.equal(p.isHost, false, 'لا يمكن لعميل بعيد أن يدّعي أنه المضيف');
  assert.equal(r.host.room.players.length, 6);
  const res = await r.clients[0].hostCmd('start');
  assert.equal(res.ok, false);
  const kick = await r.clients[0].hostCmd('kick', { target: r.clients[1].playerId });
  assert.equal(kick.ok, false);
  assert.equal((await r.hostClient.hostCmd('kick', { target: evil.playerId })).ok, true);
  await wait();
  assert.equal(evil.status, 'closed');
  assert.equal(r.host.room.players.length, 5);
  evil.close(); closeAll(r);
});

test('الغرفة: البدء يتطلب جاهزية الجميع، وكل لاعب يستلم دوره فقط', async () => {
  const r = await makeRoom('mafia', 5);
  let res = await r.hostClient.hostCmd('start');
  assert.equal(res.ok, false);
  for (const c of r.clients) await c.setReady(true);
  res = await r.hostClient.hostCmd('start');
  assert.equal(res.ok, true, res.error);
  await wait();
  const roles = r.host.room.game.state.players;
  for (const c of r.all) {
    const g = c.lastState.game;
    assert.equal(g.me.role, roles.find(p => p.id === c.playerId).role);
    for (const o of g.players) if (o.id !== c.playerId) assert.equal(o.role, null);
  }
  // لاعب جديد لا يدخل أثناء اللعب
  const late = new ClientSession({ transport: localTransport(r.host), code: '123456', store: memStore(), profile: { name: 'متأخر', emoji: '😎' } });
  await late.start(); await wait();
  assert.equal(late.status, 'rejected');
  late.close(); closeAll(r);
});

test('منع التكرار: نفس الطلب مرتين يُطبق مرة واحدة', async () => {
  const host = new HostSession({ engines: ENGINES, code: '1', gameId: 'skull' });
  const { client, host: hside } = createLocalPair({ local: true });
  host.attach(hside);
  const got = [];
  client.onMessage(m => got.push(m));
  client.send({ t: 'hello', v: PROTOCOL_VERSION, name: 'م', emoji: '👑', asHost: true });
  await wait();
  client.send({ t: 'ready', seq: 1, value: true });
  client.send({ t: 'ready', seq: 1, value: false }); // مكرر بنفس الرقم
  await wait();
  const acks = got.filter(m => m.t === 'ack');
  assert.equal(acks[1].dup, true);
  assert.equal(host.room.players[0].ready, true);
});

test('إعادة الاتصال: نفس اللاعب ونفس الدور، ولا يُحتسب صوت مرتين', async () => {
  const r = await makeRoom('bara', 3);
  for (const c of r.clients) await c.setReady(true);
  await r.hostClient.hostCmd('start'); await wait();
  const c0 = r.clients[0];
  const id0 = c0.playerId;
  const word0 = c0.lastState.game.me.word;
  // قطع الاتصال
  c0.conn.close(); await wait(20);
  assert.equal(r.host.room.players.find(p => p.id === id0).connected, false);
  await wait(1000); // إعادة المحاولة التلقائية
  assert.equal(c0.status, 'online');
  assert.equal(c0.playerId, id0);
  assert.equal(c0.lastState.game.me.word, word0);
  assert.equal(r.host.room.players.length, 4, 'لم يُنشأ لاعب جديد');
  // الوصول لمرحلة التصويت
  await r.hostClient.act({ type: 'advance' });
  await r.hostClient.act({ type: 'advance' });
  await wait();
  const target = r.all.find(c => c !== c0).playerId;
  const v1 = await c0.act({ type: 'vote', target });
  assert.equal(v1.ok, true);
  const v2 = await c0.act({ type: 'vote', target });
  assert.equal(v2.ok, false, 'الصوت الثاني مرفوض');
  const votes = r.host.room.game.state.players.filter(p => p.vote != null).length;
  assert.equal(votes, 1);
  closeAll(r);
});

test('استعادة المضيف بعد تحديث الصفحة: نفس الحالة ونفس اللاعبين', async () => {
  const r = await makeRoom('skull', 2);
  for (const c of r.clients) await c.setReady(true);
  await r.hostClient.hostCmd('start'); await wait();
  // كل لاعب يضع قرصًا
  for (const c of r.all) await c.act({ type: 'place', disc: 'rose' });
  await wait();
  const saved = r.host.serialize();
  closeAll(r);
  const host2 = new HostSession({ engines: ENGINES, restored: saved });
  assert.equal(host2.room.game.state.phase, 'turn');
  assert.ok(host2.room.players.every(p => !p.connected));
  const store = memStore();
  store.set('samra.session.123456', { token: saved.players[1].token, seq: 50 });
  const back = new ClientSession({ transport: localTransport(host2), code: '123456', store, profile: { name: 'x', emoji: '🦊' } });
  await back.start(); await wait();
  assert.equal(back.playerId, saved.players[1].id);
  assert.deepEqual(back.lastState.game.me.stack, ['rose']);
  back.close(); host2.stopTimer();
});

test('خروج لاعب في الغرفة يحذفه، وأثناء اللعب يبقى مقعده', async () => {
  const r = await makeRoom('bara', 3);
  await r.clients[2].leave(); await wait();
  assert.equal(r.host.room.players.length, 3);
  for (const c of r.clients.slice(0, 2)) await c.setReady(true);
  const late = new ClientSession({ transport: localTransport(r.host), code: '123456', store: memStore(), profile: { name: 'ج', emoji: '🐼' } });
  await late.start(); await wait(); await late.setReady(true);
  await r.hostClient.hostCmd('start'); await wait();
  await late.leave(); await wait();
  const p = r.host.room.players.find(x => x.name === 'ج');
  assert.ok(p && p.connected === false, 'المقعد محفوظ');
  assert.equal(r.host.room.status, 'playing', 'اللعبة مستمرة');
  closeAll(r);
});

test('المؤقت على المضيف ينقل المافيا للتصويت ويبث للجميع', async () => {
  let t = 1_000_000;
  const host = new HostSession({ engines: ENGINES, code: '9', gameId: 'mafia', now: () => t });
  const mk = (name, asHost) => new ClientSession({ transport: localTransport(host, { local: asHost }), code: '9', store: memStore(), profile: { name, emoji: '😎' }, asHost });
  const cs = [mk('h', true), mk('a'), mk('b'), mk('c'), mk('d')];
  for (const c of cs) { await c.start(); await wait(); }
  for (const c of cs.slice(1)) await c.setReady(true);
  await cs[0].hostCmd('setOptions', { options: { discussionSec: 30 } });
  await cs[0].hostCmd('start'); await wait();
  for (const c of cs) await c.act({ type: 'ready' });
  await wait();
  const st = host.room.game.state;
  for (const c of cs) {
    const p = st.players.find(x => x.id === c.playerId);
    const town = st.players.find(x => x.role !== 'mafia' && x.id !== c.playerId);
    if (p.role === 'mafia') await c.act({ type: 'mafiaPick', target: st.players.find(x => x.role === 'civilian').id });
    else if (p.role === 'doctor') await c.act({ type: 'protect', target: p.id });
    else if (p.role === 'detective') await c.act({ type: 'investigate', target: town.id });
    else await c.act({ type: 'sleep' });
  }
  await wait();
  assert.equal(st.phase, 'day');
  assert.equal(cs[1].lastState.game.deadline, t + 30000);
  t += 30000; host.tick(); await wait();
  for (const c of cs) assert.equal(c.lastState.game.phase, 'vote');
  cs.forEach(c => c.close()); host.stopTimer();
});

test('لا مقعد مكرر: hello مكرر على نفس الاتصال، أو إعادة محاولة قبل وصول الترحيب', async () => {
  const r = await makeRoom('herd', 1);
  const before = r.host.room.players.length;
  // نفس الاتصال يرسل hello مرتين
  const c = new ClientSession({ transport: localTransport(r.host), code: '123456', store: memStore(), profile: { name: 'سارة', emoji: '🦊' } });
  await c.start(); await wait();
  c.conn.send({ t: 'hello', v: PROTOCOL_VERSION, token: null, cid: c.cid, name: 'سارة', emoji: '🦊' });
  await wait();
  assert.equal(r.host.room.players.length, before + 1, 'hello الثاني لا ينشئ لاعبًا');
  // جهاز يعيد المحاولة على اتصال جديد دون رمز (ضاع الترحيب) لكن بنفس معرّف الجهاز
  const store = memStore();
  const d1 = new ClientSession({ transport: localTransport(r.host), code: '123456', store, profile: { name: 'فهد', emoji: '🦊' } });
  const cid = d1.cid;
  const d2 = new ClientSession({ transport: localTransport(r.host), code: '123456', store, profile: { name: 'فهد', emoji: '🦊' } });
  assert.equal(d2.cid, cid, 'معرّف الجهاز محفوظ');
  await d1.start(); await wait();
  d2.token = null; // محاكاة ضياع الترحيب
  await d2.start(); await wait();
  assert.equal(r.host.room.players.filter(p => p.name === 'فهد').length, 1);
  assert.equal(d1.playerId, d2.playerId);
  // بدء متوازٍ لا يفتح اتصالين
  const e = new ClientSession({ transport: localTransport(r.host), code: '123456', store: memStore(), profile: { name: 'ريم', emoji: '🦊' } });
  await Promise.all([e.start(), e.start()]); await wait();
  assert.equal(r.host.room.players.filter(p => p.name === 'ريم').length, 1);
  [c, d1, d2, e].forEach(x => x.close()); closeAll(r);
});

// ===== المرونة ضد الانقطاعات (أُضيفت بعد اكتشاف لاعب «منقطع للأبد» في اختبار المتصفح) =====
test('اتصال حيّ اعتبره المضيف مغلقًا يُعاد اعتماده عند أول رسالة', async () => {
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId: 'herd' });
  const { client, host: hside } = createLocalPair({ local: false });
  let closeFn = null;
  // نلتقط معالج الإغلاق لنطلقه يدويًا دون إغلاق القناة فعلًا (يحاكي error عابر)
  const fakeHost = { ...hside, onClose(f) { closeFn = f; } };
  host.attach(fakeHost);
  const got = [];
  client.onMessage(m => got.push(m));
  client.send({ t: 'hello', v: PROTOCOL_VERSION, name: 'سارة', emoji: '🦊', cid: 'c1' });
  await wait();
  const pid = got.find(m => m.t === 'welcome').id;
  closeFn();
  assert.equal(host.room.players.find(p => p.id === pid).connected, false);
  client.send({ t: 'ping', c: 1 });
  await wait();
  assert.equal(host.room.players.find(p => p.id === pid).connected, true, 'عاد متصلًا');
  assert.ok(got.some(m => m.t === 'pong'), 'تلقى ردًا');
  assert.equal(host.conns.get(pid), fakeHost);
});

test('اتصال قديم استُبدل بتبويب أحدث لا يتلقى ردًا على النبضة', async () => {
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId: 'herd' });
  const A = createLocalPair({ local: false }), B = createLocalPair({ local: false });
  const gotA = [], gotB = [];
  A.client.onMessage(m => gotA.push(m)); B.client.onMessage(m => gotB.push(m));
  host.attach(A.host);
  A.client.send({ t: 'hello', v: PROTOCOL_VERSION, name: 'سارة', emoji: '🦊', cid: 'same' });
  await wait();
  const tok = gotA.find(m => m.t === 'welcome').token;
  host.attach(B.host);
  B.client.send({ t: 'hello', v: PROTOCOL_VERSION, token: tok, name: 'سارة', emoji: '🦊', cid: 'same' });
  await wait();
  assert.ok(gotA.some(m => m.t === 'closed' && m.reason === 'replaced'));
  const before = gotA.length;
  try { A.client.send({ t: 'ping', c: 5 }); } catch {}
  await wait();
  assert.equal(gotA.slice(before).filter(m => m.t === 'pong').length, 0);
  assert.equal(host.room.players.length, 1, 'نفس المقعد');
});

test('الاتصال الصامت يُغلق، وتوقف صفحة المضيف نفسها لا يطرد أحدًا', async () => {
  let t = 1000;
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId: 'herd', now: () => t });
  const P = createLocalPair({ local: false });
  host.attach(P.host);
  P.client.onMessage(() => {});
  P.client.send({ t: 'hello', v: PROTOCOL_VERSION, name: 'فهد', emoji: '🦊', cid: 'x' });
  await wait();
  const p = host.room.players[0];
  host._lastLive = t;
  // المضيف كان متوقفًا ٦٠ ثانية: لا طرد
  t += 60000; host.checkLiveness(20000, 3000);
  assert.equal(p.connected, true);
  // فحوص منتظمة مع صمت اللاعب ٢١ ثانية: يُغلق
  for (let k = 0; k < 7; k++) { t += 3000; host.checkLiveness(20000, 3000); }
  assert.equal(p.connected, false);
  await wait();
});

test('اتصال فُتح بلا ترحيب من المضيف: العميل يعيد المحاولة بدل الانتظار للأبد', async () => {
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId: 'herd' });
  let n = 0;
  const transport = {
    async connect() {
      n++;
      if (n === 1) { // أول اتصال: قناة صمّاء لا ترد أبدًا
        return { local: false, send() {}, close() {}, onMessage() {}, onClose() {} };
      }
      return localTransport(host, { local: false }).connect();
    },
  };
  const c = new ClientSession({ transport, code: '123456', store: memStore(), profile: { name: 'نورة', emoji: '🦊' }, welcomeTimeoutMs: 40 });
  await c.start();
  await wait(1200); // مهلة الترحيب + أول خطوة إعادة محاولة (800ms)
  assert.equal(n, 2, 'أعاد المحاولة');
  assert.equal(c.status, 'online');
  assert.equal(host.room.players.length, 1);
  c.close();
});

test('wake(): بعد فشل الاتصال، عودة التطبيق للواجهة تعيد المحاولة فورًا', async () => {
  const host = new HostSession({ engines: ENGINES, code: '123456', gameId: 'herd' });
  let fail = true;
  const transport = { async connect() { if (fail) throw Object.assign(new Error('x'), { code: 'peer-timeout' }); return localTransport(host, { local: false }).connect(); } };
  const c = new ClientSession({ transport, code: '123456', store: memStore(), profile: { name: 'ريم', emoji: '🦊' } });
  c.lostSince = -1e9; // كأن المحاولات مستمرة منذ زمن: تتوقف مباشرة على «فشل»
  await c.start();
  assert.equal(c.status, 'failed');
  fail = false;
  c.wake();
  await wait(50);
  assert.equal(c.status, 'online');
  c.close();
});

test('عودة الجوال من النوم: اتصال صامت يُستبدل فورًا، واتصال سليم يبقى', async () => {
  const r = await makeRoom('herd', 1);
  const c = r.clients[0];
  const before = c.conn;
  c.wake(); // اتصال حديث: يبقى كما هو
  assert.equal(c.conn, before);
  c.lastHeard = c.now() - 30000; // كأن الجوال نام ٣٠ ثانية
  c.wake();
  await wait(1200);
  assert.equal(c.status, 'online');
  assert.notEqual(c.conn, before, 'اتصال جديد');
  assert.equal(r.host.room.players.length, 2, 'نفس المقعد بلا تكرار');
  closeAll(r);
});

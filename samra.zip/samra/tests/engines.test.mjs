import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRng } from '../js/core/rng.js';
import * as skull from '../js/engines/skull.js';
import * as bara from '../js/engines/bara.js';
import * as mafia from '../js/engines/mafia.js';

const mkPlayers = n => Array.from({ length: n }, (_, k) => ({ id: 'p' + k, name: 'لاعب ' + k, emoji: '😀' }));
const ctxOf = (rng, isHost = false, now = 0) => ({ rng, isHost, now });
const clone = o => JSON.parse(JSON.stringify(o));

// ===================== الجمجمة =====================
function skullCandidates(v, pid) {
  const c = [];
  for (const d of ['rose', 'skull']) c.push({ type: 'place', disc: d });
  for (let a = 1; a <= v.onTable; a++) c.push({ type: 'bid', amount: a });
  c.push({ type: 'pass' }, { type: 'revealOwn' });
  for (const p of v.players) c.push({ type: 'flip', target: p.id });
  c.push({ type: 'discard', disc: 'rose' }, { type: 'discard', disc: 'skull' }, { type: 'next' });
  return c;
}

function checkSkullSecrecy(s) {
  for (const p of s.players) {
    const v = skull.view(s, p.id);
    for (const o of v.players) {
      if (s.phase !== 'over') assert.equal(o.total, undefined, 'لا تُكشف مجموعة أقراص لاعب آخر');
      assert.equal(o.stack, undefined);
      const real = s.players.find(x => x.id === o.id);
      assert.equal(o.revealed.length, real.revealedCount);
    }
    if (v.me.lost) assert.equal(s.lostPrivate.to, p.id);
    const json = JSON.stringify(v.players);
    assert.ok(!json.includes('"stack"'));
  }
}

test('الجمجمة: 300 مباراة عشوائية تنتهي بفائز واحد مع حماية الأسرار', () => {
  for (let g = 0; g < 300; g++) {
    const rng = createRng(1000 + g);
    const n = 3 + (g % 4);
    const s = skull.setup(mkPlayers(n), {}, rng);
    let steps = 0;
    while (s.phase !== 'over') {
      assert.ok(++steps < 5000, 'المباراة لم تنتهِ');
      const p = s.players[rng.int(n)];
      const v = skull.view(s, p.id);
      const cands = rng.shuffle(skullCandidates(v, p.id));
      // نحد من المزايدات الكبيرة لكي لا تنتهي كل جولة فورًا
      for (const a of cands) {
        const r = skull.act(s, p.id, a, ctxOf(rng, rng.next() < 0.2));
        if (r.ok) break;
      }
      // ثوابت
      for (const pl of s.players) {
        assert.ok(pl.total.rose >= 0 && pl.total.rose <= 3);
        assert.ok(pl.total.skull >= 0 && pl.total.skull <= 1);
        assert.ok(pl.stack.length <= pl.total.rose + pl.total.skull || s.phase === 'roundEnd' || s.phase === 'discard' || s.phase === 'over');
        assert.ok(pl.wins <= 2);
      }
      checkSkullSecrecy(s);
    }
    const winners = s.players.filter(p => p.wins >= 2 || (p.alive && s.players.filter(x => x.alive).length === 1));
    assert.ok(winners.some(w => w.id === s.winner));
  }
});

function skullScenario() {
  const rng = createRng(7);
  const s = skull.setup(mkPlayers(3), {}, rng);
  s.starter = 0;
  return { s, rng };
}

test('الجمجمة: كشف الأقراص الخاصة أولًا ثم النجاح يمنح نقطة', () => {
  const { s, rng } = skullScenario();
  const c = ctxOf(rng);
  skull.act(s, 'p0', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p1', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p2', { type: 'place', disc: 'rose' }, c);
  assert.equal(s.phase, 'turn');
  assert.equal(skull.act(s, 'p1', { type: 'bid', amount: 2 }, c).ok, false, 'ليس دوره');
  assert.ok(skull.act(s, 'p0', { type: 'bid', amount: 2 }, c).ok);
  assert.equal(skull.act(s, 'p1', { type: 'bid', amount: 2 }, c).ok, false, 'يجب الرفع');
  assert.ok(skull.act(s, 'p1', { type: 'pass' }, c).ok);
  assert.ok(skull.act(s, 'p2', { type: 'pass' }, c).ok);
  assert.equal(s.phase, 'reveal');
  assert.equal(skull.act(s, 'p0', { type: 'flip', target: 'p1' }, c).ok, false, 'يجب كشف أقراصه أولًا');
  assert.ok(skull.act(s, 'p0', { type: 'revealOwn' }, c).ok);
  assert.ok(skull.act(s, 'p0', { type: 'flip', target: 'p1' }, c).ok);
  assert.equal(s.players[0].wins, 1);
  assert.equal(s.phase, 'roundEnd');
});

test('الجمجمة: جمجمة لاعب آخر = خسارة قرص عشوائي يعرفه المتحدي فقط', () => {
  const { s, rng } = skullScenario();
  const c = ctxOf(rng);
  skull.act(s, 'p0', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p1', { type: 'place', disc: 'skull' }, c);
  skull.act(s, 'p2', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p0', { type: 'bid', amount: 3 }, c); // يساوي عدد الأقراص = كشف فوري
  assert.equal(s.phase, 'reveal');
  skull.act(s, 'p0', { type: 'revealOwn' }, c);
  skull.act(s, 'p0', { type: 'flip', target: 'p1' }, c);
  assert.equal(s.result.type, 'fail');
  assert.equal(s.players[0].total.rose + s.players[0].total.skull, 3);
  assert.ok(skull.view(s, 'p0').me.lost);
  assert.equal(skull.view(s, 'p1').me.lost, null);
  assert.equal(skull.view(s, 'p2').me.lost, null);
  assert.equal(s.starter, 0, 'المتحدي يبدأ الجولة التالية');
});

test('الجمجمة: جمجمته هو = يختار القرص الذي يخسره', () => {
  const { s, rng } = skullScenario();
  const c = ctxOf(rng);
  skull.act(s, 'p0', { type: 'place', disc: 'skull' }, c);
  skull.act(s, 'p1', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p2', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p0', { type: 'bid', amount: 1 }, c);
  skull.act(s, 'p1', { type: 'pass' }, c);
  skull.act(s, 'p2', { type: 'pass' }, c);
  skull.act(s, 'p0', { type: 'revealOwn' }, c);
  assert.equal(s.phase, 'discard');
  assert.equal(skull.act(s, 'p1', { type: 'discard', disc: 'rose' }, c).ok, false);
  assert.ok(skull.act(s, 'p0', { type: 'discard', disc: 'skull' }, c).ok);
  assert.equal(s.players[0].total.skull, 0);
  assert.equal(s.phase, 'roundEnd');
});

test('الجمجمة: لا يمكن وضع قرص غير موجود في اليد', () => {
  const { s, rng } = skullScenario();
  const c = ctxOf(rng);
  assert.ok(skull.act(s, 'p0', { type: 'place', disc: 'skull' }, c).ok);
  skull.act(s, 'p1', { type: 'place', disc: 'rose' }, c);
  skull.act(s, 'p2', { type: 'place', disc: 'rose' }, c);
  assert.equal(skull.act(s, 'p0', { type: 'place', disc: 'skull' }, c).ok, false);
  assert.equal(skull.act(s, 'p0', { type: 'bid', amount: 99 }, c).ok, false);
});

// ===================== برا السالفة =====================
function playBaraRound(s, rng, voteForOutsider) {
  const host = ctxOf(rng, true);
  for (const p of s.players) assert.ok(bara.act(s, p.id, { type: 'seen' }, ctxOf(rng)).ok);
  assert.equal(s.phase, 'questions');
  while (s.phase === 'questions') {
    const asker = s.players[s.pairs[s.pairIndex][0]].id;
    assert.ok(bara.act(s, asker, { type: 'doneAsking', pairIndex: s.pairIndex }, ctxOf(rng)).ok);
  }
  assert.equal(s.phase, 'vote');
  const out = s.players[s.outsider].id;
  for (const p of s.players) {
    let target = voteForOutsider && p.id !== out ? out : s.players.find(x => x.id !== p.id && x.id !== out)?.id || s.players.find(x => x.id !== p.id).id;
    assert.ok(bara.act(s, p.id, { type: 'vote', target }, ctxOf(rng)).ok);
  }
  assert.equal(s.phase, 'guess');
  return host;
}

test('برا السالفة: السرية — اللاعب برا السالفة لا يستلم الكلمة', () => {
  const rng = createRng(3);
  const s = bara.setup(mkPlayers(5), {}, rng);
  const out = s.players[s.outsider].id;
  for (const p of s.players) {
    const v = bara.view(s, p.id);
    if (p.id === out) {
      assert.equal(v.me.word, null);
      assert.ok(!JSON.stringify(v).includes(s.word), 'الكلمة لا تظهر في بيانات اللاعب برا السالفة');
    } else {
      assert.equal(v.me.word, s.word);
      assert.equal(v.outsider, null, 'هوية اللاعب برا السالفة مخفية');
    }
    assert.equal(v.options, null);
  }
});

test('برا السالفة: احتساب النقاط والجولات وعدم تكرار التصويت', () => {
  const rng = createRng(11);
  const s = bara.setup(mkPlayers(4), { rounds: 2 }, rng);
  const out = s.players[s.outsider].id;
  const host = playBaraRound(s, rng, true);
  assert.equal(s.caught, true);
  const vOut = bara.view(s, out);
  assert.equal(vOut.options.length, 8);
  assert.equal(bara.view(s, s.players.find(p => p.id !== out).id).options, null);
  assert.equal(bara.act(s, s.players.find(p => p.id !== out).id, { type: 'guess', word: s.word }, ctxOf(rng)).ok, false);
  assert.ok(bara.act(s, out, { type: 'guess', word: s.word }, ctxOf(rng)).ok);
  for (const p of s.players) {
    const expect = p.id === out ? 1 /* تخمين صحيح، ومُسك */ : 1;
    assert.equal(p.score, expect);
  }
  assert.equal(bara.act(s, out, { type: 'next' }, ctxOf(rng)).ok, false, 'غير المضيف لا ينتقل');
  assert.ok(bara.act(s, out, { type: 'next' }, host).ok);
  assert.equal(s.round, 2);
  const out2 = s.players[s.outsider].id;
  playBaraRound(s, rng, false);
  assert.equal(s.caught, false);
  const wrong = s.options.find(w => w !== s.word);
  bara.act(s, out2, { type: 'guess', word: wrong }, ctxOf(rng));
  assert.equal(s.roundScores[out2], 2);
  bara.act(s, out2, { type: 'next' }, host);
  assert.equal(s.phase, 'over');
  const sum = bara.summary(s);
  assert.ok(sum.winners.length >= 1);
});

test('برا السالفة: لا يصوّت لنفسه ولا مرتين، والتعادل لا يُمسك', () => {
  const rng = createRng(5);
  const s = bara.setup(mkPlayers(4), {}, rng);
  bara.act(s, 'p0', { type: 'advance' }, ctxOf(rng, true));
  bara.act(s, 'p0', { type: 'advance' }, ctxOf(rng, true));
  assert.equal(s.phase, 'vote');
  assert.equal(bara.act(s, 'p1', { type: 'vote', target: 'p1' }, ctxOf(rng)).ok, false);
  assert.ok(bara.act(s, 'p1', { type: 'vote', target: 'p2' }, ctxOf(rng)).ok);
  assert.equal(bara.act(s, 'p1', { type: 'vote', target: 'p3' }, ctxOf(rng)).ok, false);
  // تعادل مقصود
  const out = s.outsider;
  s.players.forEach(p => { p.vote = null; });
  s.players.forEach((p, j) => { p.vote = (j + 1) % 4; });
  bara.act(s, 'p0', { type: 'advance' }, ctxOf(rng, true));
  assert.equal(s.caught, false, 'تعادل الأصوات لا يمسك اللاعب');
});

// ===================== المافيا =====================
function roleOf(s, role) { return s.players.filter(p => p.role === role); }

test('المافيا: توزيع الأدوار وسريتها', () => {
  for (const n of [5, 7, 10, 13, 16]) {
    const rng = createRng(n);
    const s = mafia.setup(mkPlayers(n), {}, rng);
    assert.equal(roleOf(s, 'mafia').length, mafia.autoMafia(n));
    assert.equal(roleOf(s, 'doctor').length, 1);
    assert.equal(roleOf(s, 'detective').length, 1);
    for (const p of s.players) {
      const v = mafia.view(s, p.id);
      assert.equal(v.me.role, p.role);
      for (const o of v.players) assert.equal(o.role, null, 'لا تُرسل أدوار الآخرين');
      if (p.role === 'mafia') assert.equal(v.me.team.length, roleOf(s, 'mafia').length);
      else assert.equal(v.me.team, undefined, 'غير المافيا لا يعرف المافيا');
      // بيانات المحقق والطبيب والمافيا لا تصل لغير أصحابها
      if (p.role !== 'detective') assert.equal(v.me.investigations, undefined);
      if (p.role !== 'mafia') assert.equal(v.me.picks, undefined);
    }
  }
});

function playNight(s, rng, { kill, protect, inv }) {
  const c = ctxOf(rng);
  for (const p of s.players.filter(p => p.alive)) {
    if (p.role === 'mafia') {
      const r = mafia.act(s, p.id, kill ? { type: 'mafiaPick', target: kill } : { type: 'sleep' }, c);
      assert.ok(r.ok, r.error);
    } else if (p.role === 'doctor') assert.ok(mafia.act(s, p.id, { type: 'protect', target: protect }, c).ok);
    else if (p.role === 'detective') assert.ok(mafia.act(s, p.id, { type: 'investigate', target: inv }, c).ok);
    else assert.ok(mafia.act(s, p.id, { type: 'sleep' }, c).ok);
  }
}

test('المافيا: الطبيب ينقذ، المحقق يعرف، التصويت يُقصي، وفوز المدينة', () => {
  const rng = createRng(42);
  const s = mafia.setup(mkPlayers(5), { discussionSec: 60 }, rng);
  for (const p of s.players) mafia.act(s, p.id, { type: 'ready' }, ctxOf(rng));
  assert.equal(s.phase, 'night');
  const maf = roleOf(s, 'mafia')[0];
  const doc = roleOf(s, 'doctor')[0];
  const det = roleOf(s, 'detective')[0];
  const civ = roleOf(s, 'civilian');
  assert.equal(mafia.act(s, maf.id, { type: 'mafiaPick', target: maf.id }, ctxOf(rng)).ok, false, 'المافيا لا تستهدف نفسها');
  playNight(s, rng, { kill: civ[0].id, protect: civ[0].id, inv: maf.id });
  assert.equal(s.phase, 'day');
  assert.equal(s.lastNight.killed, null, 'الطبيب أنقذ الهدف');
  assert.equal(mafia.view(s, det.id).me.investigations[0].isMafia, true);
  assert.equal(mafia.view(s, doc.id).me.investigations, undefined);
  // المؤقت
  assert.equal(mafia.tick(s, s.deadline - 1), false);
  assert.equal(mafia.tick(s, s.deadline), true);
  assert.equal(s.phase, 'vote');
  for (const p of s.players.filter(p => p.alive)) {
    const t = p.id === maf.id ? civ[0].id : maf.id;
    assert.ok(mafia.act(s, p.id, { type: 'vote', target: t }, ctxOf(rng)).ok);
  }
  assert.equal(s.winner, 'town');
  assert.equal(s.phase, 'over');
  for (const o of mafia.view(s, civ[0].id).players) assert.ok(o.role, 'كل الأدوار تُكشف في النهاية');
});

test('المافيا: لا حماية لنفس الشخص ليلتين، وفوز المافيا عند التكافؤ', () => {
  const rng = createRng(9);
  const s = mafia.setup(mkPlayers(5), { discussionSec: 0 }, rng);
  for (const p of s.players) mafia.act(s, p.id, { type: 'ready' }, ctxOf(rng));
  const maf = roleOf(s, 'mafia')[0];
  const doc = roleOf(s, 'doctor')[0];
  const det = roleOf(s, 'detective')[0];
  const civ = roleOf(s, 'civilian');
  playNight(s, rng, { kill: civ[0].id, protect: doc.id, inv: civ[1].id });
  assert.equal(s.lastNight.killed, civ[0].id);
  assert.equal(s.deadline, null, 'بدون مؤقت');
  assert.ok(mafia.act(s, 'p0', { type: 'startVote' }, ctxOf(rng, true)).ok);
  for (const p of s.players.filter(p => p.alive)) mafia.act(s, p.id, { type: 'vote', target: 'skip' }, ctxOf(rng));
  assert.equal(s.lastVote.eliminated, null);
  assert.equal(s.phase, 'night');
  assert.equal(mafia.act(s, doc.id, { type: 'protect', target: doc.id }, ctxOf(rng)).ok, false, 'لا تكرار ليلتين');
  playNight(s, rng, { kill: civ[1].id, protect: det.id, inv: maf.id });
  // بقي: مافيا + طبيب + محقق = 1 مقابل 2 → تستمر
  assert.equal(s.winner, null);
  mafia.act(s, 'p0', { type: 'startVote' }, ctxOf(rng, true));
  mafia.act(s, maf.id, { type: 'vote', target: det.id }, ctxOf(rng));
  mafia.act(s, doc.id, { type: 'vote', target: det.id }, ctxOf(rng));
  mafia.act(s, det.id, { type: 'vote', target: maf.id }, ctxOf(rng));
  assert.equal(s.lastVote.eliminated, det.id);
  assert.equal(s.winner, 'mafia');
});

test('المافيا: مافيا متعددة يجب أن تتفق على هدف واحد', () => {
  const rng = createRng(77);
  const s = mafia.setup(mkPlayers(8), {}, rng);
  for (const p of s.players) mafia.act(s, p.id, { type: 'ready' }, ctxOf(rng));
  const [m1, m2] = roleOf(s, 'mafia');
  const town = s.players.filter(p => p.role !== 'mafia');
  mafia.act(s, m1.id, { type: 'mafiaPick', target: town[0].id }, ctxOf(rng));
  mafia.act(s, m2.id, { type: 'mafiaPick', target: town[1].id }, ctxOf(rng));
  assert.equal(s.mafiaTarget, null);
  assert.equal(mafia.view(s, m1.id).me.picks[m2.id], town[1].id, 'المافيا ترى اختيار زميلها');
  assert.equal(mafia.view(s, town[0].id).me.picks, undefined, 'غير المافيا لا يرى الاختيارات');
  mafia.act(s, m1.id, { type: 'mafiaPick', target: town[1].id }, ctxOf(rng));
  assert.equal(s.mafiaTarget, s.players.indexOf(town[1]));
});

test('المافيا: 300 مباراة عشوائية تنتهي بفائز صحيح وبلا كشف أدوار ولا جمود', () => {
  const types = ['ready', 'mafiaPick', 'protect', 'investigate', 'sleep', 'vote', 'startVote', 'closeVote'];
  const hasLegal = s => {
    for (const p of s.players) for (const t of types) for (const tg of s.players.map(x => x.id).concat('skip')) {
      const c = clone(s);
      if (mafia.act(c, p.id, { type: t, target: tg }, ctxOf(createRng(1), true, 0)).ok) return true;
    }
    return false;
  };
  for (let g = 0; g < 300; g++) {
    const rng = createRng(500 + g);
    const n = 5 + (g % 12);
    const s = mafia.setup(mkPlayers(n), { firstNightKill: g % 2 === 0, discussionSec: 0 }, rng);
    let steps = 0;
    while (s.phase !== 'over') {
      steps++;
      if (steps % 400 === 0) assert.ok(hasLegal(s), 'جمود: لا يوجد إجراء قانوني');
      assert.ok(steps < 200000, 'لم تنتهِ');
      const p = s.players[rng.int(n)];
      let target = rng.pick(s.players.map(x => x.id).concat(['skip']));
      // المافيا تميل لاتباع اختيار زميلها لمحاكاة الاتفاق
      const firstPick = Object.values(s.mafiaPicks)[0];
      if (p.role === 'mafia' && firstPick != null && rng.next() < 0.7) target = s.players[firstPick].id;
      mafia.act(s, p.id, { type: rng.pick(types), target }, ctxOf(rng, rng.next() < 0.1, steps));
      if (steps % 7 === 0) for (const q of s.players) {
        const v = mafia.view(s, q.id);
        for (const o of v.players) {
          const real = s.players.find(x => x.id === o.id);
          if (s.phase !== 'over' && real.alive && o.id !== q.id) assert.equal(o.role, null);
        }
      }
    }
    const m = s.players.filter(p => p.alive && p.role === 'mafia').length;
    const t = s.players.filter(p => p.alive).length - m;
    if (s.winner === 'town') assert.equal(m, 0);
    else assert.ok(m >= t);
  }
});

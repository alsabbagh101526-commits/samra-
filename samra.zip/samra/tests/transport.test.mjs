// اختبار تقسيم الرسائل الكبيرة في طبقة PeerJS (حد PeerJS لرسائل JSON هو 16300 بايت)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { wrap } from '../js/net/peer-transport.js';

// قناة وهمية تحاكي DataConnection: تُحوّل الرسالة JSON كما يفعل PeerJS وترفض الكبير
function fakePair() {
  const mk = () => ({ h: {}, open: true, sent: [], on(ev, f) { (this.h[ev] ||= []).push(f); }, emit(ev, x) { (this.h[ev] || []).forEach(f => f(x)); } });
  const a = mk(), b = mk();
  const link = (me, other) => {
    me.send = m => {
      const bytes = Buffer.byteLength(JSON.stringify(m));
      me.sent.push(bytes);
      if (bytes >= 16300) { me.emit('error', new Error('Message too big for JSON channel')); return; }
      const copy = JSON.parse(JSON.stringify(m));
      other.emit('data', copy);
    };
    me.close = () => { me.open = false; other.open = false; me.emit('close'); other.emit('close'); };
  };
  link(a, b); link(b, a);
  return [a, b];
}

test('رسالة كبيرة (عربي + إيموجي) تصل كاملة وكل جزء تحت حد PeerJS', () => {
  const [da, db] = fakePair();
  const A = wrap(da), B = wrap(db);
  const got = [];
  B.onMessage(m => got.push(m));
  const big = { t: 'state', log: Array.from({ length: 900 }, (_, k) => `سطر رقم ${k} — «اقتباس» 😎👑 "علامات" \\ \n`) };
  A.send(big);
  assert.equal(got.length, 1);
  assert.deepEqual(got[0], big);
  assert.ok(Math.max(...da.sent) < 16300, 'أكبر جزء: ' + Math.max(...da.sent));
  assert.ok(da.sent.length > 3, 'قُسّمت فعلًا');
  // الرسائل الصغيرة تمر كما هي
  A.send({ t: 'ping', c: 1 });
  assert.deepEqual(got[1], { t: 'ping', c: 1 });
});

test('حدث error مع بقاء القناة مفتوحة لا يُعتبر إغلاقًا', () => {
  const [da] = fakePair();
  const A = wrap(da);
  let closed = 0;
  A.onClose(() => closed++);
  da.emit('error', new Error('عابر'));
  assert.equal(closed, 0);
  da.open = false; da.emit('error', new Error('مغلقة'));
  da.emit('close');
  assert.equal(closed, 1, 'مرة واحدة فقط');
});

test('أجزاء تالفة أو عدائية تُتجاهل دون انهيار', () => {
  const [da, db] = fakePair();
  const B = wrap(db);
  const got = [];
  B.onMessage(m => got.push(m));
  da.send({ t: '~', id: 1, i: 5, n: 2, d: 'x' });
  da.send({ t: '~', id: 2, i: 0, n: 1e9, d: 'x' });
  da.send({ t: '~', id: 3, i: 0, n: 1, d: '{bad json' });
  assert.equal(got.length, 0);
});

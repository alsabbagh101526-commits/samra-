// اختبارات الألعاب الـ12 الإضافية: مباريات عشوائية + ثوابت + سرية
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRng } from '../js/core/rng.js';
import { ENGINES } from '../js/engines/index.js';

const mk = n => Array.from({ length: n }, (_, k) => ({ id: 'p' + k, isHost: k === 0 }));
const clone = o => JSON.parse(JSON.stringify(o));

// مولّد إجراءات مرشحة عشوائية لكل لعبة (للاختبار فقط)
function cands(game, s, pid, rng) {
  const ids = s.players.map(p => p.id);
  const any = () => rng.pick(ids);
  const L = [];
  const push = (...a) => L.push(...a);
  switch (game) {
    case 'avalon': push({ type: 'ready' }, { type: 'propose', team: rng.shuffle(ids).slice(0, s.players.length >= 8 ? 3 + rng.int(3) : 2 + rng.int(3)) }, { type: 'vote', value: rng.pick(['yes', 'no', 'yes']) }, { type: 'play', card: rng.pick(['success', 'fail']) }, { type: 'assassinate', target: any() }); break;
    case 'werewolf': {
      const firstPick = Object.values(s.wolfPicks || {})[0];
      const t = firstPick != null && rng.next() < .7 ? s.players[firstPick].id : any();
      push({ type: 'ready' }, { type: 'wolfPick', target: t }, { type: 'see', target: any() }, { type: 'witch', heal: rng.next() < .3, poison: rng.next() < .2 ? any() : null }, { type: 'sleep' }, { type: 'shoot', target: rng.next() < .2 ? 'none' : any() }, { type: 'vote', target: rng.next() < .2 ? 'skip' : any() }, { type: 'startVote' }, { type: 'closeVote' });
      break;
    }
    case 'coup': push(...['income', 'foreign_aid', 'coup', 'tax', 'assassinate', 'steal', 'exchange'].map(t => ({ type: t, target: any() })), { type: 'allow' }, { type: 'allow' }, { type: 'challenge' }, { type: 'block', card: rng.pick(['duke', 'contessa', 'captain', 'ambassador']) }, { type: 'lose', index: rng.int(2) }, { type: 'keep', indices: rng.shuffle([0, 1, 2, 3]).slice(0, 1 + rng.int(2)) }); break;
    case 'secret': push({ type: 'ready' }, { type: 'nominate', target: any() }, { type: 'vote', value: rng.pick(['ja', 'ja', 'nein']) }, { type: 'discard', index: rng.int(3) }, { type: 'enact', index: rng.int(2) }, { type: 'veto' }, { type: 'vetoAnswer', accept: rng.next() < .5 }, { type: 'peekDone' }, { type: 'investigate', target: any() }, { type: 'invDone' }, { type: 'special', target: any() }, { type: 'kill', target: any() }); break;
    case 'kittens': {
      const me = s.players.find(p => p.id === pid);
      const h = me.hand;
      const c = rng.pick(h.length ? h : ['skip']);
      push({ type: 'draw' }, { type: 'draw' }, { type: 'play', card: c, target: any() }, { type: 'play', cards: [c, c], target: any() }, { type: 'play', cards: [c, c, c], target: any(), named: rng.pick(['defuse', 'skip', 'cat1']) }, { type: 'nope' }, { type: 'give', index: rng.int(Math.max(1, h.length)) }, { type: 'insert', position: rng.int(s.deck.length + 1) }, { type: 'pickDiscard', card: rng.pick(s.discard.length ? s.discard : ['skip']) });
      break;
    }
    case 'wavelength': push({ type: 'clue', text: 'تلميح' }, { type: 'dial', value: rng.int(101) }, { type: 'lock' }, { type: 'side', value: rng.pick(['left', 'right']) }, { type: 'next' }); break;
    case 'herd': push({ type: 'answer', text: rng.pick(['أحمر', 'الاحمر', 'أزرق', 'أخضر', 'قهوة']) }, { type: 'close' }, { type: 'merge', from: rng.int(3), into: rng.int(3) }, { type: 'confirm' }, { type: 'next' }); break;
    case 'letters': push({ type: 'pick', cell: rng.int(25) }, { type: 'buzz' }, { type: 'judge', correct: rng.next() < .6 }, { type: 'skip' }, { type: 'nextBoard' }); break;
    case 'familyfeud': push({ type: 'buzz' }, { type: 'judge', index: rng.int(8) - 1 }, { type: 'choose', value: rng.pick(['play', 'pass']) }, { type: 'next' }, { type: 'revealAll' }); break;
    case 'deception': {
      const pl = rng.pick(s.players);
      push({ type: 'ready' }, { type: 'commit', means: rng.pick(pl.means.length ? pl.means : [0]), clue: rng.pick(pl.clues.length ? pl.clues : [0]) }, { type: 'mark', tile: rng.int(6), option: rng.int(6) }, { type: 'publish' }, { type: 'solve', target: pl.id, means: rng.pick(pl.means.length ? pl.means : [0]), clue: rng.pick(pl.clues.length ? pl.clues : [0]) }, { type: 'endRound' }, { type: 'replace', tile: 2 + rng.int(4) }, { type: 'accuseWitness', target: any() });
      break;
    }
    case 'shareef': {
      const me = s.players.find(p => p.id === pid);
      const n = me.hand.length;
      push({ type: 'market', discard: rng.shuffle([...Array(n).keys()]).slice(0, rng.int(4)) }, { type: 'load', cards: rng.shuffle([...Array(n).keys()]).slice(0, 1 + rng.int(Math.min(5, Math.max(1, n)))), declare: rng.pick(['apple', 'cheese', 'bread', 'chicken']) }, { type: 'offer', gold: rng.int(8) }, { type: 'pass' }, { type: 'inspect' }, { type: 'next' });
      break;
    }
    case 'monopoly': {
      const owned = Object.keys(s.props).map(Number).filter(k => s.props[k].owner === pid);
      const sq = rng.pick(owned.length ? owned : [1]);
      push({ type: 'roll' }, { type: 'roll' }, { type: 'buy' }, { type: 'decline' }, { type: 'endTurn' }, { type: 'endTurn' }, { type: 'payJail' }, { type: 'build', sq }, { type: 'build', sq }, { type: 'mortgage', sq }, { type: 'unmortgage', sq }, { type: 'sellHouse', sq }, { type: 'bid', amount: (s.auction?.high || 0) + 1 + rng.int(40) }, { type: 'passBid' }, { type: 'payDebt' }, { type: 'bankrupt' }, { type: 'answerTrade', accept: rng.next() < .5 });
      if (rng.next() < .03) push({ type: 'proposeTrade', to: any(), give: { cash: rng.int(50), props: owned.slice(0, 1) }, get: { cash: 0, props: [] } });
      break;
    }
  }
  return rng.shuffle(L);
}

export const MAXV = {};
function playRandom(game, n, seed, { maxSteps = 60000, checkView } = {}) {
  const eng = ENGINES[game];
  const rng = createRng(seed);
  const s = eng.setup(mk(n), {}, rng);
  let now = 1e6, steps = 0, idle = 0;
  while (s.phase !== 'over') {
    steps++;
    if (steps > maxSteps) throw new Error(`${game} n=${n} seed=${seed}: لم تنتهِ — phase=${s.phase}`);
    now += 700;
    let acted = false;
    if (eng.tick && eng.tick(s, now, rng)) acted = true;
    const p = s.players[rng.int(n)];
    for (const a of cands(game, s, p.id, rng)) {
      const r = eng.act(s, p.id, a, { rng, now, isHost: p.id === 'p0' || rng.next() < .05 });
      if (r.ok) { acted = true; break; }
    }
    idle = acted ? 0 : idle + 1;
    if (idle > 3000) throw new Error(`${game} n=${n} seed=${seed}: جمود في phase=${s.phase}`);
    if (checkView && steps % 5 === 0) for (const q of s.players) { const v = eng.view(s, q.id); checkView(s, q.id, v); const b = Buffer.byteLength(JSON.stringify(v)); if (b > (MAXV[game] || 0)) MAXV[game] = b; }
  }
  // الحالة قابلة للتسلسل (لحفظ غرفة المضيف)
  assert.deepEqual(clone(s), s);
  return s;
}

const RUNS = { avalon: [5, 10], werewolf: [6, 12], coup: [2, 6], secret: [5, 10], kittens: [2, 5], wavelength: [4, 8], herd: [3, 8], letters: [3, 7], familyfeud: [3, 8], deception: [4, 9], shareef: [3, 5], monopoly: [2, 4] };

for (const [game, [lo, hi]] of Object.entries(RUNS)) {
  test(`${game}: مباريات عشوائية تنتهي بلا أخطاء ولا جمود`, () => {
    const games = game === 'monopoly' ? 25 : 80;
    for (let g = 0; g < games; g++) {
      const n = lo + (g % (hi - lo + 1));
      const s = playRandom(game, n, 9000 + g * 7, { checkView: SECRECY[game] });
      assert.equal(s.phase, 'over');
    }
  });
}

// ===== فحوص السرية =====
const SECRECY = {
  avalon(s, pid, v) {
    const me = s.players.find(p => p.id === pid);
    if (s.phase !== 'over') v.players.forEach(p => assert.equal(p.role, null));
    if (me.role === 'servant' || (me.role === 'oberon' && s.phase !== 'assassin')) assert.equal(v.me.knows, null);
    if (s.phase === 'assassin' && !['assassin', 'morgana', 'mordred', 'oberon', 'minion'].includes(me.role) && me.role !== 'merlin' && me.role !== 'percival') assert.equal(v.me.knows, null);
    if (s.phase === 'vote') v.players.forEach(p => assert.equal(typeof p.voted, 'boolean'));
    assert.ok(!JSON.stringify(v.players).includes('"card"'));
  },
  werewolf(s, pid, v) {
    if (s.phase !== 'over') v.players.forEach(p => { if (p.id !== pid && s.players.find(x => x.id === p.id).alive) assert.equal(p.role, null); });
    const me = s.players.find(p => p.id === pid);
    if (me.role !== 'seer') assert.equal(v.me.seen, undefined);
    if (me.role !== 'witch') assert.equal(v.me.victim, undefined);
  },
  coup(s, pid, v) {
    v.players.forEach(p => { if (p.id !== pid && s.phase !== 'over') p.cards.forEach(c => { if (!c.dead) assert.equal(c.c, null); }); });
    if (v.me.exchange) assert.equal(s.players[s.pend.actor].id, pid);
  },
  secret(s, pid, v) {
    const me = s.players.find(p => p.id === pid);
    if (s.phase !== 'over') v.players.forEach(p => assert.equal(p.role, null));
    if (me.role === 'liberal') assert.equal(v.me.knows, null);
    if (me.role === 'hitler' && s.players.length > 6) assert.equal(v.me.knows, null);
    if (v.me.hand) assert.ok(s.players[s.president].id === pid || s.players[s.chancellor].id === pid);
    assert.ok(!('deckOrder' in v));
  },
  kittens(s, pid, v) {
    assert.ok(!('deckCards' in v));
    assert.ok(!JSON.stringify(v.players).includes('hand'));
    if (v.me.future) assert.equal(s.future.to, pid);
  },
  wavelength(s, pid, v) { if (!['reveal', 'over'].includes(s.phase) && pid !== s.psychic) assert.equal(v.targetPos, null); },
  herd(s, pid, v) { if (s.phase === 'answer') v.players.forEach(p => assert.equal(p.answer, null)); },
  letters() {},
  familyfeud(s, pid, v) { if (pid !== s.host) v.answers.forEach((a, k) => { if (!s.revealed[k]) assert.equal(a.text, null); }); },
  deception(s, pid, v) {
    const me = s.players.find(p => p.id === pid);
    if (s.phase !== 'over') v.players.forEach(p => assert.equal(p.role, null));
    if (['investigator', 'witness'].includes(me.role) && s.phase !== 'over') assert.equal(v.crime, null);
  },
  shareef(s, pid, v) {
    v.players.forEach(p => { if (p.id !== pid && s.phase !== 'over') { assert.equal(p.stand.pepper, undefined); assert.equal(p.bag, undefined); } });
  },
  monopoly() {},
};

// ===== قواعد محددة =====
const ctx = (rng, now = 0, isHost = false) => ({ rng, now, isHost });

test('أفالون: عدد الأشرار وأحجام المهمات وفشلان في المهمة الرابعة', () => {
  const A = ENGINES.avalon;
  for (const n of [5, 6, 7, 8, 9, 10]) {
    const s = A.setup(mk(n), {}, createRng(n));
    assert.equal(s.players.filter(p => A.isEvil(p.role)).length, A.EVIL[n]);
    assert.ok(s.players.some(p => p.role === 'merlin') && s.players.some(p => p.role === 'assassin'));
  }
  const rng = createRng(3);
  const s = A.setup(mk(7), {}, rng);
  s.players.forEach(p => A.act(s, p.id, { type: 'ready' }, ctx(rng)));
  s.mission = 3; // المهمة الرابعة
  const team = s.players.slice(0, 4).map(p => p.id);
  const evil = s.players.filter(p => A.isEvil(p.role));
  A.act(s, s.players[s.leader].id, { type: 'propose', team: [evil[0].id, ...s.players.filter(p => !A.isEvil(p.role)).slice(0, 3).map(p => p.id)] }, ctx(rng));
  s.players.forEach(p => A.act(s, p.id, { type: 'vote', value: 'yes' }, ctx(rng)));
  assert.equal(s.phase, 'mission');
  const good = s.players.find(p => !A.isEvil(p.role) && s.team.includes(p.id));
  assert.equal(A.act(s, good.id, { type: 'play', card: 'fail' }, ctx(rng)).ok, false, 'الخيّر لا يلعب فشل');
  s.team.forEach(id => { const p = s.players.find(x => x.id === id); A.act(s, id, { type: 'play', card: A.isEvil(p.role) ? 'fail' : 'success' }, ctx(rng)); });
  assert.equal(s.lastMission.success, true, 'فشل واحد لا يكفي في المهمة الرابعة مع ٧ لاعبين');
});

test('الانقلاب: تحدٍّ صادق يفقد المتحدي نفوذًا ويبدّل بطاقة المدّعي', () => {
  const C = ENGINES.coup;
  const rng = createRng(5);
  const s = C.setup(mk(3), {}, rng);
  s.turn = 0;
  s.players[0].cards = [{ c: 'duke', dead: false }, { c: 'contessa', dead: false }];
  assert.ok(C.act(s, 'p0', { type: 'tax' }, ctx(rng)).ok);
  assert.equal(s.phase, 'respond');
  assert.ok(C.act(s, 'p1', { type: 'challenge' }, ctx(rng)).ok);
  assert.equal(s.lastChallenge.truthful, true);
  if (s.phase === 'lose') C.act(s, 'p1', { type: 'lose', index: 0 }, ctx(rng));
  assert.equal(s.players[1].cards.filter(c => c.dead).length, 1);
  assert.equal(s.players[0].coins, 5);
  // ١٠ عملات = انقلاب إجباري
  s.turn = 0; s.phase = 'action'; s.players[0].coins = 10;
  assert.equal(C.act(s, 'p0', { type: 'income' }, ctx(rng)).ok, false);
});

test('الانقلاب: صدّ السرقة بالقبطان ثم كشف خداع الصاد', () => {
  const C = ENGINES.coup;
  const rng = createRng(8);
  const s = C.setup(mk(2), {}, rng);
  s.turn = 0;
  s.players[1].cards = [{ c: 'duke', dead: false }, { c: 'duke', dead: false }];
  C.act(s, 'p0', { type: 'steal', target: 'p1' }, ctx(rng));
  C.act(s, 'p1', { type: 'allow' }, ctx(rng));
  assert.equal(s.pend.stage, 'block');
  C.act(s, 'p1', { type: 'block', card: 'captain' }, ctx(rng));
  C.act(s, 'p0', { type: 'challenge' }, ctx(rng));
  assert.equal(s.lastChallenge.truthful, false);
  if (s.phase === 'lose') C.act(s, 'p1', { type: 'lose', index: 0 }, ctx(rng));
  assert.equal(s.players[0].coins, 4, 'السرقة تمت بعد فشل الصد');
});

test('هتلر السري: انتخاب هتلر بعد ٣ قوانين فاشية = فوز الفاشيين', () => {
  const H = ENGINES.secret;
  const rng = createRng(2);
  const s = H.setup(mk(7), {}, rng);
  s.players.forEach(p => H.act(s, p.id, { type: 'ready' }, ctx(rng)));
  s.fas = 3;
  const hitler = s.players.find(p => p.role === 'hitler');
  if (s.players[s.president].id === hitler.id) s.president = (s.president + 1) % 7;
  s.lastGov = { p: null, c: null };
  assert.ok(H.act(s, s.players[s.president].id, { type: 'nominate', target: hitler.id }, ctx(rng)).ok);
  s.players.forEach(p => H.act(s, p.id, { type: 'vote', value: 'ja' }, ctx(rng)));
  assert.equal(s.winner, 'fascist');
});

test('هتلر السري: ثلاث حكومات فاشلة = تشريع القانون الأعلى', () => {
  const H = ENGINES.secret;
  const rng = createRng(4);
  const s = H.setup(mk(5), {}, rng);
  s.players.forEach(p => H.act(s, p.id, { type: 'ready' }, ctx(rng)));
  for (let k = 0; k < 3; k++) {
    const pres = s.players[s.president].id;
    H.act(s, pres, { type: 'nominate', target: s.players.find(p => p.id !== pres && s.players.indexOf(p) !== s.lastGov.c).id }, ctx(rng));
    s.players.forEach(p => H.act(s, p.id, { type: 'vote', value: 'nein' }, ctx(rng)));
  }
  assert.equal(s.lib + s.fas, 1);
  assert.equal(s.tracker, 0);
});

test('القطط المتفجرة: «لا!» تلغي الفعل و«لا!» الثانية تعيده', () => {
  const K = ENGINES.kittens;
  const rng = createRng(1);
  const s = K.setup(mk(3), { nopeSec: 3 }, rng);
  s.turn = 0;
  s.players[0].hand = ['skip', 'nope'];
  s.players[1].hand = ['nope'];
  const before = s.turn;
  K.act(s, 'p0', { type: 'play', card: 'skip' }, ctx(rng, 0));
  K.act(s, 'p1', { type: 'nope' }, ctx(rng, 1000));
  K.act(s, 'p0', { type: 'nope' }, ctx(rng, 2000));
  assert.equal(K.tick(s, 4000, rng), false, 'المهلة تُمدد بعد كل «لا!»');
  assert.equal(K.tick(s, 5001, rng), true);
  assert.notEqual(s.turn, before, 'التخطي نُفّذ بعد إلغاء الإلغاء');
});

test('القطط المتفجرة: سحب القطة مع بطاقة إبطال = إعادتها للكومة', () => {
  const K = ENGINES.kittens;
  const rng = createRng(2);
  const s = K.setup(mk(2), {}, rng);
  s.turn = 0; s.deck.unshift('bomb');
  const d0 = s.players[0].hand.filter(c => c === 'defuse').length;
  const deckLen = s.deck.length;
  K.act(s, 'p0', { type: 'draw' }, ctx(rng));
  assert.equal(s.phase, 'defuse');
  K.act(s, 'p0', { type: 'insert', position: 0 }, ctx(rng));
  assert.equal(s.deck[0], 'bomb');
  assert.equal(s.deck.length, deckLen);
  assert.equal(s.players[0].hand.filter(c => c === 'defuse').length, d0 - 1);
  assert.equal(s.turn, 1);
});

test('الطول الموجي: النقاط حسب المسافة ونقطة الطرف الآخر', () => {
  const W = ENGINES.wavelength;
  assert.equal(W.points(0), 4); assert.equal(W.points(10), 3); assert.equal(W.points(15), 2); assert.equal(W.points(30), 0);
  const rng = createRng(6);
  const s = W.setup(mk(4), {}, rng);
  const psy = s.psychic;
  const mate = s.teams[s.active].find(x => x !== psy);
  const opp = s.teams[s.active === 'A' ? 'B' : 'A'][0];
  assert.equal(W.view(s, mate).targetPos, null);
  W.act(s, psy, { type: 'clue', text: 'قهوة' }, ctx(rng));
  W.act(s, mate, { type: 'dial', value: s.targetPos }, ctx(rng));
  W.act(s, mate, { type: 'lock' }, ctx(rng));
  W.act(s, opp, { type: 'side', value: 'left' }, ctx(rng));
  assert.equal(s.result.pts, 4);
  assert.equal(s.result.sidePt, 0);
});

test('عقلية القطيع: توحيد الكتابة والأغلبية والبقرة', () => {
  const H = ENGINES.herd;
  assert.equal(H.norm('الأحمر'), H.norm('احمر'));
  assert.equal(H.norm('قهوة'), H.norm('قهوه'));
  const rng = createRng(1);
  const s = H.setup(mk(5), {}, rng);
  ['أحمر', 'الاحمر', 'أحمر', 'أزرق', 'أخضر'].forEach((t, k) => H.act(s, 'p' + k, { type: 'answer', text: t }, ctx(rng)));
  assert.equal(s.phase, 'group');
  H.act(s, 'p0', { type: 'confirm' }, ctx(rng, 0, true));
  assert.deepEqual(s.players.map(p => p.score), [1, 1, 1, 0, 0]);
  assert.equal(s.cow, null, 'إجابتان منفردتان = لا بقرة');
});

test('تحدي الحروف: كشف المسار المتصل', () => {
  const L = ENGINES.letters;
  const own = Array(25).fill(null);
  [0, 5, 10, 15, 20].forEach(k => { own[k] = 'A'; });
  // العمود الأول عموديًا: الصفوف الزوجية والفردية متجاورة عبر الإزاحة
  assert.equal(L.connected(own, 'A'), true);
  assert.equal(L.connected(own, 'B'), false);
  const own2 = Array(25).fill(null);
  [10, 11, 12, 13, 14].forEach(k => { own2[k] = 'B'; });
  assert.equal(L.connected(own2, 'B'), true);
});

test('فاميلي فيود: الإجابات المخفية لا تصل للاعبين، والسرقة تأخذ البنك', () => {
  const F = ENGINES.familyfeud;
  const rng = createRng(3);
  const s = F.setup(mk(5), {}, rng);
  const pv = F.view(s, 'p1');
  assert.ok(pv.answers.every(a => a.text === null));
  assert.ok(F.view(s, 'p0').answers.every(a => a.text));
  F.act(s, s.face.A, { type: 'buzz' }, ctx(rng));
  F.act(s, 'p0', { type: 'judge', index: 0 }, ctx(rng));
  assert.equal(s.phase, 'choose');
  F.act(s, s.face.A, { type: 'choose', value: 'play' }, ctx(rng));
  for (let k = 0; k < 3; k++) F.act(s, 'p0', { type: 'judge', index: -1 }, ctx(rng));
  assert.equal(s.phase, 'steal');
  const bank = s.bank;
  F.act(s, 'p0', { type: 'judge', index: 1 }, ctx(rng));
  assert.equal(s.score.B, bank + F.view(s, 'p0').answers[1].pts);
});

test('شريف: التفتيش على تاجر صادق يكلف الشريف، وعلى كاذب يصادر', () => {
  const Sh = ENGINES.shareef;
  const rng = createRng(4);
  const s = Sh.setup(mk(3), {}, rng);
  s.phase = 'inspect'; s.sheriff = 0; s.current = 1; s.queue = [2];
  s.players[1].bag = ['apple', 'apple']; s.players[1].declare = { good: 'apple', count: 2 };
  s.players[2].bag = ['apple', 'silk']; s.players[2].declare = { good: 'apple', count: 2 };
  const g0 = s.players[0].gold;
  Sh.act(s, 'p0', { type: 'inspect' }, ctx(rng));
  assert.equal(s.players[0].gold, g0 - 4);
  Sh.act(s, 'p0', { type: 'inspect' }, ctx(rng));
  assert.equal(s.players[0].gold, g0 - 4 + 4);
  assert.deepEqual(s.lastInspect.confiscated, ['silk']);
  // الملك والملكة
  s.players[0].stand = ['apple', 'apple']; s.players[1].stand = ['apple', 'apple', 'apple', 'apple']; s.players[2].stand = ['apple'];
  const sc = Sh.score(s);
  assert.equal(sc[1].bonus, 20); assert.equal(sc[0].bonus, 10); assert.equal(sc[2].bonus, 0);
});

test('مونوبولي: الإيجار والاحتكار والمحطات والبناء المتساوي والرهن', () => {
  const M = ENGINES.monopoly;
  const rng = createRng(1);
  const s = M.setup(mk(2), {}, rng);
  s.props[1].owner = 'p0';
  assert.equal(M.rentOf(s, 1, 7), 2);
  s.props[3].owner = 'p0';
  assert.equal(M.rentOf(s, 1, 7), 4, 'ضعف الإيجار للاحتكار');
  s.turn = 0; s.phase = 'end';
  assert.ok(M.act(s, 'p0', { type: 'build', sq: 1 }, ctx(rng)).ok);
  assert.equal(M.act(s, 'p0', { type: 'build', sq: 1 }, ctx(rng)).ok, false, 'البناء المتساوي');
  assert.ok(M.act(s, 'p0', { type: 'build', sq: 3 }, ctx(rng)).ok);
  assert.equal(M.rentOf(s, 1, 7), 10);
  assert.equal(M.act(s, 'p0', { type: 'mortgage', sq: 1 }, ctx(rng)).ok, false, 'لا رهن مع وجود مبانٍ');
  [5, 15].forEach(k => { s.props[k].owner = 'p1'; });
  assert.equal(M.rentOf(s, 5, 7), 50);
  s.props[12].owner = 'p1';
  assert.equal(M.rentOf(s, 12, 7), 28);
});

test('مونوبولي: الإفلاس لصالح لاعب ينقل الأملاك', () => {
  const M = ENGINES.monopoly;
  const rng = createRng(9);
  const s = M.setup(mk(3), {}, rng);
  s.props[39].owner = 'p1'; s.props[37].owner = 'p1';
  s.props[1].owner = 'p0';
  s.players[0].cash = 10; s.players[0].pos = 35; s.turn = 0; s.phase = 'roll';
  // نجبر الرمية على الوصول للخانة ٣٩
  const fake = { ...rng, int: () => 1 };
  M.act(s, 'p0', { type: 'roll' }, { rng: fake, now: 0 });
  assert.equal(s.players[0].pos, 39);
  assert.equal(s.phase, 'debt');
  assert.equal(s.debt.amount, 100);
  M.act(s, 'p0', { type: 'bankrupt' }, ctx(rng));
  assert.equal(s.players[0].bankrupt, true);
  assert.equal(s.props[1].owner, 'p1');
});

test('مونوبولي: أزرار الإدارة المعروضة تطابق ما يقبله المحرك تمامًا', () => {
  const M = ENGINES.monopoly;
  const TYPES = ['build', 'sellHouse', 'mortgage', 'unmortgage'];
  let checked = 0, shown = 0;
  for (let seed = 1; seed <= 12; seed++) {
    const rng = createRng(seed);
    const s = M.setup(mk(3), { maxRounds: 25 }, rng);
    // نوزّع مجموعات كاملة لتظهر حالات البناء
    [1, 3].forEach(k => { s.props[k].owner = 'p0'; });
    [6, 8, 9].forEach(k => { s.props[k].owner = 'p1'; });
    [11, 13, 14].forEach(k => { s.props[k].owner = 'p2'; });
    for (let step = 0; step < 900 && s.phase !== 'over'; step++) {
      // تحقق التطابق لكل لاعب
      for (const p of s.players) {
        const can = M.view(s, p.id).me.can;
        for (const k of Object.keys(s.props).map(Number)) {
          for (const t of TYPES) {
            const c = clone(s);
            const r = M.act(c, p.id, { type: t, sq: k }, { rng: createRng(1), now: 0 });
            const listed = (can[k] || []).includes(t);
            assert.equal(!!r.ok, listed, `seed ${seed} step ${step} ${p.id} ${t} @${k}: engine=${r.ok} shown=${listed} (${r.error || ''})`);
            checked++; if (listed) shown++;
          }
        }
      }
      // خطوة عشوائية تشمل البناء أحيانًا
      const cur = s.phase === 'debt' ? s.players[s.debt.from].id : s.phase === 'auction' ? s.players[s.auction.order[s.auction.at]].id : s.players[s.turn].id;
      const can = M.view(s, cur).me.can;
      const opts = [{ type: 'roll' }, { type: 'buy' }, { type: 'decline' }, { type: 'endTurn' }, { type: 'passBid' }, { type: 'bid', amount: (s.auction?.high || 0) + 10 }, { type: 'payDebt' }, { type: 'payJail' }];
      for (const [k, ts] of Object.entries(can)) for (const t of ts) if (t !== 'unmortgage' || rng.next() < .3) opts.push({ type: t, sq: Number(k) });
      if (s.phase === 'debt' && rng.next() < .1) opts.push({ type: 'bankrupt' });
      M.act(s, cur, rng.pick(opts), { rng, now: step * 1000 });
    }
  }
  assert.ok(shown > 50, 'ظهرت أزرار إدارة فعلية: ' + shown);
  assert.ok(checked > 10000);
});

test('حجم رسائل الحالة', () => { console.log('MAXVIEW ' + JSON.stringify(MAXV)); });

test('أفالون: في الاغتيال يعرف الأشرار بعضهم (بمن فيهم أوبيرون) وكل هدف معروض مقبول', () => {
  const A = ENGINES.avalon;
  for (let seed = 1; seed <= 40; seed++) {
    const rng = createRng(seed);
    const s = A.setup(mk(10), { oberon: true, mordred: true, morgana: true, percival: true }, rng);
    s.phase = 'assassin';
    const ass = s.players.find(p => p.role === 'assassin');
    const v = A.view(s, ass.id);
    const evil = s.players.filter(p => ['assassin', 'morgana', 'mordred', 'oberon', 'minion'].includes(p.role) && p.id !== ass.id).map(p => p.id).sort();
    assert.deepEqual([...v.me.knows.ids].sort(), evil);
    // نفس منطق الواجهة: الأهداف = الجميع عدا النفس والأشرار المعروفين
    for (const p of s.players.filter(p => p.id !== ass.id && !v.me.knows.ids.includes(p.id))) {
      assert.ok(A.act(clone(s), ass.id, { type: 'assassinate', target: p.id }, { rng, now: 0 }).ok);
    }
    // أهل الخير لا يرون شيئًا جديدًا
    const good = s.players.find(p => p.role === 'servant');
    if (good) assert.equal(A.view(s, good.id).me.knows, null);
  }
});

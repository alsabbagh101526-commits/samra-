// فحص صياغة كل ملفات جافاسكربت في المشروع (ملفات الواجهة لا تُحمَّل في اختبارات node الأخرى)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, statSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

function walk(d, out = []) {
  for (const f of readdirSync(d)) {
    const p = join(d, f);
    if (statSync(p).isDirectory()) walk(p, out); else if (p.endsWith('.js')) out.push(p);
  }
  return out;
}

test('كل ملفات js/ صحيحة الصياغة', () => {
  const files = walk(new URL('../js', import.meta.url).pathname);
  assert.ok(files.length > 40, 'عدد الملفات ' + files.length);
  const bad = [];
  for (const f of files) {
    try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
    catch (e) { bad.push(f + '\n' + String(e.stderr).split('\n').slice(0, 5).join('\n')); }
  }
  assert.deepEqual(bad, []);
});

test('لا تعريفات مكررة على مستوى الوحدة (let/const/function)', () => {
  const files = walk(new URL('../js', import.meta.url).pathname);
  const dups = [];
  for (const f of files) {
    const seen = new Map();
    for (const line of readFileSync(f, 'utf8').split('\n')) {
      const m = line.match(/^(?:export\s+)?(?:async\s+)?(?:let|const|function|class)\s+([A-Za-z_$][\w$]*)/);
      if (!m) continue;
      if (seen.has(m[1])) dups.push(`${f}: ${m[1]}`);
      seen.set(m[1], true);
    }
  }
  assert.deepEqual(dups, []);
});
